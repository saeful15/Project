/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;

import java.awt.event.KeyEvent;
import javax.swing.JTextField;

/**
 *
 * @author saeful_mizwar
 */
public interface Validasi {
    public void huruf(JTextField r,KeyEvent a);
    public void doube(JTextField r, KeyEvent a);
    public void angka(JTextField t,KeyEvent a);
    public void kk(JTextField t,KeyEvent a);
    public void username(KeyEvent a);
     public void passw(KeyEvent a);
      public void titik(JTextField t);
}
