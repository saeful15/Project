/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;

import Entitas.Entitas_Login;
import Jfarme.Login;

/**
 *
 * @author saeful_mizwar
 */
public interface login {
        public Entitas_Login Login(String username, String Kata_sandi);

}
