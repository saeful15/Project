/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Koneksi;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;
public class Koneksi implements Interface.Koneksi{
   
    public Connection con=null;
    public Connection buatKoneksi(){
        try{
            DriverManager.registerDriver(new com.mysql.jdbc.Driver());
            con=DriverManager.getConnection("jdbc:mysql://localhost/db_login","root","");
           //JOptionPane.showMessageDialog(null, "Koneksi sukses");
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, "Koneksi Gagal");
        }
        return con;
    }

}
