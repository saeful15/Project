/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tiket;

public final class Emas extends Zakat{
    private double harga_emas;

    Emas(int i) {
        setHarga_emas(i);
    }

   
   
     public double getHarga_emas() {
        return harga_emas;
    }

    public void setHarga_emas( double harga_emas) {
        this.harga_emas = harga_emas;
    }
   
    public Emas(double harga_emas, double jumlah) {
        this.harga_emas = harga_emas;
        this.setJumlah_harta(jumlah);
    }
    
    /**
     *
     * @return
     */
    @Override
    public long jumlah(){
        return (long)getJumlah_harta()*(long)getHarga_emas()*25/1000;
    }
    public double jumlah1(){
         return getHarga_emas()*25/1000;
    }
    

    
}
