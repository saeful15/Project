/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tiket;



public class Perdagangan extends Zakat{
    private double Modal;
    private double Bonus;
    private double Hutang;
    private double LR;
    private int Cod;

    public double getModal() {
        return Modal;
    }

    public void setModal(double Modal) {
        this.Modal = Modal;
    }

    public double getBonus() {
        return Bonus;
    }

    public void setBonus(double Bonus) {
        this.Bonus = Bonus;
    }

    public double getHutang() {
        return Hutang;
    }

    public void setHutang(double Hutang) {
        this.Hutang = Hutang;
    }

    public double getLR() {
        return LR;
    }

    public void setLR(double LR) {
        this.LR = LR;
    }

    public Perdagangan(double Modal, double Bonus, double Hutang, double LR,int c) {
        this.Modal = Modal;
        this.Bonus = Bonus;
        this.Hutang = Hutang;
        this.LR = LR;
        this.Cod=c;
    }
     @Override
    public long jumlah(){
         if (Cod==1){
             return (long)((long)getModal()+(long)getBonus()-(long)getHutang()+(long)getLR())*25/1000;
              
        } 
       else if (Cod==2){ 
           return (long)((long)getModal()+(long)getBonus()-(long)getHutang()-(long)getLR())*25/1000;
       }
       return 0; 
    }
}
