/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tiket;

public class Profesi  extends Zakat{
    private double Gaji;
    private double Bonus;
    private double Penghasilan_bruto;
    private double Pengeluaran;
    private double Penghasilan_Bersih;

    public double getGaji() {
        return Gaji;
    }

    public void setGaji(double Gaji) {
        this.Gaji = Gaji;
    }

    public double getBonus() {
        return Bonus;
    }

    public void setBonus(double Bonus) {
        this.Bonus = Bonus;
    }

    public double getPenghasilan_bruto() {
        return Penghasilan_bruto;
    }

    public void setPenghasilan_bruto() {
        this.Penghasilan_bruto = getGaji()+getBonus();
    }

    public double getPengeluaran() {
        return Pengeluaran;
    }

    public void setPengeluaran(double Pengeluaran) {
        this.Pengeluaran = Pengeluaran;
    }

    public double getPenghasilan_Bersih() {
        return Penghasilan_Bersih;
    }

    public void setPenghasilan_Bersih() {
        this.Penghasilan_Bersih = getPenghasilan_bruto()-getPengeluaran();
    }
     @Override
    public long jumlah(){
        return (long)getPenghasilan_Bersih()*25/1000;
    }

    public Profesi(double Gaji, double Bonus, double Pengeluaran) {
        this.Gaji = Gaji;
        this.Bonus = Bonus;
        this.Pengeluaran = Pengeluaran;
        setPenghasilan_bruto();
        setPenghasilan_Bersih();
    }
    
    
}
