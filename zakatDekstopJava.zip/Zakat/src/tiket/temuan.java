
package tiket;

public class temuan extends Zakat {
    private double nominal;

    public double getNominal() {
        return nominal;
    }

    public void setNominal(double nominal) {
        this.nominal = nominal;
    }

    public temuan(double nominal) {
        this.nominal = nominal;
    }
    @Override
    public long jumlah(){
        return (long)getNominal()*20/100;
    }
    
}
