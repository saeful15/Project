
package tiket;

public class Fitrah extends Zakat{
    private long jiwa;
    private long harga;

    public long getJiwa() {
        return jiwa;
    }

    public void setJiwa(long jiwa) {
        this.jiwa = jiwa;
    }

    public Fitrah(long jiwa, long harga) {
        this.jiwa = jiwa;
        this.harga = harga;
    }

    public long getHarga() {
        return harga;
    }

    public void setHarga(long harga) {
        this.harga = harga;
    }
    public long jumlah(){
        return (long) (getJiwa()*getHarga()*2.5);
    }
}
