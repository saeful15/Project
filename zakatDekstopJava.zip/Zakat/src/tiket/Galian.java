
package tiket;
public class Galian extends Zakat{
     private long harga;

    public long getHarga() {
        return harga;
    }

    public void setHarga(long harga) {
        this.harga = harga;
    }

    public Galian(long harga) {
        this.harga = harga;
    }
    public long jumlah(){
        return getHarga()*20/100;
    }
}
