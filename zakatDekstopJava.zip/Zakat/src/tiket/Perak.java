/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tiket;

/**
 *
 * @author saeful_mizwar
 */
public class Perak extends Zakat{
   private double harga_perak;
   public double getHarga_perak() {
        return harga_perak;
    }

    public Perak(double harga_perak) {
        this.harga_perak = harga_perak;
    }

    public void setHarga_perak(double harga_perak) {
        this.harga_perak = harga_perak;
    }
   @Override
    public long jumlah(){
        return (long)getJumlah_harta()*(long)getHarga_perak()*25/1000;
    }
     public double jumlah1(){
        return getHarga_perak()*25/1000;
    }
    
}
