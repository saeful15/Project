/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tiket;
    
import java.util.Scanner;


public class Zakat implements Interface.Zakat{
    String nama;
    private double berat;

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public double getJumlah_harta() {
        return berat;
    }

    public void setJumlah_harta(double jumlah_harta) {
        this.berat = jumlah_harta;
    }
    
    @Override
    public long jumlah(){
        return 0;
    }
    
    void cetak(){
        System.out.println(jumlah());
    }
    public static void main(String[] args) {
   
        
    }
}
