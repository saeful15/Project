/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tiket;

/**
 *
 * @author saeful_mizwar
 */
public class Pertanian extends Zakat {
    private double pendapatankilo;
    private double pendapatan;
    private int code;
    public double getPendapatan() {
        return pendapatan;
    }

    public double getPendapatankilo() {
        return pendapatankilo;
    }

    public void setPendapatankilo(double pendapatankilo) {
        this.pendapatankilo = pendapatankilo;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public void setPendapatan(double pendapatan) {
        this.pendapatan = pendapatan;
    }

    public Pertanian(double w, double pendapatan,int r) {
        this.pendapatan = pendapatan;
        this.code=r;
        this.pendapatankilo =w;
    }
    @Override
    public long jumlah(){
        if(code==1)
            return (long)getPendapatan()*(long)getPendapatankilo()*5/100;
        else if (code==2)
            return (long)getPendapatan()*(long)getPendapatankilo()*10/100;
        return 0;
    }
    public double jumlah1(){
        if(code==1)
            return getPendapatan()*5/100;
        else if (code==2)
            return getPendapatan()*10/100;
        return 0;
    }
    
}
