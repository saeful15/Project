
package Validasi;

import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Cek implements Interface.Validasi{
    public void huruf(JTextField r,KeyEvent a){
        char q[]=r.getText().toCharArray();
        
        if (!(Character.isAlphabetic(a.getKeyChar()) || Character.isSpace(a.getKeyChar()))) {
            a.consume();
        }
        for (int i = 0; i < q.length; i++) {
           if(q[0]==' '){
               r.setText("");
           }
        }
        String h="";
        if( q.length>2 && (q[q.length-1]==' ' && q[q.length-2]==' ')){
               for (int i = 0; i < q.length-1; i++) {
                    h+=q[i];    
                }
                r.setText(h);
            }
      
    }
    @Override
    public void doube(JTextField r, KeyEvent a){
        int y=0;
        char q[]=r.getText().toCharArray();
        for (int i = 0; i < q.length; i++) {
            if(q[i]=='.'){
               y+=1; 
            }  
        }
        if (!(Character.isDigit(a.getKeyChar()) || a.getKeyChar()=='.' && y==0)) {
            a.consume();
        }
        for (int i = 0; i < q.length; i++) {
           if(q[0]=='.'){
               r.setText("");
               y=0;
           }
        }
        
    }
  public void angka(JTextField t,KeyEvent a) {
        char q[]=t.getText().toCharArray();
        if (!(Character.isDigit(a.getKeyChar()))) {
            a.consume();
        }
        for (int i = 0; i < q.length; i++) {
           if(q[0]=='0'){
               t.setText("");
           }
        }
    }
    public void kk(JTextField t,KeyEvent a) {
      
        char q[]=t.getText().toCharArray();
        /*if(q.length<1){
            t.setText("3");
        }*/
        if( q.length>16){
            JOptionPane.showMessageDialog(null, "nomor kk tidak boleh lebih 16 digit!");
            String h="";
            for (int i = 0; i < 15; i++) {
                h+=q[i]; 
            }
            t.setText(h);
        }
        else{
            if (!(Character.isDigit(a.getKeyChar()))) {
            a.consume();
            }
            for (int i = 0; i < q.length; i++) {
                if(q[0]=='0' || q[0]=='4'){
                    t.setText("");
                }
            }
        }
    }
    public void username(KeyEvent a){
         if (!(Character.isDigit(a.getKeyChar()) || Character.isAlphabetic(a.getKeyChar())|| a.getKeyChar()=='_')){
             a.consume();
         }
    }
     public void passw(KeyEvent a){
         if (!(Character.isDigit(a.getKeyChar()) || Character.isAlphabetic(a.getKeyChar()))){
             a.consume();
         }
    }
    public void titik(JTextField t){
        t.setText(String.valueOf(Integer.parseInt(t.getText())));
    }
}
