/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entitas;

/**
 *
 * @author saeful_mizwar
 */
public class Entitas_Kas_Umum {
     private String Tanggal,Keterangan;
     private int Debet,Kredit,Saldo;

    public String getTanggal() {
        return Tanggal;
    }

    public void setTanggal(String Tanggal) {
        this.Tanggal = Tanggal;
    }

    public String getKeterangan() {
        return Keterangan;
    }

    public void setKeterangan(String Keterangan) {
        this.Keterangan = Keterangan;
    }

    public int getDebet() {
        return Debet;
    }

    public void setDebet(int Debet) {
        this.Debet = Debet;
    }

    public int getKredit() {
        return Kredit;
    }

    public void setKredit(int Kredit) {
        this.Kredit = Kredit;
    }

    public int getSaldo() {
        return Saldo;
    }

    public void setSaldo(int Saldo) {
        this.Saldo = Saldo;
    }
     
}
