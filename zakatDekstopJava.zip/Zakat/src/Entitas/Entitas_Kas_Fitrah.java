/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entitas;

import java.text.SimpleDateFormat;

/**
 *
 * @author saeful_mizwar
 */
public class Entitas_Kas_Fitrah {
     private String Tanggal,No_kk,Kepala,anggota;
     private int Debet,Kredit,Saldo;

    public String getNo_kk() {
        return No_kk;
    }

    public void setNo_kk(String No_kk) {
        this.No_kk = No_kk;
    }

    public String getKepala() {
        return Kepala;
    }

    public void setKepala(String Kepala) {
        this.Kepala = Kepala;
    }

    public String getAnggota() {
        return anggota;
    }

    public void setAnggota(String anggota) {
        this.anggota = anggota;
    }

    public String getTanggal() {
        return Tanggal;
    }

    public void setTanggal(String Tanggal) {
        this.Tanggal = Tanggal;
    }

   
    public int getDebet() {
        return Debet;
    }

    public void setDebet(int Debet) {
        this.Debet = Debet;
    }

    public int getKredit() {
        return Kredit;
    }

    public void setKredit(int Kredit) {
        this.Kredit = Kredit;
    }

    public int getSaldo() {
        return Saldo;
    }

    public void setSaldo(int Saldo) {
        this.Saldo = Saldo;
    }

    public void setTanggal(SimpleDateFormat sm) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
     
}
