package Entitas;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author saeful_mizwar
 */
public class Entitas_Data_Masyarakat {
     private String No_kk, Kepala;
     private int Jumlah;

    public String getNo_kk() {
        return No_kk;
    }

    public void setNo_kk(String No_kk) {
        this.No_kk = No_kk;
    }

    public String getKepala() {
        return Kepala;
    }

    public void setKepala(String Kepala) {
        this.Kepala = Kepala;
    }

    public int getJumlah() {
        return Jumlah;
    }

    public void setJumlah(int Jumlah) {
        this.Jumlah = Jumlah;
    }
     
}
