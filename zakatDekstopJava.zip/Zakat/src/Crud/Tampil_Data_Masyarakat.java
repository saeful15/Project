/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Crud;
import Koneksi.Koneksi;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Tampil_Data_Masyarakat implements Interface.Tampil_Data_Masyarakat{
 Connection koneksi;
    public Tampil_Data_Masyarakat(){
        Koneksi ks=new Koneksi();
        koneksi=ks.buatKoneksi();
    }
   
    public DefaultTableModel tampilMasyarakat() {
        ResultSet r = null;
        DefaultTableModel tb = new DefaultTableModel();
        
        try {
            Statement stm = koneksi.createStatement();
            r = stm.executeQuery("select * from kk");
            tb.addColumn("no_kk");
            tb.addColumn("nama_kepala_keluarga");
            tb.addColumn("anggota"); 
            while (r.next()) {
                tb.addRow(new Object[]{
                    r.getString("no_kk"),
                    r.getString("nama_kepala_keluarga"),
                    r.getInt("anggota")
                });
            }
        } catch (SQLException ex) {
           // Logger.getLogger(CRUD.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex);
        }

        return tb;
    //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    public DefaultTableModel tampilMasyarakat1(Entitas.Entitas_Data_Masyarakat ea) {
        ResultSet r = null;
        DefaultTableModel tb = new DefaultTableModel();
        
        try {
            Statement stm = koneksi.createStatement();
            r = stm.executeQuery("select * from kk where no_kk='"+ea.getNo_kk()+"'");
            tb.addColumn("no_kk");
            tb.addColumn("nama_kepala_keluarga");
            tb.addColumn("anggota"); 
            while (r.next()) {
                tb.addRow(new Object[]{
                    r.getString("no_kk"),
                    r.getString("nama_kepala_keluarga"),
                    r.getInt("anggota")
                });
            }
        } catch (SQLException ex) {
           // Logger.getLogger(CRUD.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex);
        }

        return tb;
    //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
     
}
