/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Crud;

import Entitas.Entitas_Login;
import Interface.login;
import Jfarme.Induk;
import Jfarme.Login;
import Jfarme.loading;
import Koneksi.Koneksi;
import static java.lang.Thread.sleep;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author saeful_mizwar
 */
public class Login_admin implements login{
    Entitas_Login user = new Entitas_Login();
    ResultSet r ;
    Koneksi konek=new Koneksi();
    Induk menu = new Induk();
    Login login=new Login(); 
    public Entitas_Login Login(String uname, String pass ) {
        Connection koneksi= konek.buatKoneksi();
       
        try {
            Statement stm = koneksi.createStatement();
            r = stm.executeQuery("select * from tb_login where username = '"+ uname+"' and kata_sandi= '"+ pass+"'");
             if(r.next()){
                if(uname.equals(r.getString("username")) && pass.equals(r.getString("kata_sandi"))){
                    JOptionPane.showMessageDialog(null, "berhasil login");
                    login.dispose();
                    login.setVisible(false);
                    loading bb=new loading();
                    menu.setVisible(true);
                }else{
                    JOptionPane.showMessageDialog(null, "Silahkan NYalakan Examp dulu!!!");
                    System.exit(0);
                    
                  
                }
            }else{ 
                   JOptionPane.showMessageDialog(null, "username atau password salah");
                }
        } catch (SQLException ex) {
            Logger.getLogger(Login_admin.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return user;
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    
    }

    private void dispose() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
     
}
