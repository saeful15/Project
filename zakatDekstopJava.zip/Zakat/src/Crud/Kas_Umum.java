/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Crud;

import Entitas.Entitas_Kas_Umum;
import Koneksi.Koneksi;
import java.sql.Connection;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author saeful_mizwar
 */
public class Kas_Umum implements Interface.Kas_Umum{
     Koneksi konek;
    Connection con;
    public Kas_Umum(){
        Koneksi konek=new Koneksi();
        con=konek.buatKoneksi();
    }
    public int TambahData(Entitas_Kas_Umum ea){
        int hasil=0;
        try {
            Statement stm=con.createStatement();
            hasil=stm.executeUpdate("insert into kas values('" + ea.getTanggal()+ "','" + ea.getKeterangan()+ "','" + ea.getDebet()+"','" + 0 + "','" + ea.getSaldo() +"')");
            JOptionPane.showMessageDialog(null, "Input Berhasil");
        } catch (Exception e) {
            System.out.println(e);
        }
        return hasil;
    }
    public int KurangData(Entitas_Kas_Umum ea){
        int hasil=0;
        try {
            Statement stm=con.createStatement();
            hasil=stm.executeUpdate("insert into kas values('" + ea.getTanggal()+ "','" + ea.getKeterangan()+ "','" + 0 +"','" + ea.getKredit() + "','" + ea.getSaldo() +"')");
            JOptionPane.showMessageDialog(null, "Input Berhasil");
        } catch (Exception e) {
            System.out.println(e);
        }
        return hasil;
    }
}
