/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Crud;

import Koneksi.Koneksi;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author saeful_mizwar
 */
public class Ambil_Saldo_Kas_Fitrah implements  Interface.Ambil_Saldo_Kas_Fitrah{
  Connection koneksi;
    public Ambil_Saldo_Kas_Fitrah(){
        Koneksi ks=new Koneksi();
        koneksi=ks.buatKoneksi();
    }
   
    public DefaultTableModel tampilsaldo() {
        ResultSet r = null;
        DefaultTableModel tb = new DefaultTableModel();
        
        try {
            Statement stm = koneksi.createStatement();
            r = stm.executeQuery("select * from saldo_fitrah");
            tb.addColumn("saldo"); 
            while (r.next()) {
                tb.addRow(new Object[]{
                    r.getString("saldo")
                });
            }
        } catch (SQLException ex) {
           // Logger.getLogger(CRUD.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex);
        }

        return tb;
    //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
      public int UbahData(int ea){
        int hasil=0;
        try {
            Statement stm=koneksi.createStatement();
            hasil=stm.executeUpdate("Update saldo_fitrah set saldo='" + ea + "'");
        } catch (Exception e) {
             JOptionPane.showMessageDialog(null, e);
        }
        return hasil;
    }
      
}
