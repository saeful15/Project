
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Crud;

import Entitas.Entitas_Kas_Fitrah;
import Koneksi.Koneksi;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author saeful_mizwar
 */
public class Kas_Fitrah implements Interface.Kas_Fitrah{
       Koneksi konek;
    Connection con;
    public Kas_Fitrah(){
        Koneksi konek=new Koneksi();
        con=konek.buatKoneksi();
    }
    public int TambahData(Entitas_Kas_Fitrah ea){
        int hasil=0;
        try {
            Statement stm=con.createStatement();
            hasil=stm.executeUpdate("insert into kas_fitrah values('" + ea.getTanggal()+ "','" + ea.getNo_kk()+ "','" + ea.getKepala()+ "','" + ea.getAnggota()+ "','" + ea.getDebet()+"','" + 0 + "','" + ea.getSaldo() +"')");
            JOptionPane.showMessageDialog(null, "Input Berhasil");
        } catch (Exception e) {
            System.out.println(e);
        }
        return hasil;
    }
    public int KurangData(Entitas_Kas_Fitrah ea){
        int hasil=0;
        try {
            Statement stm=con.createStatement();
            hasil=stm.executeUpdate("insert into kas_fitrah values('" + ea.getTanggal()+ "','" + ea.getNo_kk()+ "','" + ea.getKepala()+ "','" + ea.getAnggota()+ "','" + 0 +"','" + ea.getKredit() + "','" + ea.getSaldo() +"')");
            JOptionPane.showMessageDialog(null, "Input Berhasil");
        } catch (Exception e) {
            System.out.println(e);
        }
        return hasil;
    }
     public DefaultTableModel tampilKasFitrah() {
        ResultSet r = null;
        DefaultTableModel tb = new DefaultTableModel();
        
        try {
            Statement stm = con.createStatement();
            r = stm.executeQuery("select * from kas_fitrah");
            tb.addColumn("Tanggal");
            tb.addColumn("no_kk");
            tb.addColumn("Kepala_Keluarga");
            tb.addColumn("Anggota");
            tb.addColumn("Debet");
            tb.addColumn("Kredit");
            tb.addColumn("Saldo");
            
            
            while (r.next()) {
                tb.addRow(new Object[]{
                    r.getString("Tanggal"),
                    r.getString("no_kk"),
                    r.getString("Kepala_keluarga"),
                    r.getString("Anggota"),
                    r.getInt("Debet"),
                    r.getInt("Kredit"),
                    r.getInt("Saldo")
                });

            }

        } catch (SQLException ex) {
           // Logger.getLogger(CRUD.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex);
        }

        return tb;
    //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
