/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Crud;





import Koneksi.Koneksi;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Tampil_Kas_Fitrah implements Interface.Tampil_Kas_Fitrah{
 Connection koneksi;
    public Tampil_Kas_Fitrah(){
        Koneksi ks=new Koneksi();
        koneksi=ks.buatKoneksi();
    }
   
    public DefaultTableModel tampilKasFitrah() {
        ResultSet r = null;
        DefaultTableModel tb = new DefaultTableModel();
        
        try {
            Statement stm = koneksi.createStatement();
            r = stm.executeQuery("select * from kas_fitrah");
            tb.addColumn("Tanggal");
            tb.addColumn("no_kk");
            tb.addColumn("Kepala_Keluarga");
            tb.addColumn("Anggota");
            tb.addColumn("Debet");
            tb.addColumn("Kredit");
            tb.addColumn("Saldo");
            
            
            while (r.next()) {
                tb.addRow(new Object[]{
                    r.getString("Tanggal"),
                    r.getString("no_kk"),
                    r.getString("Kepala_keluarga"),
                    r.getString("Anggota"),
                    r.getInt("Debet"),
                    r.getInt("Kredit"),
                    r.getInt("Saldo")
                });

            }

        } catch (SQLException ex) {
           // Logger.getLogger(CRUD.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex);
        }

        return tb;
    //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
