/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Crud;

import Entitas.Entitas_Data_Masyarakat;
import Koneksi.Koneksi;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author saeful_mizwar
 */
public class Data_Masyarakat implements Interface.Data_Masyarakat{
    Koneksi konek;
    Connection con;
    public Data_Masyarakat(){
        Koneksi konek=new Koneksi();
        con=konek.buatKoneksi();
    }
    public int TambahData(Entitas_Data_Masyarakat ea){
        int hasil=0;
        try {
            Statement stm=con.createStatement();
            hasil=stm.executeUpdate("insert into kk values('" + ea.getNo_kk()+ "','" + ea.getKepala()+ "','" + ea.getJumlah()+"')");
            JOptionPane.showMessageDialog(null, "Input Berhasil");
        } catch (Exception e) {
            System.out.println(e);
        }
        return hasil;
    }
      public int HapusData(Entitas_Data_Masyarakat ea){
        int hasil=0;
        int p=JOptionPane.showConfirmDialog (null, "Yakin Akan Dihapus?","Peringatan!",JOptionPane.YES_OPTION);
        if (p == 0) {
        try {
            Statement stm=con.createStatement();
            hasil=stm.executeUpdate("Delete from kk where no_kk='" + ea.getNo_kk() + "'");
            JOptionPane.showMessageDialog(null, "Data Telah Dihapus");
        } catch (SQLException | HeadlessException e) {
        }
        }
        return hasil;
    }
       public int UbahData(Entitas_Data_Masyarakat ea){
        int hasil=0;
        int p=JOptionPane.showConfirmDialog (null, "Yakin Akan Diubah?","Peringatan!",JOptionPane.YES_OPTION);
        if (p == 0) {
        try {
            Statement stm=con.createStatement();
            hasil=stm.executeUpdate("Update kk set nama_kepala_keluarga='" + ea.getKepala()+ "',anggota='" + ea.getJumlah()+"' where no_kk='" + ea.getNo_kk()+ "'");
            JOptionPane.showMessageDialog(null, "Data Telah Diubah");
        } catch (Exception e) {
             JOptionPane.showMessageDialog(null, e);
        }
        return hasil;
        }
        return 0;
        
    }
        public DefaultTableModel tampilKasFitrah(Entitas_Data_Masyarakat ea) {
        ResultSet r = null;
        DefaultTableModel tb = new DefaultTableModel();
        try {
            Statement stm = con.createStatement();
            r = stm.executeQuery("select * from kk where nama_kepala_keluarga like '%"+ea.getKepala()+"%'" ); 
            tb.addColumn("no_kk");
            tb.addColumn("nama_kepala_keluarga");
            tb.addColumn("anggota"); 
            while (r.next()) {
                tb.addRow(new Object[]{
                    r.getString("no_kk"),
                    r.getString("nama_kepala_keluarga"),
                    r.getInt("anggota")
                });
            }
        } catch (SQLException ex) {
           // Logger.getLogger(CRUD.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex);
        }

        return tb;
    //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    public DefaultTableModel tampilKasFitrah1(Entitas_Data_Masyarakat ea) {
        ResultSet r = null;
        DefaultTableModel tb = new DefaultTableModel();
        try {
            Statement stm = con.createStatement();
            r = stm.executeQuery("select * from kk where no_kk='"+ea.getKepala()+"'"); 
            tb.addColumn("no_kk");
            tb.addColumn("nama_kepala_keluarga");
            tb.addColumn("anggota"); 
            while (r.next()) {
                tb.addRow(new Object[]{
                    r.getString("no_kk"),
                    r.getString("nama_kepala_keluarga"),
                    r.getInt("anggota")
                });
            }
        } catch (SQLException ex) {
           // Logger.getLogger(CRUD.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex);
        }

        return tb;
    //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
       
}
