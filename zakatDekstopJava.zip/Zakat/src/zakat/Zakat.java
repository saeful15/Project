/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zakat;
import Jfarme.Login;
import Koneksi.Koneksi;
/**
 *
 * @author saeful_mizwar
 */
public class Zakat {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Koneksi a=new Koneksi();
        a.buatKoneksi();
        Login k=new Login();
       k.setVisible(true);       
       
    }
    
}
