package Jfarme;

import Crud.Ambil_Data_Masyarakat;
import Crud.Ambil_Saldo_Kas;
import Crud.Ambil_Saldo_Kas_Fitrah;
import Crud.Data_Masyarakat;
import Crud.Kas_Fitrah;
import Crud.Kas_Umum;
import Crud.Tampil_Data_Masyarakat;
import Crud.Tampil_Kas_Fitrah;
import Crud.Tampil_Kas_Umum;
import Entitas.Entitas_Data_Masyarakat;
import Entitas.Entitas_Kas_Fitrah;
import Entitas.Entitas_Kas_Umum;
import Validasi.Cek;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.Timer;
import javax.xml.bind.DatatypeConverter;
import tiket.Emas;
import tiket.Fitrah;
import tiket.Galian;
import tiket.Perak;
import tiket.Perdagangan;
import tiket.Pertanian;
import tiket.Profesi;
import tiket.temuan;

public class Induk extends javax.swing.JFrame {
        Data_Masyarakat b= new Data_Masyarakat();
        Entitas_Data_Masyarakat isi=new Entitas_Data_Masyarakat();
        public String No;
        String tanggal="yyyy-MM-dd";
        SimpleDateFormat tgll=new SimpleDateFormat(tanggal);
        Cek a=new Cek();
    public Induk() {
        initComponents();
       jTable4.setVisible(false);
       Pengertian.setVisible(false);
       Syarat.setVisible(false);
       Rukun.setVisible(false);
       Perhitungan.setVisible(false);
       Kas_fitrah.setVisible(false);
       Kas_mesjid.setVisible(false);
       Data_masyarakat.setVisible(false);
       Wdkm.removeAll();
       Wdkm.repaint();
       Wdkm.revalidate();
       tanggal();
        jam();
    }
   String sm;
    void tanggal(){
        Date d=new Date();
        SimpleDateFormat s=new SimpleDateFormat("dd-MM-yyyy");
        SimpleDateFormat smm=new SimpleDateFormat("yyyy-MM-dd");
        sm=smm.format(d);
        tgl.setText(s.format(d));   
    }
    void jam (){
        new Timer(0,new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
               Date d=new Date();
               SimpleDateFormat s=new SimpleDateFormat("hh:mm:ss");
               tgl1.setText(s.format(d));   
            }
        }).start();
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Perak_rukun = new javax.swing.JPanel();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        jPanel2 = new javax.swing.JPanel();
        Wadah = new javax.swing.JPanel();
        Wdkm = new javax.swing.JPanel();
        PKas_m = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        Keterangan = new javax.swing.JTextField();
        Jumlah = new javax.swing.JTextField();
        Ok = new javax.swing.JButton();
        Tanggal = new com.toedter.calendar.JDateChooser();
        jPanel7 = new javax.swing.JPanel();
        jRadioButton5 = new javax.swing.JRadioButton();
        jRadioButton6 = new javax.swing.JRadioButton();
        jPanel10 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel250 = new javax.swing.JLabel();
        jButton7 = new javax.swing.JButton();
        jLabel242 = new javax.swing.JLabel();
        PData = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        tambahkk = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        tambahjumlah = new javax.swing.JTextField();
        tambahkepala = new javax.swing.JTextField();
        Ok1 = new javax.swing.JButton();
        ubahjumlah = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        ubahkepala = new javax.swing.JTextField();
        ubahkk = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        hapuskk = new javax.swing.JTextField();
        Ok4 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        Ok2 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel253 = new javax.swing.JLabel();
        hapuskk1 = new javax.swing.JTextField();
        jButton22 = new javax.swing.JButton();
        jLabel247 = new javax.swing.JLabel();
        PKas_F = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jPanel8 = new javax.swing.JPanel();
        jLabel254 = new javax.swing.JLabel();
        No_kk = new javax.swing.JTextField();
        jLabel255 = new javax.swing.JLabel();
        kepala = new javax.swing.JTextField();
        jLabel256 = new javax.swing.JLabel();
        anggota = new javax.swing.JTextField();
        jLabel257 = new javax.swing.JLabel();
        jumlah = new javax.swing.JTextField();
        jButton8 = new javax.swing.JButton();
        jLabel258 = new javax.swing.JLabel();
        Tanggal1 = new com.toedter.calendar.JDateChooser();
        jPanel9 = new javax.swing.JPanel();
        jLabel268 = new javax.swing.JLabel();
        No_kk1 = new javax.swing.JTextField();
        jLabel269 = new javax.swing.JLabel();
        kepala1 = new javax.swing.JTextField();
        jLabel270 = new javax.swing.JLabel();
        anggota1 = new javax.swing.JTextField();
        jLabel271 = new javax.swing.JLabel();
        jumlah1 = new javax.swing.JTextField();
        jButton21 = new javax.swing.JButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable5 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jLabel267 = new javax.swing.JLabel();
        jLabel176 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jLabel241 = new javax.swing.JLabel();
        Emas_perhitungan = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel174 = new javax.swing.JLabel();
        berat = new javax.swing.JTextField();
        jLabel175 = new javax.swing.JLabel();
        harga = new javax.swing.JTextField();
        nishab = new javax.swing.JTextField();
        jLabel185 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        jLabel172 = new javax.swing.JLabel();
        hasilgram = new javax.swing.JTextField();
        jLabel173 = new javax.swing.JLabel();
        hasilrupiah = new javax.swing.JTextField();
        jButton4 = new javax.swing.JButton();
        Emas_rukun = new javax.swing.JPanel();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        Perak_pengertian = new javax.swing.JPanel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        Perak_syarat = new javax.swing.JPanel();
        jLabel41 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        jLabel53 = new javax.swing.JLabel();
        jLabel54 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        jLabel56 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        Temuan_pengertian = new javax.swing.JPanel();
        jLabel58 = new javax.swing.JLabel();
        jLabel59 = new javax.swing.JLabel();
        jLabel60 = new javax.swing.JLabel();
        jLabel61 = new javax.swing.JLabel();
        jLabel62 = new javax.swing.JLabel();
        jLabel63 = new javax.swing.JLabel();
        jLabel64 = new javax.swing.JLabel();
        jLabel65 = new javax.swing.JLabel();
        jLabel66 = new javax.swing.JLabel();
        jLabel67 = new javax.swing.JLabel();
        Temuan_rukun = new javax.swing.JPanel();
        jLabel68 = new javax.swing.JLabel();
        jLabel69 = new javax.swing.JLabel();
        jLabel70 = new javax.swing.JLabel();
        jLabel71 = new javax.swing.JLabel();
        jLabel72 = new javax.swing.JLabel();
        Temuan_syarat = new javax.swing.JPanel();
        jLabel76 = new javax.swing.JLabel();
        jLabel77 = new javax.swing.JLabel();
        jLabel78 = new javax.swing.JLabel();
        jLabel79 = new javax.swing.JLabel();
        jLabel80 = new javax.swing.JLabel();
        jLabel81 = new javax.swing.JLabel();
        Fitrah_rukun = new javax.swing.JPanel();
        jLabel73 = new javax.swing.JLabel();
        jLabel82 = new javax.swing.JLabel();
        jLabel83 = new javax.swing.JLabel();
        jLabel84 = new javax.swing.JLabel();
        jLabel85 = new javax.swing.JLabel();
        jLabel86 = new javax.swing.JLabel();
        jLabel87 = new javax.swing.JLabel();
        Fitrah_syarat = new javax.swing.JPanel();
        jLabel74 = new javax.swing.JLabel();
        jLabel75 = new javax.swing.JLabel();
        jLabel88 = new javax.swing.JLabel();
        jLabel89 = new javax.swing.JLabel();
        jLabel90 = new javax.swing.JLabel();
        jLabel91 = new javax.swing.JLabel();
        jLabel92 = new javax.swing.JLabel();
        jLabel93 = new javax.swing.JLabel();
        jLabel94 = new javax.swing.JLabel();
        Fitrah_pengertian = new javax.swing.JPanel();
        jLabel95 = new javax.swing.JLabel();
        jLabel96 = new javax.swing.JLabel();
        jLabel97 = new javax.swing.JLabel();
        jLabel98 = new javax.swing.JLabel();
        Galian_pengertian = new javax.swing.JPanel();
        jLabel99 = new javax.swing.JLabel();
        jLabel100 = new javax.swing.JLabel();
        jLabel101 = new javax.swing.JLabel();
        jLabel102 = new javax.swing.JLabel();
        Galian_rukun = new javax.swing.JPanel();
        jLabel103 = new javax.swing.JLabel();
        jLabel104 = new javax.swing.JLabel();
        jLabel105 = new javax.swing.JLabel();
        jLabel106 = new javax.swing.JLabel();
        jLabel107 = new javax.swing.JLabel();
        Galian_syarat = new javax.swing.JPanel();
        jLabel111 = new javax.swing.JLabel();
        jLabel112 = new javax.swing.JLabel();
        jLabel113 = new javax.swing.JLabel();
        jLabel114 = new javax.swing.JLabel();
        jLabel115 = new javax.swing.JLabel();
        Profesi_pengertian = new javax.swing.JPanel();
        jLabel108 = new javax.swing.JLabel();
        jLabel109 = new javax.swing.JLabel();
        jLabel110 = new javax.swing.JLabel();
        jLabel116 = new javax.swing.JLabel();
        jLabel133 = new javax.swing.JLabel();
        Profesi_syarat = new javax.swing.JPanel();
        jLabel117 = new javax.swing.JLabel();
        jLabel118 = new javax.swing.JLabel();
        jLabel119 = new javax.swing.JLabel();
        jLabel120 = new javax.swing.JLabel();
        jLabel121 = new javax.swing.JLabel();
        Profesi_rukun = new javax.swing.JPanel();
        jLabel125 = new javax.swing.JLabel();
        jLabel126 = new javax.swing.JLabel();
        jLabel127 = new javax.swing.JLabel();
        jLabel128 = new javax.swing.JLabel();
        jLabel129 = new javax.swing.JLabel();
        jLabel130 = new javax.swing.JLabel();
        jLabel131 = new javax.swing.JLabel();
        jLabel132 = new javax.swing.JLabel();
        Perdagangan_pengertian = new javax.swing.JPanel();
        jLabel122 = new javax.swing.JLabel();
        jLabel123 = new javax.swing.JLabel();
        jLabel124 = new javax.swing.JLabel();
        jLabel134 = new javax.swing.JLabel();
        jLabel149 = new javax.swing.JLabel();
        Perdagangan_syarat = new javax.swing.JPanel();
        jLabel135 = new javax.swing.JLabel();
        jLabel136 = new javax.swing.JLabel();
        jLabel137 = new javax.swing.JLabel();
        jLabel138 = new javax.swing.JLabel();
        Perdagangan_rukun = new javax.swing.JPanel();
        jLabel143 = new javax.swing.JLabel();
        jLabel144 = new javax.swing.JLabel();
        jLabel145 = new javax.swing.JLabel();
        jLabel146 = new javax.swing.JLabel();
        jLabel147 = new javax.swing.JLabel();
        jLabel148 = new javax.swing.JLabel();
        Pertanian_pengertian = new javax.swing.JPanel();
        jLabel139 = new javax.swing.JLabel();
        jLabel140 = new javax.swing.JLabel();
        jLabel141 = new javax.swing.JLabel();
        jLabel142 = new javax.swing.JLabel();
        jLabel166 = new javax.swing.JLabel();
        jLabel167 = new javax.swing.JLabel();
        jLabel168 = new javax.swing.JLabel();
        Pertanian_syarat = new javax.swing.JPanel();
        jLabel150 = new javax.swing.JLabel();
        jLabel151 = new javax.swing.JLabel();
        jLabel152 = new javax.swing.JLabel();
        jLabel153 = new javax.swing.JLabel();
        jLabel154 = new javax.swing.JLabel();
        jLabel155 = new javax.swing.JLabel();
        jLabel156 = new javax.swing.JLabel();
        jLabel157 = new javax.swing.JLabel();
        jLabel169 = new javax.swing.JLabel();
        Pertanian_rukun = new javax.swing.JPanel();
        jLabel158 = new javax.swing.JLabel();
        jLabel159 = new javax.swing.JLabel();
        jLabel160 = new javax.swing.JLabel();
        jLabel161 = new javax.swing.JLabel();
        jLabel162 = new javax.swing.JLabel();
        jLabel163 = new javax.swing.JLabel();
        Emas_pengertian = new javax.swing.JPanel();
        jLabel164 = new javax.swing.JLabel();
        jLabel165 = new javax.swing.JLabel();
        jLabel170 = new javax.swing.JLabel();
        jLabel171 = new javax.swing.JLabel();
        Perak_perhitungan = new javax.swing.JPanel();
        jLabel177 = new javax.swing.JLabel();
        jLabel178 = new javax.swing.JLabel();
        jLabel179 = new javax.swing.JLabel();
        jLabel180 = new javax.swing.JLabel();
        jLabel183 = new javax.swing.JLabel();
        beratperak = new javax.swing.JTextField();
        jLabel184 = new javax.swing.JLabel();
        hargaperak = new javax.swing.JTextField();
        nishabperak = new javax.swing.JTextField();
        jLabel189 = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        jButton5 = new javax.swing.JButton();
        jLabel181 = new javax.swing.JLabel();
        jLabel182 = new javax.swing.JLabel();
        hasilperak = new javax.swing.JTextField();
        hasilperak1 = new javax.swing.JTextField();
        jButton6 = new javax.swing.JButton();
        Temuan_perhitungan = new javax.swing.JPanel();
        jLabel195 = new javax.swing.JLabel();
        jLabel196 = new javax.swing.JLabel();
        namatemuan = new javax.swing.JTextField();
        jPanel13 = new javax.swing.JPanel();
        jLabel198 = new javax.swing.JLabel();
        jLabel202 = new javax.swing.JLabel();
        nilaitemuan = new javax.swing.JTextField();
        jButton9 = new javax.swing.JButton();
        jLabel199 = new javax.swing.JLabel();
        hasiltemuan = new javax.swing.JTextField();
        jLabel200 = new javax.swing.JLabel();
        jButton10 = new javax.swing.JButton();
        Fitrah_perhitungan = new javax.swing.JPanel();
        jLabel197 = new javax.swing.JLabel();
        jPanel14 = new javax.swing.JPanel();
        jButton12 = new javax.swing.JButton();
        hasilfitrah = new javax.swing.JTextField();
        jLabel205 = new javax.swing.JLabel();
        jLabel204 = new javax.swing.JLabel();
        jButton11 = new javax.swing.JButton();
        jLabel203 = new javax.swing.JLabel();
        jLabel206 = new javax.swing.JLabel();
        hargafitrah = new javax.swing.JTextField();
        jumlahfitrah = new javax.swing.JTextField();
        jLabel201 = new javax.swing.JLabel();
        Galian_perhitungan = new javax.swing.JPanel();
        jLabel207 = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        jButton14 = new javax.swing.JButton();
        hasilgalian = new javax.swing.JTextField();
        jLabel211 = new javax.swing.JLabel();
        jLabel210 = new javax.swing.JLabel();
        jButton13 = new javax.swing.JButton();
        nilaigalian = new javax.swing.JTextField();
        jLabel212 = new javax.swing.JLabel();
        jLabel209 = new javax.swing.JLabel();
        namagalian = new javax.swing.JTextField();
        jLabel208 = new javax.swing.JLabel();
        Pertanian_perhitungan = new javax.swing.JPanel();
        jLabel213 = new javax.swing.JLabel();
        jLabel214 = new javax.swing.JLabel();
        jLabel215 = new javax.swing.JLabel();
        jLabel216 = new javax.swing.JLabel();
        jLabel219 = new javax.swing.JLabel();
        berattani = new javax.swing.JTextField();
        nishabtani = new javax.swing.JTextField();
        hargapokoktani = new javax.swing.JTextField();
        jLabel224 = new javax.swing.JLabel();
        jLabel222 = new javax.swing.JLabel();
        jLabel223 = new javax.swing.JLabel();
        jLabel225 = new javax.swing.JLabel();
        jRadioButton3 = new javax.swing.JRadioButton();
        jRadioButton4 = new javax.swing.JRadioButton();
        jPanel16 = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        jButton15 = new javax.swing.JButton();
        jLabel217 = new javax.swing.JLabel();
        hasiltani = new javax.swing.JTextField();
        jLabel218 = new javax.swing.JLabel();
        hasiltani1 = new javax.swing.JTextField();
        jButton16 = new javax.swing.JButton();
        Perdagangan_perhitungan = new javax.swing.JPanel();
        jLabel220 = new javax.swing.JLabel();
        jLabel226 = new javax.swing.JLabel();
        jLabel227 = new javax.swing.JLabel();
        jLabel228 = new javax.swing.JLabel();
        jLabel229 = new javax.swing.JLabel();
        jLabel231 = new javax.swing.JLabel();
        modaldagang = new javax.swing.JTextField();
        jLabel232 = new javax.swing.JLabel();
        bonusdagang = new javax.swing.JTextField();
        hasildagang = new javax.swing.JTextField();
        jButton17 = new javax.swing.JButton();
        jButton18 = new javax.swing.JButton();
        jLabel233 = new javax.swing.JLabel();
        jumlahlbrg = new javax.swing.JTextField();
        jLabel234 = new javax.swing.JLabel();
        jLabel235 = new javax.swing.JLabel();
        jLabel244 = new javax.swing.JLabel();
        hutangdagang = new javax.swing.JTextField();
        jLabel245 = new javax.swing.JLabel();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jPanel18 = new javax.swing.JPanel();
        jPanel19 = new javax.swing.JPanel();
        Profesi_perhitungan = new javax.swing.JPanel();
        jLabel221 = new javax.swing.JLabel();
        jLabel230 = new javax.swing.JLabel();
        jLabel236 = new javax.swing.JLabel();
        jLabel239 = new javax.swing.JLabel();
        gajiprofesi = new javax.swing.JTextField();
        jLabel240 = new javax.swing.JLabel();
        bonusprofesi = new javax.swing.JTextField();
        jLabel243 = new javax.swing.JLabel();
        jLabel246 = new javax.swing.JLabel();
        jLabel248 = new javax.swing.JLabel();
        jLabel249 = new javax.swing.JLabel();
        pengeluaranprofesi = new javax.swing.JTextField();
        jLabel251 = new javax.swing.JLabel();
        nishabprofesi = new javax.swing.JTextField();
        jPanel20 = new javax.swing.JPanel();
        jButton19 = new javax.swing.JButton();
        jLabel237 = new javax.swing.JLabel();
        jLabel238 = new javax.swing.JLabel();
        hasilprofesi1 = new javax.swing.JTextField();
        jButton20 = new javax.swing.JButton();
        Emas_syarat = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        Perak1_rukun = new javax.swing.JPanel();
        jLabel259 = new javax.swing.JLabel();
        jLabel260 = new javax.swing.JLabel();
        jLabel261 = new javax.swing.JLabel();
        jLabel262 = new javax.swing.JLabel();
        jLabel263 = new javax.swing.JLabel();
        jLabel264 = new javax.swing.JLabel();
        jLabel265 = new javax.swing.JLabel();
        jLabel266 = new javax.swing.JLabel();
        Kas_mesjid = new javax.swing.JButton();
        Kas_fitrah = new javax.swing.JButton();
        Data_masyarakat = new javax.swing.JButton();
        Pengertian = new javax.swing.JButton();
        Rukun = new javax.swing.JButton();
        Syarat = new javax.swing.JButton();
        Perhitungan = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel186 = new javax.swing.JLabel();
        tgl = new javax.swing.JLabel();
        jLabel190 = new javax.swing.JLabel();
        jLabel191 = new javax.swing.JLabel();
        jLabel192 = new javax.swing.JLabel();
        jLabel193 = new javax.swing.JLabel();
        jLabel194 = new javax.swing.JLabel();
        jLabel187 = new javax.swing.JLabel();
        jLabel252 = new javax.swing.JLabel();
        tgl1 = new javax.swing.JLabel();
        jLabel188 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();
        menu = new javax.swing.JPanel();
        Dkm = new javax.swing.JButton();
        Emas = new javax.swing.JButton();
        Perak = new javax.swing.JButton();
        Temuan = new javax.swing.JButton();
        Fitrah = new javax.swing.JButton();
        Galian = new javax.swing.JButton();
        Profesi = new javax.swing.JButton();
        Perdagangan = new javax.swing.JButton();
        Pertanian = new javax.swing.JButton();
        keluar = new javax.swing.JButton();

        Perak_rukun.setBackground(new java.awt.Color(0, 255, 255));

        jLabel43.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel43.setText("Rukun Zakat Perak");

        jLabel44.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel44.setText("1).  Pelepasan atau pengeluaran hak milik pada sebagaian");

        jLabel45.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel45.setText("3).  Penyerahan sebagian harta tersebut dari orang yang ");

        jLabel46.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel46.setText("2).  harta yang dikenakan wajib zakat");

        jLabel47.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel47.setText("4).  mempunyai harta kepada orang yang bertugas atau orang");

        jLabel48.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel48.setText("5).  yang mengurusi zakat (amil zakat). ");

        jLabel49.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel49.setText("6).  Penyerahan amil kepada orang yang berhak menerima ");

        jLabel50.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel50.setText("       zakat sebagai milik");

        javax.swing.GroupLayout Perak_rukunLayout = new javax.swing.GroupLayout(Perak_rukun);
        Perak_rukun.setLayout(Perak_rukunLayout);
        Perak_rukunLayout.setHorizontalGroup(
            Perak_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Perak_rukunLayout.createSequentialGroup()
                .addGroup(Perak_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Perak_rukunLayout.createSequentialGroup()
                        .addGap(373, 373, 373)
                        .addComponent(jLabel43))
                    .addGroup(Perak_rukunLayout.createSequentialGroup()
                        .addGap(300, 300, 300)
                        .addGroup(Perak_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel45)
                            .addComponent(jLabel44)
                            .addComponent(jLabel46)
                            .addComponent(jLabel49)
                            .addComponent(jLabel47)
                            .addComponent(jLabel48)
                            .addComponent(jLabel50))))
                .addContainerGap(544, Short.MAX_VALUE))
        );
        Perak_rukunLayout.setVerticalGroup(
            Perak_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Perak_rukunLayout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addComponent(jLabel43)
                .addGap(41, 41, 41)
                .addComponent(jLabel44)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel46)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel45)
                .addGap(13, 13, 13)
                .addComponent(jLabel47)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel48)
                .addGap(18, 18, 18)
                .addComponent(jLabel49)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel50)
                .addContainerGap(394, Short.MAX_VALUE))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(0, 204, 204));

        Wadah.setBackground(new java.awt.Color(0, 204, 255));
        Wadah.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));
        Wadah.setPreferredSize(new java.awt.Dimension(1167, 629));
        Wadah.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Wdkm.setBackground(new java.awt.Color(0, 255, 255));
        Wdkm.setPreferredSize(new java.awt.Dimension(1167, 629));

        PKas_m.setBackground(new java.awt.Color(0, 255, 255));
        PKas_m.setPreferredSize(new java.awt.Dimension(1347, 751));
        PKas_m.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        PKas_m.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, 561, 378));

        jLabel1.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel1.setText("Kas Mesjid");
        PKas_m.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 70, -1, -1));

        jLabel2.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel2.setText("Transaksi");
        PKas_m.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 60, -1, -1));

        jLabel3.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        jLabel3.setText("Tanggal Transaksi  :");
        PKas_m.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 110, -1, -1));

        jLabel4.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        jLabel4.setText("Keterangan              :");
        PKas_m.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 150, -1, -1));

        jLabel5.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        jLabel5.setText("Posisi                        :");
        PKas_m.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 190, -1, -1));

        Keterangan.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                KeteranganKeyTyped(evt);
            }
        });
        PKas_m.add(Keterangan, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 150, 196, 22));

        Jumlah.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                JumlahKeyTyped(evt);
            }
        });
        PKas_m.add(Jumlah, new org.netbeans.lib.awtextra.AbsoluteConstraints(846, 240, 160, 22));

        Ok.setText("Selesai");
        Ok.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Ok.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OkActionPerformed(evt);
            }
        });
        PKas_m.add(Ok, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 280, -1, 33));

        Tanggal.setDateFormatString("MMMM d,yyyyy");
        PKas_m.add(Tanggal, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 110, 196, -1));

        jPanel7.setBackground(new java.awt.Color(0, 255, 255));
        jPanel7.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        jRadioButton5.setBackground(new java.awt.Color(0, 255, 255));
        buttonGroup3.add(jRadioButton5);
        jRadioButton5.setText("Mengurangi Kas");

        jRadioButton6.setBackground(new java.awt.Color(0, 255, 255));
        buttonGroup3.add(jRadioButton6);
        jRadioButton6.setText("Menambah Kas");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addComponent(jRadioButton6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jRadioButton5)
                .addContainerGap(48, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addGap(0, 3, Short.MAX_VALUE)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jRadioButton5)
                    .addComponent(jRadioButton6)))
        );

        PKas_m.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 190, 250, 30));

        jPanel10.setBackground(new java.awt.Color(0, 255, 255));
        jPanel10.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        jLabel6.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        jLabel6.setText("Rp.");

        jLabel250.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        jLabel250.setText("Jumlah                     :");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel250)
                .addGap(18, 18, 18)
                .addComponent(jLabel6)
                .addContainerGap(219, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(0, 129, Short.MAX_VALUE)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(76, 76, 76))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel250)
                        .addGap(85, 85, 85))))
        );

        PKas_m.add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 100, 460, 240));

        jButton7.setBackground(new java.awt.Color(0, 255, 255));
        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/print.jpg"))); // NOI18N
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        PKas_m.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 70, 70, 50));

        jLabel242.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel242.setText("Print Data");
        PKas_m.add(jLabel242, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, 70, 20));

        PData.setBackground(new java.awt.Color(0, 255, 255));
        PData.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        PData.setPreferredSize(new java.awt.Dimension(1347, 751));
        PData.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                PDataFocusLost(evt);
            }
        });
        PData.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel8.setText("Data Masyarakat");
        PData.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 30, -1, -1));

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable3MouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jTable3);

        PData.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 132, 498, 370));

        jLabel9.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel9.setText("Tambah Data");
        PData.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(723, 21, -1, -1));

        jLabel10.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        jLabel10.setText("No Kartu Keluarga            :");
        PData.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(621, 62, -1, -1));

        tambahkk.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tambahkkKeyTyped(evt);
            }
        });
        PData.add(tambahkk, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 62, 175, 22));

        jLabel11.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        jLabel11.setText("Nama Kepala Keluarga     :");
        PData.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(621, 90, -1, -1));

        jLabel12.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        jLabel12.setText("Jumlah Seluruh Keluarga :");
        PData.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 126, -1, -1));

        tambahjumlah.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tambahjumlahKeyTyped(evt);
            }
        });
        PData.add(tambahjumlah, new org.netbeans.lib.awtextra.AbsoluteConstraints(859, 129, 175, 22));

        tambahkepala.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tambahkepalaKeyTyped(evt);
            }
        });
        PData.add(tambahkepala, new org.netbeans.lib.awtextra.AbsoluteConstraints(859, 93, 175, 22));

        Ok1.setText("Selesai");
        Ok1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Ok1.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                Ok1AncestorAdded(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        Ok1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Ok1ActionPerformed(evt);
            }
        });
        PData.add(Ok1, new org.netbeans.lib.awtextra.AbsoluteConstraints(966, 460, -1, -1));

        ubahjumlah.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                ubahjumlahKeyTyped(evt);
            }
        });
        PData.add(ubahjumlah, new org.netbeans.lib.awtextra.AbsoluteConstraints(819, 325, 216, 22));

        jLabel13.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        jLabel13.setText("Jumlah Seluruh Keluarga :");
        PData.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(586, 322, -1, -1));

        jLabel14.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        jLabel14.setText("Nama Kepala Keluarga     :");
        PData.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(587, 286, -1, -1));

        ubahkepala.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                ubahkepalaKeyTyped(evt);
            }
        });
        PData.add(ubahkepala, new org.netbeans.lib.awtextra.AbsoluteConstraints(819, 289, 216, 22));

        ubahkk.setEditable(false);
        ubahkk.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                ubahkkKeyTyped(evt);
            }
        });
        PData.add(ubahkk, new org.netbeans.lib.awtextra.AbsoluteConstraints(819, 253, 216, 22));

        jLabel15.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        jLabel15.setText("No Kartu Keluarga            :");
        PData.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(588, 250, -1, -1));

        jLabel16.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel16.setText("Ubah Data");
        PData.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 202, -1, -1));

        jLabel17.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel17.setText("Hapus Data");
        PData.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(739, 409, -1, -1));

        jLabel18.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        jLabel18.setText("No Kartu Keluarga     :");
        PData.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(583, 457, -1, -1));

        hapuskk.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                hapuskkKeyTyped(evt);
            }
        });
        PData.add(hapuskk, new org.netbeans.lib.awtextra.AbsoluteConstraints(785, 460, 175, 22));

        Ok4.setText("Selesai");
        Ok4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Ok4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Ok4ActionPerformed(evt);
            }
        });
        PData.add(Ok4, new org.netbeans.lib.awtextra.AbsoluteConstraints(969, 162, -1, -1));

        jPanel3.setBackground(new java.awt.Color(0, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 476, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 136, Short.MAX_VALUE)
        );

        PData.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 50, 480, 140));

        jPanel4.setBackground(new java.awt.Color(0, 255, 255));
        jPanel4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        Ok2.setText("Selesai");
        Ok2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Ok2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Ok2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(401, Short.MAX_VALUE)
                .addComponent(Ok2)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(112, Short.MAX_VALUE)
                .addComponent(Ok2)
                .addContainerGap())
        );

        PData.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 240, 480, 150));

        jPanel5.setBackground(new java.awt.Color(0, 255, 255));
        jPanel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 476, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 36, Short.MAX_VALUE)
        );

        PData.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 450, 480, 40));

        jPanel6.setBackground(new java.awt.Color(0, 255, 255));
        jPanel6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        jLabel253.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        jLabel253.setText("Cari  :");

        hapuskk1.addMouseWheelListener(new java.awt.event.MouseWheelListener() {
            public void mouseWheelMoved(java.awt.event.MouseWheelEvent evt) {
                hapuskk1MouseWheelMoved(evt);
            }
        });
        hapuskk1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hapuskk1ActionPerformed(evt);
            }
        });
        hapuskk1.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                hapuskk1PropertyChange(evt);
            }
        });
        hapuskk1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                hapuskk1KeyTyped(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel253)
                .addGap(14, 14, 14)
                .addComponent(hapuskk1, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(hapuskk1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel253, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        PData.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 80, 270, 40));

        jButton22.setBackground(new java.awt.Color(0, 255, 255));
        jButton22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/print.jpg"))); // NOI18N
        jButton22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton22ActionPerformed(evt);
            }
        });
        PData.add(jButton22, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 70, 50));

        jLabel247.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel247.setText("Print Data");
        PData.add(jLabel247, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, 70, 20));

        PKas_F.setBackground(new java.awt.Color(0, 255, 255));
        PKas_F.setPreferredSize(new java.awt.Dimension(1347, 751));
        PKas_F.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel7.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel7.setText("Kas Mesjid");
        PKas_F.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 60, -1, -1));

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        PKas_F.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, 575, 438));

        jPanel8.setBackground(new java.awt.Color(0, 255, 255));
        jPanel8.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        jLabel254.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        jLabel254.setForeground(new java.awt.Color(255, 255, 255));
        jLabel254.setText("Masukan No KK                     :");

        No_kk.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                No_kkKeyTyped(evt);
            }
        });

        jLabel255.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        jLabel255.setForeground(new java.awt.Color(255, 255, 255));
        jLabel255.setText("Nama Kepala Keluarga         :");

        kepala.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                kepalaKeyTyped(evt);
            }
        });

        jLabel256.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        jLabel256.setForeground(new java.awt.Color(255, 255, 255));
        jLabel256.setText("Jumlah Keluarga                  :");

        anggota.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                anggotaKeyTyped(evt);
            }
        });

        jLabel257.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        jLabel257.setForeground(new java.awt.Color(255, 255, 255));
        jLabel257.setText("Zakat Yang Harus Dibayar  :");

        jumlah.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jumlahKeyTyped(evt);
            }
        });

        jButton8.setText("Bayar");
        jButton8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jLabel258.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        jLabel258.setForeground(new java.awt.Color(255, 255, 255));
        jLabel258.setText("Tanggal Transaksi                 :");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addComponent(jLabel256)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(anggota, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                                .addComponent(jLabel257)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jumlah, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addComponent(jLabel258)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(Tanggal1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addComponent(jLabel255)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(kepala, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addComponent(jLabel254)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(No_kk, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(189, 189, 189)
                        .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel258)
                    .addComponent(Tanggal1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel254)
                    .addComponent(No_kk, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel255)
                    .addComponent(kepala, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(anggota, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel256))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel257)
                    .addComponent(jumlah, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        PKas_F.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(599, 77, -1, -1));

        jPanel9.setBackground(new java.awt.Color(0, 255, 255));
        jPanel9.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        jLabel268.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        jLabel268.setForeground(new java.awt.Color(255, 255, 255));
        jLabel268.setText("Masukan No KK                     :");

        No_kk1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                No_kk1KeyTyped(evt);
            }
        });

        jLabel269.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        jLabel269.setForeground(new java.awt.Color(255, 255, 255));
        jLabel269.setText("Nama Kepala Keluarga         :");

        kepala1.setEditable(false);
        kepala1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                kepala1KeyTyped(evt);
            }
        });

        jLabel270.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        jLabel270.setForeground(new java.awt.Color(255, 255, 255));
        jLabel270.setText("Jumlah Keluarga                  :");

        anggota1.setEditable(false);
        anggota1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                anggota1KeyTyped(evt);
            }
        });

        jLabel271.setFont(new java.awt.Font("Century", 0, 18)); // NOI18N
        jLabel271.setForeground(new java.awt.Color(255, 255, 255));
        jLabel271.setText("Zakat Yang Harus Dibayar  :");

        jumlah1.setEditable(false);
        jumlah1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jumlah1KeyTyped(evt);
            }
        });

        jButton21.setText("Bayar");
        jButton21.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton21ActionPerformed(evt);
            }
        });

        jTable5.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane5.setViewportView(jTable5);

        jButton1.setText("Cari");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(jPanel9Layout.createSequentialGroup()
                                    .addComponent(jLabel270)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(anggota1, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                                    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jButton21, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel271))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(jumlah1, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel9Layout.createSequentialGroup()
                                .addComponent(jLabel269)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(kepala1, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(jLabel268)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(No_kk1, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton1)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(69, 69, 69)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel268)
                            .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(No_kk1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton1)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel269)
                            .addComponent(kepala1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(anggota1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel270))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel271)
                            .addComponent(jumlah1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton21, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        PKas_F.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(599, 335, -1, -1));

        jLabel267.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel267.setForeground(new java.awt.Color(255, 255, 255));
        jLabel267.setText("Tambah Saldo Fitrah");
        PKas_F.add(jLabel267, new org.netbeans.lib.awtextra.AbsoluteConstraints(714, 299, -1, -1));

        jLabel176.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel176.setForeground(new java.awt.Color(255, 255, 255));
        jLabel176.setText("Pembagian Fitrah");
        PKas_F.add(jLabel176, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 36, -1, -1));

        jButton2.setBackground(new java.awt.Color(0, 255, 255));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/print.jpg"))); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        PKas_F.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 50, 70, 50));

        jLabel241.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel241.setText("Print Data");
        PKas_F.add(jLabel241, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 30, 70, 20));

        Emas_perhitungan.setBackground(new java.awt.Color(0, 255, 255));
        Emas_perhitungan.setPreferredSize(new java.awt.Dimension(1347, 751));
        Emas_perhitungan.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel19.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel19.setText("Perhitungan Zakat Emas");
        Emas_perhitungan.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(373, 67, -1, -1));

        jLabel20.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel20.setText("Masukan Berat Emas               :");
        Emas_perhitungan.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(303, 148, -1, -1));

        jLabel21.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel21.setText("Nishab Emas                         :");
        Emas_perhitungan.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(303, 183, -1, -1));

        jLabel22.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel22.setText("Masukan Harga Emas Pergram  :");
        Emas_perhitungan.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(303, 213, -1, -1));

        jLabel174.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel174.setText("/gram");
        Emas_perhitungan.add(jLabel174, new org.netbeans.lib.awtextra.AbsoluteConstraints(735, 148, -1, -1));

        berat.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                beratKeyTyped(evt);
            }
        });
        Emas_perhitungan.add(berat, new org.netbeans.lib.awtextra.AbsoluteConstraints(609, 152, 116, -1));

        jLabel175.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel175.setText("Rp.");
        Emas_perhitungan.add(jLabel175, new org.netbeans.lib.awtextra.AbsoluteConstraints(579, 213, -1, -1));

        harga.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                hargaKeyTyped(evt);
            }
        });
        Emas_perhitungan.add(harga, new org.netbeans.lib.awtextra.AbsoluteConstraints(609, 217, 173, -1));

        nishab.setEditable(false);
        nishab.setText("85");
        nishab.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        Emas_perhitungan.add(nishab, new org.netbeans.lib.awtextra.AbsoluteConstraints(608, 187, 117, -1));

        jLabel185.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel185.setText("/gram");
        Emas_perhitungan.add(jLabel185, new org.netbeans.lib.awtextra.AbsoluteConstraints(735, 183, -1, -1));

        jPanel11.setBackground(new java.awt.Color(0, 255, 255));
        jPanel11.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        jButton3.setText("Hitung");
        jButton3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel172.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel172.setText("Jumlah Zakat Yang Harus Dibayar");

        hasilgram.setEditable(false);

        jLabel173.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel173.setText("gram / Rp.");

        hasilrupiah.setEditable(false);

        jButton4.setText("Hitung Kembali");
        jButton4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap(128, Short.MAX_VALUE)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                        .addComponent(jButton3)
                        .addGap(239, 239, 239))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                        .addComponent(jLabel172)
                        .addGap(131, 131, 131))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                        .addComponent(hasilgram, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(4, 4, 4)
                        .addComponent(jLabel173)
                        .addGap(10, 10, 10)
                        .addComponent(hasilrupiah, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(64, 64, 64))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                        .addComponent(jButton4)
                        .addGap(213, 213, 213))))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(147, 147, 147)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel172)
                .addGap(18, 18, 18)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel173)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(hasilgram, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(hasilrupiah, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(29, Short.MAX_VALUE))
        );

        Emas_perhitungan.add(jPanel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 120, 550, 340));

        Emas_rukun.setBackground(new java.awt.Color(0, 255, 255));

        jLabel31.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel31.setText("Rukun Zakat Emas");

        jLabel32.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel32.setText("1).  Pelepasan atau pengeluaran hak milik pada sebagaian");

        jLabel33.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel33.setText("3).  Penyerahan sebagian harta tersebut dari orang yang ");

        jLabel34.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel34.setText("2).  harta yang dikenakan wajib zakat");

        jLabel35.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel35.setText("4).  mempunyai harta kepada orang yang bertugas atau orang");

        jLabel36.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel36.setText("5).  yang mengurusi zakat (amil zakat). ");

        jLabel37.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel37.setText("6).  Penyerahan amil kepada orang yang berhak menerima ");

        jLabel38.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel38.setText("       zakat sebagai milik");

        javax.swing.GroupLayout Emas_rukunLayout = new javax.swing.GroupLayout(Emas_rukun);
        Emas_rukun.setLayout(Emas_rukunLayout);
        Emas_rukunLayout.setHorizontalGroup(
            Emas_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Emas_rukunLayout.createSequentialGroup()
                .addGroup(Emas_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Emas_rukunLayout.createSequentialGroup()
                        .addGap(373, 373, 373)
                        .addComponent(jLabel31))
                    .addGroup(Emas_rukunLayout.createSequentialGroup()
                        .addGap(300, 300, 300)
                        .addGroup(Emas_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel33)
                            .addComponent(jLabel32)
                            .addComponent(jLabel34)
                            .addComponent(jLabel37)
                            .addComponent(jLabel35)
                            .addComponent(jLabel36)
                            .addComponent(jLabel38))))
                .addContainerGap(374, Short.MAX_VALUE))
        );
        Emas_rukunLayout.setVerticalGroup(
            Emas_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Emas_rukunLayout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addComponent(jLabel31)
                .addGap(41, 41, 41)
                .addComponent(jLabel32)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel34)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel33)
                .addGap(13, 13, 13)
                .addComponent(jLabel35)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel36)
                .addGap(18, 18, 18)
                .addComponent(jLabel37)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel38)
                .addContainerGap(368, Short.MAX_VALUE))
        );

        Perak_pengertian.setBackground(new java.awt.Color(0, 255, 255));
        Perak_pengertian.setPreferredSize(new java.awt.Dimension(1347, 751));

        jLabel39.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel39.setText("Pengertian Zakat Perak");

        jLabel40.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel40.setText("zakat yang wajib dikeluarkan oleh seorang yang mempunyai perak");

        jLabel42.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel42.setText(" dan apabila telah mencapai nisab dan haul.");

        javax.swing.GroupLayout Perak_pengertianLayout = new javax.swing.GroupLayout(Perak_pengertian);
        Perak_pengertian.setLayout(Perak_pengertianLayout);
        Perak_pengertianLayout.setHorizontalGroup(
            Perak_pengertianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Perak_pengertianLayout.createSequentialGroup()
                .addGroup(Perak_pengertianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Perak_pengertianLayout.createSequentialGroup()
                        .addGap(303, 303, 303)
                        .addGroup(Perak_pengertianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel40)
                            .addComponent(jLabel42)))
                    .addGroup(Perak_pengertianLayout.createSequentialGroup()
                        .addGap(378, 378, 378)
                        .addComponent(jLabel39)))
                .addContainerGap(330, Short.MAX_VALUE))
        );
        Perak_pengertianLayout.setVerticalGroup(
            Perak_pengertianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Perak_pengertianLayout.createSequentialGroup()
                .addGap(83, 83, 83)
                .addComponent(jLabel39)
                .addGap(35, 35, 35)
                .addComponent(jLabel40)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel42)
                .addContainerGap(522, Short.MAX_VALUE))
        );

        Perak_syarat.setBackground(new java.awt.Color(0, 255, 255));
        Perak_syarat.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel41.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel41.setText("Syarat Zakat Perak");
        Perak_syarat.add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(375, 76, -1, -1));

        jLabel51.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel51.setText("1.      Milik orang islam");
        Perak_syarat.add(jLabel51, new org.netbeans.lib.awtextra.AbsoluteConstraints(303, 148, -1, -1));

        jLabel52.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel52.setText("3.      Mencapai nishab");
        Perak_syarat.add(jLabel52, new org.netbeans.lib.awtextra.AbsoluteConstraints(303, 214, -1, -1));

        jLabel53.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel53.setText("2.      Mencapai haul");
        Perak_syarat.add(jLabel53, new org.netbeans.lib.awtextra.AbsoluteConstraints(303, 181, -1, -1));

        jLabel54.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel54.setText("4.      Besar zakat 2,5 %");
        Perak_syarat.add(jLabel54, new org.netbeans.lib.awtextra.AbsoluteConstraints(303, 249, -1, -1));

        jLabel55.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel55.setText("5.      Harus berupa emas murni atau perak murni (24K/99%), bukan campuran. ");
        Perak_syarat.add(jLabel55, new org.netbeans.lib.awtextra.AbsoluteConstraints(303, 282, -1, -1));

        jLabel56.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel56.setText("          Jika campuran, walaupun mencapai nishob,maka tidak ada kewajiban zakatnya,");
        Perak_syarat.add(jLabel56, new org.netbeans.lib.awtextra.AbsoluteConstraints(303, 322, -1, -1));

        jLabel57.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel57.setText("          sebab berat aslinya kurang dari itu.");
        Perak_syarat.add(jLabel57, new org.netbeans.lib.awtextra.AbsoluteConstraints(303, 355, -1, -1));

        Temuan_pengertian.setBackground(new java.awt.Color(0, 255, 255));
        Temuan_pengertian.setPreferredSize(new java.awt.Dimension(1347, 751));

        jLabel58.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel58.setText("Pengertian Zakat Barang Temuan");

        jLabel59.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel59.setText("Zakat barang temuan (rikaz) adalah zakat yang wajib dikeluarkan ");

        jLabel60.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel60.setText("yang biasa disebut dengan harta karun. Zakat barang temuan");

        jLabel61.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel61.setText("untuk barang yang ditemukan terpendam di dalam tanah, atau ");

        jLabel62.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel62.setText("(jumlah minimal untuk terkena kewajiban zakat), sementara kadar");

        jLabel63.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel63.setText("tidak mensyaratkan baik haul (lama penyimpanan) maupun nisab ");

        jLabel64.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel64.setText("zakatnya adalah sebesar seperlima atau 20% dari jumlah harta yang");

        jLabel65.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel65.setText("besarnya, wajib dikeluarkan zakatnya sebesar seperlima dari besar ");

        jLabel66.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel66.setText("ditemukan. Jadi setiap mendapatkan harta temuan berapapun");

        jLabel67.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel67.setText("total harta tersebut.");

        javax.swing.GroupLayout Temuan_pengertianLayout = new javax.swing.GroupLayout(Temuan_pengertian);
        Temuan_pengertian.setLayout(Temuan_pengertianLayout);
        Temuan_pengertianLayout.setHorizontalGroup(
            Temuan_pengertianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Temuan_pengertianLayout.createSequentialGroup()
                .addGroup(Temuan_pengertianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Temuan_pengertianLayout.createSequentialGroup()
                        .addGap(377, 377, 377)
                        .addComponent(jLabel58))
                    .addGroup(Temuan_pengertianLayout.createSequentialGroup()
                        .addGap(345, 345, 345)
                        .addGroup(Temuan_pengertianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel60)
                            .addComponent(jLabel59)
                            .addComponent(jLabel61)
                            .addComponent(jLabel64)
                            .addComponent(jLabel63)
                            .addComponent(jLabel62)
                            .addComponent(jLabel67)
                            .addComponent(jLabel66)
                            .addComponent(jLabel65))))
                .addContainerGap(273, Short.MAX_VALUE))
        );
        Temuan_pengertianLayout.setVerticalGroup(
            Temuan_pengertianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Temuan_pengertianLayout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addComponent(jLabel58)
                .addGap(40, 40, 40)
                .addComponent(jLabel59)
                .addGap(4, 4, 4)
                .addComponent(jLabel61)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel60)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel63)
                .addGap(4, 4, 4)
                .addComponent(jLabel62)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel64)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel66)
                .addGap(4, 4, 4)
                .addComponent(jLabel65)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel67)
                .addContainerGap(367, Short.MAX_VALUE))
        );

        Temuan_rukun.setBackground(new java.awt.Color(0, 255, 255));
        Temuan_rukun.setPreferredSize(new java.awt.Dimension(1347, 751));

        jLabel68.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel68.setText("Rukun Zakat Barang Temuan");

        jLabel69.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel69.setText("a) Niat untuk menunaikan zakat dengan ikhlas,semata-mata karena Allah swt. ");

        jLabel70.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel70.setText("c) Ada orang yang menerima zakat ");

        jLabel71.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel71.setText("b) Ada orang yang menunaikan zakat ");

        jLabel72.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel72.setText("d) Ada barang atau makanan pokok yang dizakatkan");

        javax.swing.GroupLayout Temuan_rukunLayout = new javax.swing.GroupLayout(Temuan_rukun);
        Temuan_rukun.setLayout(Temuan_rukunLayout);
        Temuan_rukunLayout.setHorizontalGroup(
            Temuan_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Temuan_rukunLayout.createSequentialGroup()
                .addGroup(Temuan_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Temuan_rukunLayout.createSequentialGroup()
                        .addGap(373, 373, 373)
                        .addComponent(jLabel68))
                    .addGroup(Temuan_rukunLayout.createSequentialGroup()
                        .addGap(300, 300, 300)
                        .addGroup(Temuan_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel70)
                            .addComponent(jLabel69)
                            .addComponent(jLabel71)
                            .addComponent(jLabel72))))
                .addContainerGap(238, Short.MAX_VALUE))
        );
        Temuan_rukunLayout.setVerticalGroup(
            Temuan_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Temuan_rukunLayout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addComponent(jLabel68)
                .addGap(41, 41, 41)
                .addComponent(jLabel69)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel71)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel70)
                .addGap(13, 13, 13)
                .addComponent(jLabel72)
                .addContainerGap(463, Short.MAX_VALUE))
        );

        Temuan_syarat.setBackground(new java.awt.Color(0, 255, 255));
        Temuan_syarat.setPreferredSize(new java.awt.Dimension(1347, 751));

        jLabel76.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel76.setText("Syarat Zakat Barang Temuan");

        jLabel77.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel77.setText("1)     Harta itu terpendam di tanah hak miliknya");

        jLabel78.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel78.setText("         Jahiliyyah dengan ciri-ciri tertentu, jika harta");

        jLabel79.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel79.setText("2)     Benda yang terpendam harus benda pusaka");

        jLabel80.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel80.setText("         terpendam itu berupa benda pusaka muslimin");

        jLabel81.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel81.setText("         maka wajib diserahkan ke Baitulmal");

        javax.swing.GroupLayout Temuan_syaratLayout = new javax.swing.GroupLayout(Temuan_syarat);
        Temuan_syarat.setLayout(Temuan_syaratLayout);
        Temuan_syaratLayout.setHorizontalGroup(
            Temuan_syaratLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Temuan_syaratLayout.createSequentialGroup()
                .addGap(375, 375, 375)
                .addGroup(Temuan_syaratLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel78)
                    .addComponent(jLabel77)
                    .addComponent(jLabel79)
                    .addComponent(jLabel80)
                    .addComponent(jLabel81)
                    .addComponent(jLabel76))
                .addContainerGap(367, Short.MAX_VALUE))
        );
        Temuan_syaratLayout.setVerticalGroup(
            Temuan_syaratLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Temuan_syaratLayout.createSequentialGroup()
                .addGap(66, 66, 66)
                .addComponent(jLabel76)
                .addGap(44, 44, 44)
                .addComponent(jLabel77)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel79)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel78)
                .addGap(13, 13, 13)
                .addComponent(jLabel80)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel81)
                .addContainerGap(418, Short.MAX_VALUE))
        );

        Fitrah_rukun.setBackground(new java.awt.Color(0, 255, 255));
        Fitrah_rukun.setPreferredSize(new java.awt.Dimension(1347, 751));

        jLabel73.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel73.setText("Rukun Zakat Fitrah");

        jLabel82.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel82.setText("1. Niat untuk menunaikan zakat fitrah dengan");

        jLabel83.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel83.setText("2. Terdapat pemberi zakat fitrah atau musakki");

        jLabel84.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel84.setText("    ikhlas semata-mata karena Allah SWT");

        jLabel85.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel85.setText("3. Terdapat penerima zakat fitrah atau mustahik");

        jLabel86.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel86.setText("5. Besar zakat fitrah yang dikeluarkan sesuai agama islam ");

        jLabel87.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel87.setText("4. Terdapat makanan pokok yang dizakatkan");

        javax.swing.GroupLayout Fitrah_rukunLayout = new javax.swing.GroupLayout(Fitrah_rukun);
        Fitrah_rukun.setLayout(Fitrah_rukunLayout);
        Fitrah_rukunLayout.setHorizontalGroup(
            Fitrah_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Fitrah_rukunLayout.createSequentialGroup()
                .addGroup(Fitrah_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Fitrah_rukunLayout.createSequentialGroup()
                        .addGap(373, 373, 373)
                        .addComponent(jLabel73))
                    .addGroup(Fitrah_rukunLayout.createSequentialGroup()
                        .addGap(303, 303, 303)
                        .addGroup(Fitrah_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel83)
                            .addComponent(jLabel82)
                            .addComponent(jLabel84)
                            .addComponent(jLabel86)
                            .addComponent(jLabel85)
                            .addComponent(jLabel87))))
                .addContainerGap(393, Short.MAX_VALUE))
        );
        Fitrah_rukunLayout.setVerticalGroup(
            Fitrah_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Fitrah_rukunLayout.createSequentialGroup()
                .addGap(67, 67, 67)
                .addComponent(jLabel73)
                .addGap(51, 51, 51)
                .addComponent(jLabel82)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel84)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel83)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel85)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel87)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel86)
                .addContainerGap(395, Short.MAX_VALUE))
        );

        Fitrah_syarat.setBackground(new java.awt.Color(0, 255, 255));
        Fitrah_syarat.setPreferredSize(new java.awt.Dimension(1347, 751));

        jLabel74.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel74.setText("Syarat Zakat Fitrah");

        jLabel75.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel75.setText("1. Orang Islam. sedangkan bagi orang yang bukan islam ");

        jLabel88.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel88.setText("2. Membayar zakat fitrah dilaksanakan setelah terbenamnya");

        jLabel89.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel89.setText("     tidak diwajibkan");

        jLabel90.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel90.setText("    matahari dari bulan ramadhan sampai akhir bulan ramadan. ");

        jLabel91.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel91.setText("3. Memiliki harta yang berlebih dengan ketentuan kelebihan ");

        jLabel92.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel92.setText("     harta untuk dirinya sendiri dan untuk keluarganya. Sedangkan");

        jLabel93.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel93.setText("     bagi yang kekurangan tidak diwajibkan untuk membayar zakat ");

        jLabel94.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel94.setText("fitrah");

        javax.swing.GroupLayout Fitrah_syaratLayout = new javax.swing.GroupLayout(Fitrah_syarat);
        Fitrah_syarat.setLayout(Fitrah_syaratLayout);
        Fitrah_syaratLayout.setHorizontalGroup(
            Fitrah_syaratLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Fitrah_syaratLayout.createSequentialGroup()
                .addGroup(Fitrah_syaratLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Fitrah_syaratLayout.createSequentialGroup()
                        .addGap(303, 303, 303)
                        .addGroup(Fitrah_syaratLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel88)
                            .addComponent(jLabel75)
                            .addComponent(jLabel89)
                            .addComponent(jLabel90)
                            .addComponent(jLabel91)))
                    .addGroup(Fitrah_syaratLayout.createSequentialGroup()
                        .addGap(375, 375, 375)
                        .addComponent(jLabel74))
                    .addGroup(Fitrah_syaratLayout.createSequentialGroup()
                        .addGap(292, 292, 292)
                        .addGroup(Fitrah_syaratLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel93)
                            .addComponent(jLabel92)
                            .addGroup(Fitrah_syaratLayout.createSequentialGroup()
                                .addGap(27, 27, 27)
                                .addComponent(jLabel94)))))
                .addContainerGap(336, Short.MAX_VALUE))
        );
        Fitrah_syaratLayout.setVerticalGroup(
            Fitrah_syaratLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Fitrah_syaratLayout.createSequentialGroup()
                .addGap(76, 76, 76)
                .addComponent(jLabel74)
                .addGap(42, 42, 42)
                .addComponent(jLabel75)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel89)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel88)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel90)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel91)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel92)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel93)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel94)
                .addContainerGap(328, Short.MAX_VALUE))
        );

        Fitrah_pengertian.setBackground(new java.awt.Color(0, 255, 255));
        Fitrah_pengertian.setPreferredSize(new java.awt.Dimension(1347, 751));

        jLabel95.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel95.setText("Pengertian Zakat Fitrah");

        jLabel96.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel96.setText("   Zakat Fitrah adalah zakat yang wajib dikeluarkan umat Islam baik");

        jLabel97.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel97.setText("dan muda, pada awal bulan ramadhan sampai menjelang idul fitri.");

        jLabel98.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel98.setText("laki-laki, perempuan, besar atau kecil, merdeka atau budak, tua ");

        javax.swing.GroupLayout Fitrah_pengertianLayout = new javax.swing.GroupLayout(Fitrah_pengertian);
        Fitrah_pengertian.setLayout(Fitrah_pengertianLayout);
        Fitrah_pengertianLayout.setHorizontalGroup(
            Fitrah_pengertianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Fitrah_pengertianLayout.createSequentialGroup()
                .addGroup(Fitrah_pengertianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Fitrah_pengertianLayout.createSequentialGroup()
                        .addGap(373, 373, 373)
                        .addComponent(jLabel95))
                    .addGroup(Fitrah_pengertianLayout.createSequentialGroup()
                        .addGap(303, 303, 303)
                        .addGroup(Fitrah_pengertianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel97)
                            .addComponent(jLabel96)
                            .addComponent(jLabel98))))
                .addContainerGap(320, Short.MAX_VALUE))
        );
        Fitrah_pengertianLayout.setVerticalGroup(
            Fitrah_pengertianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Fitrah_pengertianLayout.createSequentialGroup()
                .addGap(67, 67, 67)
                .addComponent(jLabel95)
                .addGap(51, 51, 51)
                .addComponent(jLabel96)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel98)
                .addGap(18, 18, 18)
                .addComponent(jLabel97)
                .addContainerGap(482, Short.MAX_VALUE))
        );

        Galian_pengertian.setBackground(new java.awt.Color(0, 255, 255));
        Galian_pengertian.setPreferredSize(new java.awt.Dimension(1347, 751));

        jLabel99.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel99.setText("Pengertian Zakat Galian");

        jLabel100.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel100.setText(" Barang galian atau rikaz ialah harta karun yang dipendam ");

        jLabel101.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel101.setText("disyaratkan haul dan nisab. ");

        jLabel102.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel102.setText("di bawah tanah yang dalam kewajiban zakatnya tidak ");

        javax.swing.GroupLayout Galian_pengertianLayout = new javax.swing.GroupLayout(Galian_pengertian);
        Galian_pengertian.setLayout(Galian_pengertianLayout);
        Galian_pengertianLayout.setHorizontalGroup(
            Galian_pengertianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Galian_pengertianLayout.createSequentialGroup()
                .addGroup(Galian_pengertianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Galian_pengertianLayout.createSequentialGroup()
                        .addGap(373, 373, 373)
                        .addComponent(jLabel99))
                    .addGroup(Galian_pengertianLayout.createSequentialGroup()
                        .addGap(303, 303, 303)
                        .addGroup(Galian_pengertianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel101)
                            .addComponent(jLabel100)
                            .addComponent(jLabel102))))
                .addContainerGap(388, Short.MAX_VALUE))
        );
        Galian_pengertianLayout.setVerticalGroup(
            Galian_pengertianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Galian_pengertianLayout.createSequentialGroup()
                .addGap(67, 67, 67)
                .addComponent(jLabel99)
                .addGap(51, 51, 51)
                .addComponent(jLabel100)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel102)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel101)
                .addContainerGap(478, Short.MAX_VALUE))
        );

        Galian_rukun.setBackground(new java.awt.Color(0, 255, 255));
        Galian_rukun.setPreferredSize(new java.awt.Dimension(1347, 751));

        jLabel103.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel103.setText("Rukun Zakat Galian");

        jLabel104.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel104.setText("a) Niat untuk menunaikan zakat dengan ikhlas,semata-mata karena Allah swt. ");

        jLabel105.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel105.setText("c) Ada orang yang menerima zakat  ");

        jLabel106.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel106.setText("b) Ada orang yang menunaikan zakat ");

        jLabel107.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel107.setText("d) Ada barang atau makanan pokok yang dizakatkan");

        javax.swing.GroupLayout Galian_rukunLayout = new javax.swing.GroupLayout(Galian_rukun);
        Galian_rukun.setLayout(Galian_rukunLayout);
        Galian_rukunLayout.setHorizontalGroup(
            Galian_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Galian_rukunLayout.createSequentialGroup()
                .addGroup(Galian_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Galian_rukunLayout.createSequentialGroup()
                        .addGap(373, 373, 373)
                        .addComponent(jLabel103))
                    .addGroup(Galian_rukunLayout.createSequentialGroup()
                        .addGap(300, 300, 300)
                        .addGroup(Galian_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel105)
                            .addComponent(jLabel104)
                            .addComponent(jLabel106)
                            .addComponent(jLabel107))))
                .addContainerGap(238, Short.MAX_VALUE))
        );
        Galian_rukunLayout.setVerticalGroup(
            Galian_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Galian_rukunLayout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addComponent(jLabel103)
                .addGap(41, 41, 41)
                .addComponent(jLabel104)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel106)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel105)
                .addGap(13, 13, 13)
                .addComponent(jLabel107)
                .addContainerGap(463, Short.MAX_VALUE))
        );

        Galian_syarat.setBackground(new java.awt.Color(0, 255, 255));
        Galian_syarat.setPreferredSize(new java.awt.Dimension(1347, 751));

        jLabel111.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel111.setText("Syarat Zakat Barang Galian");

        jLabel112.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel112.setText("1)     Harta itu terpendam di tanah hak miliknya");

        jLabel113.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel113.setText("         dengan ciri-ciri tertentu, jika harta terpendam itu berupa ");

        jLabel114.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel114.setText("2)     Benda yang terpendam harus benda pusaka Jahiliyyah");

        jLabel115.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel115.setText("         benda pusaka muslimin maka wajib diserahkan ke Baitulmal");

        javax.swing.GroupLayout Galian_syaratLayout = new javax.swing.GroupLayout(Galian_syarat);
        Galian_syarat.setLayout(Galian_syaratLayout);
        Galian_syaratLayout.setHorizontalGroup(
            Galian_syaratLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Galian_syaratLayout.createSequentialGroup()
                .addGroup(Galian_syaratLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Galian_syaratLayout.createSequentialGroup()
                        .addGap(303, 303, 303)
                        .addGroup(Galian_syaratLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel113)
                            .addComponent(jLabel112)
                            .addComponent(jLabel114)
                            .addComponent(jLabel115)))
                    .addGroup(Galian_syaratLayout.createSequentialGroup()
                        .addGap(375, 375, 375)
                        .addComponent(jLabel111)))
                .addContainerGap(328, Short.MAX_VALUE))
        );
        Galian_syaratLayout.setVerticalGroup(
            Galian_syaratLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Galian_syaratLayout.createSequentialGroup()
                .addGap(76, 76, 76)
                .addComponent(jLabel111)
                .addGap(42, 42, 42)
                .addComponent(jLabel112)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel114)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel113)
                .addGap(13, 13, 13)
                .addComponent(jLabel115)
                .addContainerGap(443, Short.MAX_VALUE))
        );

        Profesi_pengertian.setBackground(new java.awt.Color(0, 255, 255));
        Profesi_pengertian.setPreferredSize(new java.awt.Dimension(1347, 751));

        jLabel108.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel108.setText("Pengertian Zakat Profesi");

        jLabel109.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel109.setText("Zakat Profesi adalah zakat yang dikeluarkan dari penghasilan profesi ");

        jLabel110.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel110.setText("pegawai negeri atau swasta, konsultan, dokter, notaris, akuntan, artis,");

        jLabel116.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel116.setText("(hasil profesi) bila telah mencapai nisab. Profesi tersebut misalnya ");

        jLabel133.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel133.setText("dan wiraswasta.");

        javax.swing.GroupLayout Profesi_pengertianLayout = new javax.swing.GroupLayout(Profesi_pengertian);
        Profesi_pengertian.setLayout(Profesi_pengertianLayout);
        Profesi_pengertianLayout.setHorizontalGroup(
            Profesi_pengertianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Profesi_pengertianLayout.createSequentialGroup()
                .addGroup(Profesi_pengertianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Profesi_pengertianLayout.createSequentialGroup()
                        .addGap(373, 373, 373)
                        .addComponent(jLabel108))
                    .addGroup(Profesi_pengertianLayout.createSequentialGroup()
                        .addGap(303, 303, 303)
                        .addGroup(Profesi_pengertianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel110)
                            .addComponent(jLabel109)
                            .addComponent(jLabel116)
                            .addComponent(jLabel133))))
                .addContainerGap(302, Short.MAX_VALUE))
        );
        Profesi_pengertianLayout.setVerticalGroup(
            Profesi_pengertianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Profesi_pengertianLayout.createSequentialGroup()
                .addGap(67, 67, 67)
                .addComponent(jLabel108)
                .addGap(51, 51, 51)
                .addComponent(jLabel109)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel116)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel110)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel133)
                .addContainerGap(450, Short.MAX_VALUE))
        );

        Profesi_syarat.setBackground(new java.awt.Color(0, 255, 255));
        Profesi_syarat.setPreferredSize(new java.awt.Dimension(1347, 751));

        jLabel117.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel117.setText("Syarat Zakat Profesi");

        jLabel118.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel118.setText("a.      Islam");

        jLabel119.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel119.setText("c.      Berakal dan balig");

        jLabel120.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel120.setText("b.      Merdeka");

        jLabel121.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel121.setText("d.      Memiliki nisab");

        javax.swing.GroupLayout Profesi_syaratLayout = new javax.swing.GroupLayout(Profesi_syarat);
        Profesi_syarat.setLayout(Profesi_syaratLayout);
        Profesi_syaratLayout.setHorizontalGroup(
            Profesi_syaratLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Profesi_syaratLayout.createSequentialGroup()
                .addGroup(Profesi_syaratLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Profesi_syaratLayout.createSequentialGroup()
                        .addGap(303, 303, 303)
                        .addGroup(Profesi_syaratLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel119)
                            .addComponent(jLabel118)
                            .addComponent(jLabel120)
                            .addComponent(jLabel121)))
                    .addGroup(Profesi_syaratLayout.createSequentialGroup()
                        .addGap(375, 375, 375)
                        .addComponent(jLabel117)))
                .addContainerGap(532, Short.MAX_VALUE))
        );
        Profesi_syaratLayout.setVerticalGroup(
            Profesi_syaratLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Profesi_syaratLayout.createSequentialGroup()
                .addGap(76, 76, 76)
                .addComponent(jLabel117)
                .addGap(42, 42, 42)
                .addComponent(jLabel118)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel120)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel119)
                .addGap(13, 13, 13)
                .addComponent(jLabel121)
                .addContainerGap(443, Short.MAX_VALUE))
        );

        Profesi_rukun.setBackground(new java.awt.Color(0, 255, 255));
        Profesi_rukun.setPreferredSize(new java.awt.Dimension(1347, 751));

        jLabel125.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel125.setText("Rukun Zakat Profesi");

        jLabel126.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel126.setText("1. Pelepasan atau pengeluaran hak milik pada sebagaian harta");

        jLabel127.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel127.setText("2. Penyerahan sebagian harta tersebut dari orang yang mempunyai");

        jLabel128.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel128.setText("    yang dikenakan wajib zakat");

        jLabel129.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel129.setText("    harta kepada orang yang bertugas atau orang yang mengurusi ");

        jLabel130.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel130.setText("     zakat (amil zakat). ");

        jLabel131.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel131.setText("3. Penyerahan amil kepada orang yang berhak menerima zakat ");

        jLabel132.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel132.setText("    sebagai milik.");

        javax.swing.GroupLayout Profesi_rukunLayout = new javax.swing.GroupLayout(Profesi_rukun);
        Profesi_rukun.setLayout(Profesi_rukunLayout);
        Profesi_rukunLayout.setHorizontalGroup(
            Profesi_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Profesi_rukunLayout.createSequentialGroup()
                .addGroup(Profesi_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Profesi_rukunLayout.createSequentialGroup()
                        .addGap(373, 373, 373)
                        .addComponent(jLabel125))
                    .addGroup(Profesi_rukunLayout.createSequentialGroup()
                        .addGap(300, 300, 300)
                        .addGroup(Profesi_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel127)
                            .addComponent(jLabel126)
                            .addComponent(jLabel128)
                            .addComponent(jLabel131)
                            .addComponent(jLabel129)
                            .addComponent(jLabel130)
                            .addComponent(jLabel132))))
                .addContainerGap(327, Short.MAX_VALUE))
        );
        Profesi_rukunLayout.setVerticalGroup(
            Profesi_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Profesi_rukunLayout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addComponent(jLabel125)
                .addGap(41, 41, 41)
                .addComponent(jLabel126)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel128)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel127)
                .addGap(13, 13, 13)
                .addComponent(jLabel129)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel130)
                .addGap(18, 18, 18)
                .addComponent(jLabel131)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel132)
                .addContainerGap(357, Short.MAX_VALUE))
        );

        Perdagangan_pengertian.setBackground(new java.awt.Color(0, 255, 255));
        Perdagangan_pengertian.setPreferredSize(new java.awt.Dimension(1347, 751));

        jLabel122.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel122.setText("Pengertian Zakat Perdagangan");

        jLabel123.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel123.setText("Zakat perdagangan (perniagaan) atau sering disebut juga ");

        jLabel124.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel124.setText("diproduksi untuk dijual belikan dengan bermacam-macam cara");

        jLabel134.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel134.setText("dengan harta perdagangan adalah semua bentuk hartayang ");

        jLabel149.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel149.setText("dan membawa kenaikan serta manfaat bagi manusia.");

        javax.swing.GroupLayout Perdagangan_pengertianLayout = new javax.swing.GroupLayout(Perdagangan_pengertian);
        Perdagangan_pengertian.setLayout(Perdagangan_pengertianLayout);
        Perdagangan_pengertianLayout.setHorizontalGroup(
            Perdagangan_pengertianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Perdagangan_pengertianLayout.createSequentialGroup()
                .addGroup(Perdagangan_pengertianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Perdagangan_pengertianLayout.createSequentialGroup()
                        .addGap(373, 373, 373)
                        .addComponent(jLabel122))
                    .addGroup(Perdagangan_pengertianLayout.createSequentialGroup()
                        .addGap(303, 303, 303)
                        .addGroup(Perdagangan_pengertianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel124)
                            .addComponent(jLabel123)
                            .addComponent(jLabel134)
                            .addComponent(jLabel149))))
                .addContainerGap(361, Short.MAX_VALUE))
        );
        Perdagangan_pengertianLayout.setVerticalGroup(
            Perdagangan_pengertianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Perdagangan_pengertianLayout.createSequentialGroup()
                .addGap(67, 67, 67)
                .addComponent(jLabel122)
                .addGap(51, 51, 51)
                .addComponent(jLabel123)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel134)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel124)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel149)
                .addContainerGap(445, Short.MAX_VALUE))
        );

        Perdagangan_syarat.setBackground(new java.awt.Color(0, 255, 255));
        Perdagangan_syarat.setPreferredSize(new java.awt.Dimension(1347, 751));

        jLabel135.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel135.setText("Syarat Zakat Perdagangan");

        jLabel136.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel136.setText("1). Genap berniaga satu tahun atau sudah berjalan haul (satu tahun)");

        jLabel137.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel137.setText("      itu wajib mengeluarkan zakat");

        jLabel138.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel138.setText("2). Nishab yaitu batas minimal yang jika harta sudah melebihi batas ");

        javax.swing.GroupLayout Perdagangan_syaratLayout = new javax.swing.GroupLayout(Perdagangan_syarat);
        Perdagangan_syarat.setLayout(Perdagangan_syaratLayout);
        Perdagangan_syaratLayout.setHorizontalGroup(
            Perdagangan_syaratLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Perdagangan_syaratLayout.createSequentialGroup()
                .addGroup(Perdagangan_syaratLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Perdagangan_syaratLayout.createSequentialGroup()
                        .addGap(303, 303, 303)
                        .addGroup(Perdagangan_syaratLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel137)
                            .addComponent(jLabel136)
                            .addComponent(jLabel138)))
                    .addGroup(Perdagangan_syaratLayout.createSequentialGroup()
                        .addGap(375, 375, 375)
                        .addComponent(jLabel135)))
                .addContainerGap(309, Short.MAX_VALUE))
        );
        Perdagangan_syaratLayout.setVerticalGroup(
            Perdagangan_syaratLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Perdagangan_syaratLayout.createSequentialGroup()
                .addGap(76, 76, 76)
                .addComponent(jLabel135)
                .addGap(42, 42, 42)
                .addComponent(jLabel136)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel138)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel137)
                .addContainerGap(478, Short.MAX_VALUE))
        );

        Perdagangan_rukun.setBackground(new java.awt.Color(0, 255, 255));
        Perdagangan_rukun.setPreferredSize(new java.awt.Dimension(1347, 751));

        jLabel143.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel143.setText("Rukun Zakat Perdagangan");

        jLabel144.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel144.setText("1). Niat untuk menunaikan dengan ikhlas semata-mata karena Allah SWT.,");

        jLabel145.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel145.setText("3). Terdapat penerima zakat atau mustahik");

        jLabel146.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel146.setText("2). Terdapat pemberi zakat ");

        jLabel147.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel147.setText("4). Terdapat makanan/barang/uang pokok yang dizakatkan");

        jLabel148.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel148.setText("5).  Besar zakat yang dikeluarkan sesuai agama islam ");

        javax.swing.GroupLayout Perdagangan_rukunLayout = new javax.swing.GroupLayout(Perdagangan_rukun);
        Perdagangan_rukun.setLayout(Perdagangan_rukunLayout);
        Perdagangan_rukunLayout.setHorizontalGroup(
            Perdagangan_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Perdagangan_rukunLayout.createSequentialGroup()
                .addGroup(Perdagangan_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Perdagangan_rukunLayout.createSequentialGroup()
                        .addGap(373, 373, 373)
                        .addComponent(jLabel143))
                    .addGroup(Perdagangan_rukunLayout.createSequentialGroup()
                        .addGap(300, 300, 300)
                        .addGroup(Perdagangan_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel145)
                            .addComponent(jLabel144)
                            .addComponent(jLabel146)
                            .addComponent(jLabel147)
                            .addComponent(jLabel148))))
                .addContainerGap(269, Short.MAX_VALUE))
        );
        Perdagangan_rukunLayout.setVerticalGroup(
            Perdagangan_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Perdagangan_rukunLayout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addComponent(jLabel143)
                .addGap(41, 41, 41)
                .addComponent(jLabel144)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel146)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel145)
                .addGap(13, 13, 13)
                .addComponent(jLabel147)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel148)
                .addContainerGap(430, Short.MAX_VALUE))
        );

        Pertanian_pengertian.setBackground(new java.awt.Color(0, 255, 255));
        Pertanian_pengertian.setPreferredSize(new java.awt.Dimension(1347, 751));

        jLabel139.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel139.setText("Pengertian Zakat Pertanian");

        jLabel140.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel140.setText("Zakat pertanian adalah zakat yang dikeluarkan dari ");

        jLabel141.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel141.setText("tanaman yang bernilai ekonomis seperti biji-bijian,");

        jLabel142.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel142.setText("hasil pertanian berupa tumbuh-tumbuhan, atau ");

        jLabel166.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel166.setText("umbi-umbian, sayur-mayur, buah-buahan, tanaman hias,");

        jLabel167.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel167.setText(" dan dapat disimpan.");

        jLabel168.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel168.setText(" rumput-rumputan, d.l.l. yang merupakan makanan pokok");

        javax.swing.GroupLayout Pertanian_pengertianLayout = new javax.swing.GroupLayout(Pertanian_pengertian);
        Pertanian_pengertian.setLayout(Pertanian_pengertianLayout);
        Pertanian_pengertianLayout.setHorizontalGroup(
            Pertanian_pengertianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Pertanian_pengertianLayout.createSequentialGroup()
                .addGroup(Pertanian_pengertianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Pertanian_pengertianLayout.createSequentialGroup()
                        .addGap(425, 425, 425)
                        .addComponent(jLabel139))
                    .addGroup(Pertanian_pengertianLayout.createSequentialGroup()
                        .addGap(384, 384, 384)
                        .addGroup(Pertanian_pengertianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel168)
                            .addComponent(jLabel141)
                            .addComponent(jLabel140)
                            .addComponent(jLabel142)
                            .addComponent(jLabel167)
                            .addComponent(jLabel166))))
                .addContainerGap(315, Short.MAX_VALUE))
        );
        Pertanian_pengertianLayout.setVerticalGroup(
            Pertanian_pengertianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Pertanian_pengertianLayout.createSequentialGroup()
                .addGap(54, 54, 54)
                .addComponent(jLabel139)
                .addGap(33, 33, 33)
                .addComponent(jLabel140)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel142)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel141)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel166)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel168)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel167)
                .addContainerGap(415, Short.MAX_VALUE))
        );

        Pertanian_syarat.setBackground(new java.awt.Color(0, 255, 255));
        Pertanian_syarat.setPreferredSize(new java.awt.Dimension(1347, 751));

        jLabel150.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel150.setText("Syarat Zakat Pertanian");

        jLabel151.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel151.setText("1.   Islam  ");

        jLabel152.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel152.setText("3.   Sempurna Milik");

        jLabel153.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel153.setText("2.   Merdeka");

        jLabel154.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel154.setText("4.   Cukup nisab");

        jLabel155.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel155.setText("5.   Tanaman tersebut adalah makanan asasi ");

        jLabel156.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel156.setText("      yang tahan disimpan lama.");

        jLabel157.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel157.setText("6.   Tanaman tersebut adalah hasil usaha manusia dan bukannya");

        jLabel169.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel169.setText("    tumbuh sendiri seperti tumbuh liar, dihanyutkan air dan sebagainya.");

        javax.swing.GroupLayout Pertanian_syaratLayout = new javax.swing.GroupLayout(Pertanian_syarat);
        Pertanian_syarat.setLayout(Pertanian_syaratLayout);
        Pertanian_syaratLayout.setHorizontalGroup(
            Pertanian_syaratLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Pertanian_syaratLayout.createSequentialGroup()
                .addGroup(Pertanian_syaratLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Pertanian_syaratLayout.createSequentialGroup()
                        .addGap(303, 303, 303)
                        .addGroup(Pertanian_syaratLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel152)
                            .addComponent(jLabel151)
                            .addComponent(jLabel153)
                            .addComponent(jLabel156)
                            .addComponent(jLabel154)
                            .addComponent(jLabel155)
                            .addComponent(jLabel157)
                            .addComponent(jLabel169)))
                    .addGroup(Pertanian_syaratLayout.createSequentialGroup()
                        .addGap(375, 375, 375)
                        .addComponent(jLabel150)))
                .addContainerGap(293, Short.MAX_VALUE))
        );
        Pertanian_syaratLayout.setVerticalGroup(
            Pertanian_syaratLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Pertanian_syaratLayout.createSequentialGroup()
                .addGap(76, 76, 76)
                .addComponent(jLabel150)
                .addGap(42, 42, 42)
                .addComponent(jLabel151)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel153)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel152)
                .addGap(13, 13, 13)
                .addComponent(jLabel154)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel155)
                .addGap(18, 18, 18)
                .addComponent(jLabel156)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel157)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel169)
                .addContainerGap(309, Short.MAX_VALUE))
        );

        Pertanian_rukun.setBackground(new java.awt.Color(0, 255, 255));
        Pertanian_rukun.setPreferredSize(new java.awt.Dimension(1347, 751));
        Pertanian_rukun.setRequestFocusEnabled(false);

        jLabel158.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel158.setText("Rukun Zakat Pertanian");

        jLabel159.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel159.setText("   1.    Islam");

        jLabel160.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel160.setText("   3.    Milik sempurna");

        jLabel161.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel161.setText("   2.    Merdeka");

        jLabel162.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel162.setText("   4.    Biji tanaman tersebut ditanam oleh manusia");

        jLabel163.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel163.setText("   5.    Tanaman tersebut tahan lama untuk disimpan");

        javax.swing.GroupLayout Pertanian_rukunLayout = new javax.swing.GroupLayout(Pertanian_rukun);
        Pertanian_rukun.setLayout(Pertanian_rukunLayout);
        Pertanian_rukunLayout.setHorizontalGroup(
            Pertanian_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Pertanian_rukunLayout.createSequentialGroup()
                .addGroup(Pertanian_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Pertanian_rukunLayout.createSequentialGroup()
                        .addGap(373, 373, 373)
                        .addComponent(jLabel158))
                    .addGroup(Pertanian_rukunLayout.createSequentialGroup()
                        .addGap(300, 300, 300)
                        .addGroup(Pertanian_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel160)
                            .addComponent(jLabel159)
                            .addComponent(jLabel161)
                            .addComponent(jLabel162)
                            .addComponent(jLabel163))))
                .addContainerGap(447, Short.MAX_VALUE))
        );
        Pertanian_rukunLayout.setVerticalGroup(
            Pertanian_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Pertanian_rukunLayout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addComponent(jLabel158)
                .addGap(41, 41, 41)
                .addComponent(jLabel159)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel161)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel160)
                .addGap(13, 13, 13)
                .addComponent(jLabel162)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel163)
                .addContainerGap(430, Short.MAX_VALUE))
        );

        Emas_pengertian.setBackground(new java.awt.Color(0, 255, 255));

        jLabel164.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel164.setText("Pengertian Zakat Emas");

        jLabel165.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel165.setText("Zakat emas adalah zakat yang wajib dikeluarkan ");

        jLabel170.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel170.setText("mencapai nisab dan haul.");

        jLabel171.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel171.setText("oleh seorang muslim yang mempunyai emas bila telah");

        javax.swing.GroupLayout Emas_pengertianLayout = new javax.swing.GroupLayout(Emas_pengertian);
        Emas_pengertian.setLayout(Emas_pengertianLayout);
        Emas_pengertianLayout.setHorizontalGroup(
            Emas_pengertianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Emas_pengertianLayout.createSequentialGroup()
                .addGroup(Emas_pengertianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Emas_pengertianLayout.createSequentialGroup()
                        .addGap(373, 373, 373)
                        .addComponent(jLabel164))
                    .addGroup(Emas_pengertianLayout.createSequentialGroup()
                        .addGap(303, 303, 303)
                        .addGroup(Emas_pengertianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel170)
                            .addComponent(jLabel165)
                            .addComponent(jLabel171))))
                .addContainerGap(436, Short.MAX_VALUE))
        );
        Emas_pengertianLayout.setVerticalGroup(
            Emas_pengertianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Emas_pengertianLayout.createSequentialGroup()
                .addGap(67, 67, 67)
                .addComponent(jLabel164)
                .addGap(51, 51, 51)
                .addComponent(jLabel165)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel171)
                .addGap(18, 18, 18)
                .addComponent(jLabel170)
                .addContainerGap(482, Short.MAX_VALUE))
        );

        Perak_perhitungan.setBackground(new java.awt.Color(0, 255, 255));
        Perak_perhitungan.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel177.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel177.setText("Perhitungan Zakat Perak");
        Perak_perhitungan.add(jLabel177, new org.netbeans.lib.awtextra.AbsoluteConstraints(373, 67, -1, -1));

        jLabel178.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel178.setText("Masukan Berat Perak              :");
        Perak_perhitungan.add(jLabel178, new org.netbeans.lib.awtextra.AbsoluteConstraints(303, 148, -1, -1));

        jLabel179.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel179.setText("Nishab Perak                         :");
        Perak_perhitungan.add(jLabel179, new org.netbeans.lib.awtextra.AbsoluteConstraints(303, 178, -1, -1));

        jLabel180.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel180.setText("Masukan Harga Emas Pergram  :");
        Perak_perhitungan.add(jLabel180, new org.netbeans.lib.awtextra.AbsoluteConstraints(303, 213, -1, -1));

        jLabel183.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel183.setText("/gram");
        Perak_perhitungan.add(jLabel183, new org.netbeans.lib.awtextra.AbsoluteConstraints(735, 148, -1, -1));

        beratperak.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                beratperakKeyTyped(evt);
            }
        });
        Perak_perhitungan.add(beratperak, new org.netbeans.lib.awtextra.AbsoluteConstraints(609, 152, 116, -1));

        jLabel184.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel184.setText("Rp.");
        Perak_perhitungan.add(jLabel184, new org.netbeans.lib.awtextra.AbsoluteConstraints(579, 213, -1, -1));

        hargaperak.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                hargaperakKeyTyped(evt);
            }
        });
        Perak_perhitungan.add(hargaperak, new org.netbeans.lib.awtextra.AbsoluteConstraints(609, 217, 173, -1));

        nishabperak.setEditable(false);
        nishabperak.setText("595");
        nishabperak.setCursor(new java.awt.Cursor(java.awt.Cursor.NE_RESIZE_CURSOR));
        Perak_perhitungan.add(nishabperak, new org.netbeans.lib.awtextra.AbsoluteConstraints(609, 182, 116, -1));

        jLabel189.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel189.setText("/gram");
        Perak_perhitungan.add(jLabel189, new org.netbeans.lib.awtextra.AbsoluteConstraints(735, 178, -1, -1));

        jPanel12.setBackground(new java.awt.Color(0, 255, 255));
        jPanel12.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        jButton5.setText("Hitung");
        jButton5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jLabel181.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel181.setText("Jumlah Zakat Yang Harus Dibayar");

        jLabel182.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel182.setText("gram / Rp.");

        hasilperak.setEditable(false);

        hasilperak1.setEditable(false);

        jButton6.setText("Hitung Kembali");
        jButton6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap(132, Short.MAX_VALUE)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                        .addComponent(jButton5)
                        .addGap(229, 229, 229))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel12Layout.createSequentialGroup()
                                .addGap(17, 17, 17)
                                .addComponent(jLabel181))
                            .addGroup(jPanel12Layout.createSequentialGroup()
                                .addComponent(hasilperak, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(4, 4, 4)
                                .addComponent(jLabel182)
                                .addGap(10, 10, 10)
                                .addComponent(hasilperak1, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(99, 99, 99))))
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(236, 236, 236)
                .addComponent(jButton6)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(152, 152, 152)
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel181)
                .addGap(11, 11, 11)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel182)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(hasilperak, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(hasilperak1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        Perak_perhitungan.add(jPanel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 120, 550, 340));

        Temuan_perhitungan.setBackground(new java.awt.Color(0, 255, 255));
        Temuan_perhitungan.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel195.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel195.setText("Perhitungan Zakat Temuan");
        Temuan_perhitungan.add(jLabel195, new org.netbeans.lib.awtextra.AbsoluteConstraints(373, 67, -1, -1));

        jLabel196.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel196.setText("Masukan Nama Barang Temuan  :");
        Temuan_perhitungan.add(jLabel196, new org.netbeans.lib.awtextra.AbsoluteConstraints(303, 148, -1, -1));

        namatemuan.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                namatemuanKeyTyped(evt);
            }
        });
        Temuan_perhitungan.add(namatemuan, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 152, 185, -1));

        jPanel13.setBackground(new java.awt.Color(0, 255, 255));
        jPanel13.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        jLabel198.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel198.setText("Masukan Nilai Barang                :");

        jLabel202.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel202.setText("Rp.");

        nilaitemuan.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                nilaitemuanKeyTyped(evt);
            }
        });

        jButton9.setText("Hitung");
        jButton9.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jLabel199.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel199.setText("Jumlah Zakat Yang Harus Dibayar");

        hasiltemuan.setEditable(false);
        hasiltemuan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hasiltemuanActionPerformed(evt);
            }
        });

        jLabel200.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel200.setText("Rp.");

        jButton10.setText("Hitung Kembali");
        jButton10.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap(31, Short.MAX_VALUE)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel13Layout.createSequentialGroup()
                        .addComponent(jLabel198)
                        .addGap(6, 6, 6)
                        .addComponent(jLabel202)
                        .addGap(4, 4, 4)
                        .addComponent(nilaitemuan, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(23, 23, 23))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel13Layout.createSequentialGroup()
                            .addComponent(jLabel200)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(hasiltemuan, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(148, 148, 148))
                        .addGroup(jPanel13Layout.createSequentialGroup()
                            .addComponent(jLabel199)
                            .addGap(115, 115, 115)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel13Layout.createSequentialGroup()
                        .addComponent(jButton9)
                        .addGap(230, 230, 230))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel13Layout.createSequentialGroup()
                        .addComponent(jButton10)
                        .addGap(209, 209, 209))))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGap(68, 68, 68)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel198)
                    .addComponent(jLabel202)
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addComponent(nilaitemuan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(29, 29, 29)
                .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel199)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(hasiltemuan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel200))
                .addGap(29, 29, 29)
                .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(56, Short.MAX_VALUE))
        );

        Temuan_perhitungan.add(jPanel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 120, 550, 340));

        Fitrah_perhitungan.setBackground(new java.awt.Color(0, 255, 255));
        Fitrah_perhitungan.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel197.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel197.setText("Perhitungan Zakat Fitrah");
        Fitrah_perhitungan.add(jLabel197, new org.netbeans.lib.awtextra.AbsoluteConstraints(373, 67, -1, -1));

        jPanel14.setBackground(new java.awt.Color(0, 255, 255));
        jPanel14.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        jButton12.setText("Hitung Kembali");
        jButton12.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        hasilfitrah.setEditable(false);
        hasilfitrah.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        hasilfitrah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hasilfitrahActionPerformed(evt);
            }
        });

        jLabel205.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel205.setText("Rp.");

        jLabel204.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel204.setText("Jumlah Zakat Yang Harus Dibayar");

        jButton11.setText("Hitung");
        jButton11.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jLabel203.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel203.setText("Masukan Harga Barang Pokok       :");

        jLabel206.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel206.setText("Rp.");

        hargafitrah.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                hargafitrahKeyTyped(evt);
            }
        });

        jumlahfitrah.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jumlahfitrahKeyTyped(evt);
            }
        });

        jLabel201.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel201.setText("Masukan Jumlah Jiwa                  :");

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addComponent(jLabel201)
                        .addGap(18, 18, 18)
                        .addComponent(jumlahfitrah, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(36, Short.MAX_VALUE))
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addComponent(jLabel203)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel206)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(hargafitrah, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
                        .addComponent(jButton11)
                        .addGap(222, 222, 222))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
                        .addComponent(jLabel204)
                        .addGap(126, 126, 126))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
                        .addComponent(jLabel205)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(hasilfitrah, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
                                .addComponent(jButton12)
                                .addGap(57, 57, 57)))
                        .addGap(141, 141, 141))))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
                .addContainerGap(37, Short.MAX_VALUE)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jumlahfitrah, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel201))
                .addGap(18, 18, 18)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel203)
                    .addComponent(jLabel206)
                    .addComponent(hargafitrah, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel204)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(hasilfitrah, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel205))
                .addGap(18, 18, 18)
                .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(55, 55, 55))
        );

        Fitrah_perhitungan.add(jPanel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 120, 560, 340));

        Galian_perhitungan.setBackground(new java.awt.Color(0, 255, 255));
        Galian_perhitungan.setPreferredSize(new java.awt.Dimension(1347, 751));
        Galian_perhitungan.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel207.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel207.setText("Perhitungan Zakat Barang Galian");
        Galian_perhitungan.add(jLabel207, new org.netbeans.lib.awtextra.AbsoluteConstraints(347, 65, -1, -1));

        jPanel15.setBackground(new java.awt.Color(0, 255, 255));
        jPanel15.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        jButton14.setText("Hitung Kembali");
        jButton14.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });

        hasilgalian.setEditable(false);
        hasilgalian.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hasilgalianActionPerformed(evt);
            }
        });

        jLabel211.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel211.setText("Rp.");

        jLabel210.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel210.setText("Jumlah Zakat Yang Harus Dibayar");

        jButton13.setText("Hitung");
        jButton13.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });

        nilaigalian.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                nilaigalianKeyTyped(evt);
            }
        });

        jLabel212.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel212.setText("Rp.");

        jLabel209.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel209.setText("Masukan Nilai Barang                :");

        namagalian.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                namagalianKeyTyped(evt);
            }
        });

        jLabel208.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel208.setText("Masukan Nama Barang Galian     :");

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap(30, Short.MAX_VALUE)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel15Layout.createSequentialGroup()
                                .addComponent(jLabel209)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel212))
                            .addComponent(jLabel208))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(namagalian, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(nilaigalian, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                        .addComponent(jButton13)
                        .addGap(231, 231, 231))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                        .addComponent(jLabel210)
                        .addGap(126, 126, 126))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                        .addComponent(jLabel211)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(hasilgalian, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                                .addComponent(jButton14)
                                .addGap(56, 56, 56)))
                        .addGap(147, 147, 147))))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                .addContainerGap(33, Short.MAX_VALUE)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(namagalian, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel208))
                .addGap(18, 18, 18)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nilaigalian, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel212)
                    .addComponent(jLabel209))
                .addGap(23, 23, 23)
                .addComponent(jButton13, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel210)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(hasilgalian, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel211))
                .addGap(18, 18, 18)
                .addComponent(jButton14, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(66, 66, 66))
        );

        Galian_perhitungan.add(jPanel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 120, 550, 340));

        Pertanian_perhitungan.setBackground(new java.awt.Color(0, 255, 255));
        Pertanian_perhitungan.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel213.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel213.setText("Perhitungan Zakat Pertanian");
        Pertanian_perhitungan.add(jLabel213, new org.netbeans.lib.awtextra.AbsoluteConstraints(373, 67, -1, -1));

        jLabel214.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel214.setText("Masukan Berat Hasil Pertanian    :");
        Pertanian_perhitungan.add(jLabel214, new org.netbeans.lib.awtextra.AbsoluteConstraints(303, 148, -1, -1));

        jLabel215.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel215.setText("Masukan Harga Pokok               :");
        Pertanian_perhitungan.add(jLabel215, new org.netbeans.lib.awtextra.AbsoluteConstraints(303, 213, -1, -1));

        jLabel216.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel216.setText("Nishab Pertanian Adalah            :");
        Pertanian_perhitungan.add(jLabel216, new org.netbeans.lib.awtextra.AbsoluteConstraints(303, 183, -1, -1));

        jLabel219.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel219.setText("/Kg");
        Pertanian_perhitungan.add(jLabel219, new org.netbeans.lib.awtextra.AbsoluteConstraints(837, 148, -1, -1));

        berattani.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                berattaniKeyTyped(evt);
            }
        });
        Pertanian_perhitungan.add(berattani, new org.netbeans.lib.awtextra.AbsoluteConstraints(592, 152, 241, -1));

        nishabtani.setEditable(false);
        nishabtani.setText("652.8");
        Pertanian_perhitungan.add(nishabtani, new org.netbeans.lib.awtextra.AbsoluteConstraints(592, 187, 241, -1));

        hargapokoktani.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                hargapokoktaniKeyTyped(evt);
            }
        });
        Pertanian_perhitungan.add(hargapokoktani, new org.netbeans.lib.awtextra.AbsoluteConstraints(622, 217, 205, -1));

        jLabel224.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel224.setText("Rp.");
        Pertanian_perhitungan.add(jLabel224, new org.netbeans.lib.awtextra.AbsoluteConstraints(592, 213, -1, -1));

        jLabel222.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel222.setText("/Kg");
        Pertanian_perhitungan.add(jLabel222, new org.netbeans.lib.awtextra.AbsoluteConstraints(837, 183, -1, -1));

        jLabel223.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel223.setText("/Kg");
        Pertanian_perhitungan.add(jLabel223, new org.netbeans.lib.awtextra.AbsoluteConstraints(831, 213, -1, -1));

        jLabel225.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel225.setText("Metode Pengairan                    :");
        Pertanian_perhitungan.add(jLabel225, new org.netbeans.lib.awtextra.AbsoluteConstraints(303, 256, -1, -1));

        jRadioButton3.setBackground(new java.awt.Color(0, 255, 255));
        buttonGroup2.add(jRadioButton3);
        jRadioButton3.setText("Pengairan Pribadi");
        Pertanian_perhitungan.add(jRadioButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(592, 259, 138, -1));

        jRadioButton4.setBackground(new java.awt.Color(0, 255, 255));
        buttonGroup2.add(jRadioButton4);
        jRadioButton4.setText("Pengairan Alami");
        Pertanian_perhitungan.add(jRadioButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(732, 259, 130, -1));

        jPanel16.setBackground(new java.awt.Color(0, 255, 255));
        jPanel16.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        jPanel17.setBackground(new java.awt.Color(0, 255, 255));
        jPanel17.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 276, Short.MAX_VALUE)
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 29, Short.MAX_VALUE)
        );

        jButton15.setText("Hitung");
        jButton15.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });

        jLabel217.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel217.setText("Jumlah Zakat Yang Harus Dibayar");

        hasiltani.setEditable(false);

        jLabel218.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel218.setText("Kg / Rp.");

        hasiltani1.setEditable(false);

        jButton16.setText("Hitung Kembali");
        jButton16.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton16ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap(156, Short.MAX_VALUE)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel16Layout.createSequentialGroup()
                        .addComponent(jButton15)
                        .addGap(266, 266, 266))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel16Layout.createSequentialGroup()
                        .addComponent(jLabel217)
                        .addGap(165, 165, 165))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel16Layout.createSequentialGroup()
                        .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel16Layout.createSequentialGroup()
                        .addComponent(hasiltani, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(4, 4, 4)
                        .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton16)
                            .addGroup(jPanel16Layout.createSequentialGroup()
                                .addComponent(jLabel218)
                                .addGap(4, 4, 4)
                                .addComponent(hasiltani1, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(124, 124, 124))))
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addGap(131, 131, 131)
                .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addComponent(jButton15, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel217)
                .addGap(18, 18, 18)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel218, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(hasiltani, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(hasiltani1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                .addComponent(jButton16, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        Pertanian_perhitungan.add(jPanel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 120, 610, 350));

        Perdagangan_perhitungan.setBackground(new java.awt.Color(0, 255, 255));
        Perdagangan_perhitungan.setPreferredSize(new java.awt.Dimension(1347, 751));
        Perdagangan_perhitungan.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel220.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel220.setText("Perhitungan Zakat Perdagangan");
        Perdagangan_perhitungan.add(jLabel220, new org.netbeans.lib.awtextra.AbsoluteConstraints(358, 71, -1, -1));

        jLabel226.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel226.setText("Bonus Pendapatan Lain-lain Perbulan    :");
        Perdagangan_perhitungan.add(jLabel226, new org.netbeans.lib.awtextra.AbsoluteConstraints(303, 195, -1, -1));

        jLabel227.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel227.setText("Modal Yang Diputar selama satu tahun  :");
        Perdagangan_perhitungan.add(jLabel227, new org.netbeans.lib.awtextra.AbsoluteConstraints(303, 153, -1, -1));

        jLabel228.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel228.setText("Jumlah Zakat Yang Harus Dibayar");
        Perdagangan_perhitungan.add(jLabel228, new org.netbeans.lib.awtextra.AbsoluteConstraints(395, 376, -1, -1));

        jLabel229.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel229.setText("Rp.");
        Perdagangan_perhitungan.add(jLabel229, new org.netbeans.lib.awtextra.AbsoluteConstraints(405, 409, -1, -1));

        jLabel231.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel231.setText("Rp.");
        Perdagangan_perhitungan.add(jLabel231, new org.netbeans.lib.awtextra.AbsoluteConstraints(644, 153, -1, -1));

        modaldagang.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                modaldagangKeyTyped(evt);
            }
        });
        Perdagangan_perhitungan.add(modaldagang, new org.netbeans.lib.awtextra.AbsoluteConstraints(674, 157, 157, -1));

        jLabel232.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel232.setText("Rp.");
        Perdagangan_perhitungan.add(jLabel232, new org.netbeans.lib.awtextra.AbsoluteConstraints(644, 195, -1, -1));

        bonusdagang.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                bonusdagangKeyTyped(evt);
            }
        });
        Perdagangan_perhitungan.add(bonusdagang, new org.netbeans.lib.awtextra.AbsoluteConstraints(674, 199, 157, -1));

        hasildagang.setEditable(false);
        hasildagang.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        hasildagang.setEnabled(false);
        Perdagangan_perhitungan.add(hasildagang, new org.netbeans.lib.awtextra.AbsoluteConstraints(441, 413, 209, -1));

        jButton17.setText("Hitung");
        jButton17.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton17ActionPerformed(evt);
            }
        });
        Perdagangan_perhitungan.add(jButton17, new org.netbeans.lib.awtextra.AbsoluteConstraints(505, 340, -1, 30));

        jButton18.setText("Hitung Kembali");
        jButton18.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton18ActionPerformed(evt);
            }
        });
        Perdagangan_perhitungan.add(jButton18, new org.netbeans.lib.awtextra.AbsoluteConstraints(481, 444, -1, 30));

        jLabel233.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel233.setText("Rp.");
        Perdagangan_perhitungan.add(jLabel233, new org.netbeans.lib.awtextra.AbsoluteConstraints(644, 258, -1, -1));

        jumlahlbrg.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jumlahlbrgKeyTyped(evt);
            }
        });
        Perdagangan_perhitungan.add(jumlahlbrg, new org.netbeans.lib.awtextra.AbsoluteConstraints(674, 262, 157, -1));

        jLabel234.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel234.setText("Laba / Rugi                                      :");
        Perdagangan_perhitungan.add(jLabel234, new org.netbeans.lib.awtextra.AbsoluteConstraints(303, 230, -1, -1));

        jLabel235.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel235.setText("Jumlah laba / Rugi                            :");
        Perdagangan_perhitungan.add(jLabel235, new org.netbeans.lib.awtextra.AbsoluteConstraints(303, 258, -1, -1));

        jLabel244.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel244.setText("Hutang Jatuh Tempo                         :");
        Perdagangan_perhitungan.add(jLabel244, new org.netbeans.lib.awtextra.AbsoluteConstraints(303, 293, -1, -1));

        hutangdagang.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                hutangdagangKeyTyped(evt);
            }
        });
        Perdagangan_perhitungan.add(hutangdagang, new org.netbeans.lib.awtextra.AbsoluteConstraints(674, 297, 157, -1));

        jLabel245.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel245.setText("Rp.");
        Perdagangan_perhitungan.add(jLabel245, new org.netbeans.lib.awtextra.AbsoluteConstraints(644, 293, -1, -1));

        jRadioButton1.setBackground(new java.awt.Color(0, 255, 255));
        buttonGroup1.add(jRadioButton1);
        jRadioButton1.setText("Laba");
        Perdagangan_perhitungan.add(jRadioButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(674, 233, 66, -1));

        jRadioButton2.setBackground(new java.awt.Color(0, 255, 255));
        buttonGroup1.add(jRadioButton2);
        jRadioButton2.setText("Rugi");
        Perdagangan_perhitungan.add(jRadioButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(758, 233, 66, -1));

        jPanel18.setBackground(new java.awt.Color(0, 255, 255));
        jPanel18.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        jPanel19.setBackground(new java.awt.Color(0, 255, 255));
        jPanel19.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 182, Short.MAX_VALUE)
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 27, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel18Layout.createSequentialGroup()
                .addContainerGap(380, Short.MAX_VALUE)
                .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addGap(106, 106, 106)
                .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(229, Short.MAX_VALUE))
        );

        Perdagangan_perhitungan.add(jPanel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 120, 580, 370));

        Profesi_perhitungan.setBackground(new java.awt.Color(0, 255, 255));
        Profesi_perhitungan.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel221.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel221.setText("Perhitungan Zakat Profesi");
        Profesi_perhitungan.add(jLabel221, new org.netbeans.lib.awtextra.AbsoluteConstraints(371, 29, -1, -1));

        jLabel230.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel230.setText("Bonus Pendapatan Lain-lain Perbulan  :");
        Profesi_perhitungan.add(jLabel230, new org.netbeans.lib.awtextra.AbsoluteConstraints(299, 140, -1, -1));

        jLabel236.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel236.setText("Masukan Jumlah Gaji Perbulan           :");
        Profesi_perhitungan.add(jLabel236, new org.netbeans.lib.awtextra.AbsoluteConstraints(299, 98, -1, -1));

        jLabel239.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel239.setText("Rp.");
        Profesi_perhitungan.add(jLabel239, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 98, -1, -1));

        gajiprofesi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gajiprofesiActionPerformed(evt);
            }
        });
        gajiprofesi.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                gajiprofesiKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                gajiprofesiKeyTyped(evt);
            }
        });
        Profesi_perhitungan.add(gajiprofesi, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 102, 174, -1));

        jLabel240.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel240.setText("Rp.");
        Profesi_perhitungan.add(jLabel240, new org.netbeans.lib.awtextra.AbsoluteConstraints(628, 140, -1, -1));

        bonusprofesi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bonusprofesiActionPerformed(evt);
            }
        });
        bonusprofesi.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                bonusprofesiKeyTyped(evt);
            }
        });
        Profesi_perhitungan.add(bonusprofesi, new org.netbeans.lib.awtextra.AbsoluteConstraints(658, 144, 176, -1));

        jLabel243.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel243.setText("Pengeluaran Kebutuhan Pokok           :");
        Profesi_perhitungan.add(jLabel243, new org.netbeans.lib.awtextra.AbsoluteConstraints(297, 182, -1, -1));

        jLabel246.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel246.setText("(termasuk hutang jatuh tempo)per bulan");
        Profesi_perhitungan.add(jLabel246, new org.netbeans.lib.awtextra.AbsoluteConstraints(287, 210, -1, -1));

        jLabel248.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel248.setText("Nishabnya Adalah                            :");
        Profesi_perhitungan.add(jLabel248, new org.netbeans.lib.awtextra.AbsoluteConstraints(296, 250, -1, -1));

        jLabel249.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel249.setText("Rp.");
        Profesi_perhitungan.add(jLabel249, new org.netbeans.lib.awtextra.AbsoluteConstraints(628, 182, -1, -1));

        pengeluaranprofesi.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                pengeluaranprofesiKeyTyped(evt);
            }
        });
        Profesi_perhitungan.add(pengeluaranprofesi, new org.netbeans.lib.awtextra.AbsoluteConstraints(658, 182, 176, -1));

        jLabel251.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel251.setText("Rp.");
        Profesi_perhitungan.add(jLabel251, new org.netbeans.lib.awtextra.AbsoluteConstraints(628, 250, -1, -1));

        nishabprofesi.setEditable(false);
        nishabprofesi.setText("6530000");
        Profesi_perhitungan.add(nishabprofesi, new org.netbeans.lib.awtextra.AbsoluteConstraints(664, 254, 170, -1));

        jPanel20.setBackground(new java.awt.Color(0, 255, 255));
        jPanel20.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        jButton19.setText("Hitung");
        jButton19.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton19ActionPerformed(evt);
            }
        });

        jLabel237.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel237.setText("Jumlah Zakat Yang Harus Dibayar");

        jLabel238.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel238.setText("Rp.");

        hasilprofesi1.setEditable(false);

        jButton20.setText("Hitung Kembali");
        jButton20.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton20ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addContainerGap(179, Short.MAX_VALUE)
                .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel20Layout.createSequentialGroup()
                        .addComponent(jButton19)
                        .addGap(241, 241, 241))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel20Layout.createSequentialGroup()
                        .addComponent(jLabel237)
                        .addGap(131, 131, 131))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel20Layout.createSequentialGroup()
                        .addComponent(jLabel238)
                        .addGap(4, 4, 4)
                        .addComponent(hasilprofesi1, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(150, 150, 150))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel20Layout.createSequentialGroup()
                        .addComponent(jButton20)
                        .addGap(211, 211, 211))))
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel20Layout.createSequentialGroup()
                .addContainerGap(234, Short.MAX_VALUE)
                .addComponent(jButton19, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel237)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel238)
                    .addComponent(hasilprofesi1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton20, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8))
        );

        Profesi_perhitungan.add(jPanel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 70, 580, 380));

        Emas_syarat.setBackground(new java.awt.Color(0, 255, 255));
        Emas_syarat.setPreferredSize(new java.awt.Dimension(1347, 751));

        jLabel23.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel23.setText("Syarat Zakat Emas");

        jLabel24.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel24.setText("1.      Milik orang islam");

        jLabel25.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel25.setText("3.      Mencapai nishab");

        jLabel26.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel26.setText("2.      Mencapai haul");

        jLabel27.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel27.setText("4.      Besar zakat 2,5 %");

        jLabel28.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel28.setText("5.      Harus berupa emas murni atau perak murni (24K/99%), bukan campuran. ");

        jLabel29.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel29.setText("          Jika campuran, walaupun mencapai nishob,maka tidak ada kewajiban zakatnya,");

        jLabel30.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel30.setText("          sebab berat aslinya kurang dari itu.");

        javax.swing.GroupLayout Emas_syaratLayout = new javax.swing.GroupLayout(Emas_syarat);
        Emas_syarat.setLayout(Emas_syaratLayout);
        Emas_syaratLayout.setHorizontalGroup(
            Emas_syaratLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Emas_syaratLayout.createSequentialGroup()
                .addGroup(Emas_syaratLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Emas_syaratLayout.createSequentialGroup()
                        .addGap(303, 303, 303)
                        .addGroup(Emas_syaratLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel25)
                            .addComponent(jLabel24)
                            .addComponent(jLabel26)
                            .addComponent(jLabel29)
                            .addComponent(jLabel27)
                            .addComponent(jLabel28)
                            .addComponent(jLabel30)))
                    .addGroup(Emas_syaratLayout.createSequentialGroup()
                        .addGap(375, 375, 375)
                        .addComponent(jLabel23)))
                .addContainerGap(178, Short.MAX_VALUE))
        );
        Emas_syaratLayout.setVerticalGroup(
            Emas_syaratLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Emas_syaratLayout.createSequentialGroup()
                .addGap(76, 76, 76)
                .addComponent(jLabel23)
                .addGap(42, 42, 42)
                .addComponent(jLabel24)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel26)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel25)
                .addGap(13, 13, 13)
                .addComponent(jLabel27)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel28)
                .addGap(18, 18, 18)
                .addComponent(jLabel29)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel30)
                .addContainerGap(348, Short.MAX_VALUE))
        );

        Perak1_rukun.setBackground(new java.awt.Color(0, 255, 255));

        jLabel259.setFont(new java.awt.Font("Century", 1, 24)); // NOI18N
        jLabel259.setText("Rukun Zakat Perak");

        jLabel260.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel260.setText("1).  Pelepasan atau pengeluaran hak milik pada sebagaian");

        jLabel261.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel261.setText("3).  Penyerahan sebagian harta tersebut dari orang yang ");

        jLabel262.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel262.setText("2).  harta yang dikenakan wajib zakat");

        jLabel263.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel263.setText("4).  mempunyai harta kepada orang yang bertugas atau orang");

        jLabel264.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel264.setText("5).  yang mengurusi zakat (amil zakat). ");

        jLabel265.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel265.setText("6).  Penyerahan amil kepada orang yang berhak menerima ");

        jLabel266.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel266.setText("       zakat sebagai milik");

        javax.swing.GroupLayout Perak1_rukunLayout = new javax.swing.GroupLayout(Perak1_rukun);
        Perak1_rukun.setLayout(Perak1_rukunLayout);
        Perak1_rukunLayout.setHorizontalGroup(
            Perak1_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Perak1_rukunLayout.createSequentialGroup()
                .addGroup(Perak1_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Perak1_rukunLayout.createSequentialGroup()
                        .addGap(373, 373, 373)
                        .addComponent(jLabel259))
                    .addGroup(Perak1_rukunLayout.createSequentialGroup()
                        .addGap(300, 300, 300)
                        .addGroup(Perak1_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel261)
                            .addComponent(jLabel260)
                            .addComponent(jLabel262)
                            .addComponent(jLabel265)
                            .addComponent(jLabel263)
                            .addComponent(jLabel264)
                            .addComponent(jLabel266))))
                .addContainerGap(374, Short.MAX_VALUE))
        );
        Perak1_rukunLayout.setVerticalGroup(
            Perak1_rukunLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Perak1_rukunLayout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addComponent(jLabel259)
                .addGap(41, 41, 41)
                .addComponent(jLabel260)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel262)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel261)
                .addGap(13, 13, 13)
                .addComponent(jLabel263)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel264)
                .addGap(18, 18, 18)
                .addComponent(jLabel265)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel266)
                .addContainerGap(368, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout WdkmLayout = new javax.swing.GroupLayout(Wdkm);
        Wdkm.setLayout(WdkmLayout);
        WdkmLayout.setHorizontalGroup(
            WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PKas_m, javax.swing.GroupLayout.DEFAULT_SIZE, 1167, Short.MAX_VALUE)
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(WdkmLayout.createSequentialGroup()
                    .addComponent(PKas_F, javax.swing.GroupLayout.DEFAULT_SIZE, 1143, Short.MAX_VALUE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(WdkmLayout.createSequentialGroup()
                    .addComponent(PData, javax.swing.GroupLayout.DEFAULT_SIZE, 1143, Short.MAX_VALUE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(WdkmLayout.createSequentialGroup()
                    .addComponent(Emas_perhitungan, javax.swing.GroupLayout.DEFAULT_SIZE, 1136, Short.MAX_VALUE)
                    .addGap(0, 31, Short.MAX_VALUE)))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(Emas_rukun, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WdkmLayout.createSequentialGroup()
                    .addComponent(Perak_pengertian, javax.swing.GroupLayout.DEFAULT_SIZE, 1110, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(Perak_syarat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WdkmLayout.createSequentialGroup()
                    .addComponent(Temuan_pengertian, javax.swing.GroupLayout.DEFAULT_SIZE, 1110, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WdkmLayout.createSequentialGroup()
                    .addComponent(Temuan_rukun, javax.swing.GroupLayout.DEFAULT_SIZE, 1110, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WdkmLayout.createSequentialGroup()
                    .addComponent(Temuan_syarat, javax.swing.GroupLayout.DEFAULT_SIZE, 1110, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WdkmLayout.createSequentialGroup()
                    .addComponent(Fitrah_rukun, javax.swing.GroupLayout.DEFAULT_SIZE, 1110, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WdkmLayout.createSequentialGroup()
                    .addComponent(Fitrah_syarat, javax.swing.GroupLayout.DEFAULT_SIZE, 1110, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WdkmLayout.createSequentialGroup()
                    .addComponent(Fitrah_pengertian, javax.swing.GroupLayout.DEFAULT_SIZE, 1110, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WdkmLayout.createSequentialGroup()
                    .addComponent(Galian_pengertian, javax.swing.GroupLayout.DEFAULT_SIZE, 1110, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WdkmLayout.createSequentialGroup()
                    .addComponent(Galian_rukun, javax.swing.GroupLayout.DEFAULT_SIZE, 1110, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WdkmLayout.createSequentialGroup()
                    .addComponent(Galian_syarat, javax.swing.GroupLayout.DEFAULT_SIZE, 1110, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WdkmLayout.createSequentialGroup()
                    .addComponent(Profesi_pengertian, javax.swing.GroupLayout.DEFAULT_SIZE, 1110, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(WdkmLayout.createSequentialGroup()
                    .addComponent(Profesi_syarat, javax.swing.GroupLayout.DEFAULT_SIZE, 1110, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WdkmLayout.createSequentialGroup()
                    .addComponent(Profesi_rukun, javax.swing.GroupLayout.DEFAULT_SIZE, 1110, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WdkmLayout.createSequentialGroup()
                    .addComponent(Perdagangan_pengertian, javax.swing.GroupLayout.DEFAULT_SIZE, 1110, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WdkmLayout.createSequentialGroup()
                    .addComponent(Perdagangan_syarat, javax.swing.GroupLayout.DEFAULT_SIZE, 1110, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WdkmLayout.createSequentialGroup()
                    .addComponent(Perdagangan_rukun, javax.swing.GroupLayout.DEFAULT_SIZE, 1110, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WdkmLayout.createSequentialGroup()
                    .addComponent(Pertanian_pengertian, javax.swing.GroupLayout.DEFAULT_SIZE, 1110, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WdkmLayout.createSequentialGroup()
                    .addComponent(Pertanian_syarat, javax.swing.GroupLayout.DEFAULT_SIZE, 1110, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(Pertanian_rukun, javax.swing.GroupLayout.DEFAULT_SIZE, 1120, Short.MAX_VALUE))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(Emas_pengertian, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(Perak_perhitungan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(Temuan_perhitungan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(Fitrah_perhitungan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(Galian_perhitungan, javax.swing.GroupLayout.DEFAULT_SIZE, 1167, Short.MAX_VALUE))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(Pertanian_perhitungan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(Perdagangan_perhitungan, javax.swing.GroupLayout.DEFAULT_SIZE, 1167, Short.MAX_VALUE))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(Profesi_perhitungan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(Emas_syarat, javax.swing.GroupLayout.DEFAULT_SIZE, 1120, Short.MAX_VALUE))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(Perak1_rukun, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        WdkmLayout.setVerticalGroup(
            WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WdkmLayout.createSequentialGroup()
                .addComponent(PKas_m, javax.swing.GroupLayout.PREFERRED_SIZE, 725, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(PKas_F, javax.swing.GroupLayout.PREFERRED_SIZE, 725, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(PData, javax.swing.GroupLayout.PREFERRED_SIZE, 725, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(WdkmLayout.createSequentialGroup()
                    .addComponent(Emas_perhitungan, javax.swing.GroupLayout.PREFERRED_SIZE, 714, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(Emas_rukun, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(Perak_pengertian, javax.swing.GroupLayout.PREFERRED_SIZE, 725, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(Perak_syarat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(Temuan_pengertian, javax.swing.GroupLayout.PREFERRED_SIZE, 725, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WdkmLayout.createSequentialGroup()
                    .addComponent(Temuan_rukun, javax.swing.GroupLayout.PREFERRED_SIZE, 714, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WdkmLayout.createSequentialGroup()
                    .addComponent(Temuan_syarat, javax.swing.GroupLayout.PREFERRED_SIZE, 714, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(Fitrah_rukun, javax.swing.GroupLayout.PREFERRED_SIZE, 725, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WdkmLayout.createSequentialGroup()
                    .addComponent(Fitrah_syarat, javax.swing.GroupLayout.PREFERRED_SIZE, 714, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(Fitrah_pengertian, javax.swing.GroupLayout.PREFERRED_SIZE, 725, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WdkmLayout.createSequentialGroup()
                    .addComponent(Galian_pengertian, javax.swing.GroupLayout.PREFERRED_SIZE, 714, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WdkmLayout.createSequentialGroup()
                    .addComponent(Galian_rukun, javax.swing.GroupLayout.PREFERRED_SIZE, 714, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WdkmLayout.createSequentialGroup()
                    .addComponent(Galian_syarat, javax.swing.GroupLayout.PREFERRED_SIZE, 714, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WdkmLayout.createSequentialGroup()
                    .addComponent(Profesi_pengertian, javax.swing.GroupLayout.PREFERRED_SIZE, 714, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WdkmLayout.createSequentialGroup()
                    .addComponent(Profesi_syarat, javax.swing.GroupLayout.PREFERRED_SIZE, 714, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WdkmLayout.createSequentialGroup()
                    .addComponent(Profesi_rukun, javax.swing.GroupLayout.PREFERRED_SIZE, 714, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WdkmLayout.createSequentialGroup()
                    .addComponent(Perdagangan_pengertian, javax.swing.GroupLayout.PREFERRED_SIZE, 714, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WdkmLayout.createSequentialGroup()
                    .addComponent(Perdagangan_syarat, javax.swing.GroupLayout.PREFERRED_SIZE, 714, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WdkmLayout.createSequentialGroup()
                    .addComponent(Perdagangan_rukun, javax.swing.GroupLayout.PREFERRED_SIZE, 714, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WdkmLayout.createSequentialGroup()
                    .addComponent(Pertanian_pengertian, javax.swing.GroupLayout.PREFERRED_SIZE, 714, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, WdkmLayout.createSequentialGroup()
                    .addComponent(Pertanian_syarat, javax.swing.GroupLayout.PREFERRED_SIZE, 714, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(WdkmLayout.createSequentialGroup()
                    .addComponent(Pertanian_rukun, javax.swing.GroupLayout.PREFERRED_SIZE, 714, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(Emas_pengertian, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(Perak_perhitungan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(Temuan_perhitungan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(Fitrah_perhitungan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(WdkmLayout.createSequentialGroup()
                    .addComponent(Galian_perhitungan, javax.swing.GroupLayout.PREFERRED_SIZE, 725, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(Pertanian_perhitungan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(WdkmLayout.createSequentialGroup()
                    .addComponent(Perdagangan_perhitungan, javax.swing.GroupLayout.PREFERRED_SIZE, 714, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(Profesi_perhitungan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(Emas_syarat, javax.swing.GroupLayout.PREFERRED_SIZE, 725, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(WdkmLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(Perak1_rukun, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        Wadah.add(Wdkm, new org.netbeans.lib.awtextra.AbsoluteConstraints(2, 51, 1120, 725));

        Kas_mesjid.setBackground(new java.awt.Color(0, 0, 255));
        Kas_mesjid.setForeground(new java.awt.Color(255, 255, 255));
        Kas_mesjid.setText("Kas Mesjid");
        Kas_mesjid.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Kas_mesjid.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        Kas_mesjid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Kas_mesjidActionPerformed(evt);
            }
        });
        Wadah.add(Kas_mesjid, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 10, 158, 32));

        Kas_fitrah.setBackground(new java.awt.Color(0, 0, 255));
        Kas_fitrah.setForeground(new java.awt.Color(255, 255, 255));
        Kas_fitrah.setText("Kas Fitrah");
        Kas_fitrah.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Kas_fitrah.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        Kas_fitrah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Kas_fitrahActionPerformed(evt);
            }
        });
        Wadah.add(Kas_fitrah, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 10, 158, 32));

        Data_masyarakat.setBackground(new java.awt.Color(0, 0, 255));
        Data_masyarakat.setForeground(new java.awt.Color(255, 255, 255));
        Data_masyarakat.setText("Data Masyarakat");
        Data_masyarakat.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Data_masyarakat.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        Data_masyarakat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Data_masyarakatActionPerformed(evt);
            }
        });
        Wadah.add(Data_masyarakat, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 10, 158, 32));

        Pengertian.setBackground(new java.awt.Color(0, 0, 255));
        Pengertian.setForeground(new java.awt.Color(255, 255, 255));
        Pengertian.setText("Pengertian");
        Pengertian.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Pengertian.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        Pengertian.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PengertianActionPerformed(evt);
            }
        });
        Wadah.add(Pengertian, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 10, 158, 32));

        Rukun.setBackground(new java.awt.Color(0, 0, 255));
        Rukun.setForeground(new java.awt.Color(255, 255, 255));
        Rukun.setText("Rukun");
        Rukun.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Rukun.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        Rukun.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RukunActionPerformed(evt);
            }
        });
        Wadah.add(Rukun, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 10, 158, 32));

        Syarat.setBackground(new java.awt.Color(0, 0, 255));
        Syarat.setForeground(new java.awt.Color(255, 255, 255));
        Syarat.setText("Syarat");
        Syarat.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Syarat.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        Syarat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SyaratActionPerformed(evt);
            }
        });
        Wadah.add(Syarat, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 10, 158, 32));

        Perhitungan.setBackground(new java.awt.Color(0, 0, 255));
        Perhitungan.setForeground(new java.awt.Color(255, 255, 255));
        Perhitungan.setText("Perhitungan");
        Perhitungan.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Perhitungan.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        Perhitungan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PerhitunganActionPerformed(evt);
            }
        });
        Wadah.add(Perhitungan, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 10, 158, 32));

        jPanel1.setBackground(new java.awt.Color(0, 102, 153));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel186.setFont(new java.awt.Font("Century", 1, 14)); // NOI18N
        jLabel186.setForeground(new java.awt.Color(255, 255, 255));
        jLabel186.setText("(Jl. Dakota No.8A Des. Sukaraja Kec Cicendo Kota Bandung)");
        jPanel1.add(jLabel186, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 67, 460, 20));

        tgl.setFont(new java.awt.Font("Century", 1, 16)); // NOI18N
        tgl.setForeground(new java.awt.Color(255, 255, 255));
        tgl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tgl.setText("date");
        jPanel1.add(tgl, new org.netbeans.lib.awtextra.AbsoluteConstraints(1160, 50, 150, 20));

        jLabel190.setFont(new java.awt.Font("Century", 1, 20)); // NOI18N
        jLabel190.setForeground(new java.awt.Color(255, 255, 255));
        jLabel190.setText("DAN KALKULATOR ZAKAT");
        jPanel1.add(jLabel190, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 30, 300, 20));

        jLabel191.setFont(new java.awt.Font("Century", 1, 20)); // NOI18N
        jLabel191.setForeground(new java.awt.Color(255, 255, 255));
        jLabel191.setText("DKM MASJID AL-IKHWAN");
        jPanel1.add(jLabel191, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 50, 300, 20));

        jLabel192.setFont(new java.awt.Font("Century", 1, 20)); // NOI18N
        jLabel192.setForeground(new java.awt.Color(255, 255, 255));
        jLabel192.setText("APLIKASI PENGELOLA KEUANGAN");
        jPanel1.add(jLabel192, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 10, 390, 20));

        jLabel193.setFont(new java.awt.Font("Century", 1, 20)); // NOI18N
        jLabel193.setForeground(new java.awt.Color(255, 51, 51));
        jLabel193.setText("DAN KALKULATOR ZAKAT");
        jPanel1.add(jLabel193, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 30, -1, -1));

        jLabel194.setFont(new java.awt.Font("Century", 1, 20)); // NOI18N
        jLabel194.setForeground(new java.awt.Color(255, 51, 51));
        jLabel194.setText("DKM MASJID AL-IKHWAN");
        jPanel1.add(jLabel194, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 50, -1, -1));

        jLabel187.setFont(new java.awt.Font("Century", 1, 14)); // NOI18N
        jLabel187.setForeground(new java.awt.Color(255, 51, 51));
        jLabel187.setText("(Jl. Dakota No.8A Des. Sukaraja Kec Cicendo Kota Bandung)");
        jPanel1.add(jLabel187, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 70, -1, -1));

        jLabel252.setFont(new java.awt.Font("Century", 1, 20)); // NOI18N
        jLabel252.setForeground(new java.awt.Color(255, 0, 51));
        jLabel252.setText("APLIKASI PENGELOLA KEUANGAN");
        jPanel1.add(jLabel252, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 10, -1, -1));

        tgl1.setFont(new java.awt.Font("Century", 1, 20)); // NOI18N
        tgl1.setForeground(new java.awt.Color(255, 255, 255));
        tgl1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tgl1.setText("date");
        jPanel1.add(tgl1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1160, 30, 150, 20));

        jLabel188.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/a.png"))); // NOI18N
        jPanel1.add(jLabel188, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, 110, 90));

        jScrollPane4.setEnabled(false);

        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane4.setViewportView(jTable4);

        jPanel1.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 40, 60, 0));

        menu.setBackground(new java.awt.Color(0, 204, 255));
        menu.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white, java.awt.Color.white));

        Dkm.setBackground(java.awt.Color.green);
        Dkm.setForeground(new java.awt.Color(255, 255, 255));
        Dkm.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/masjid-tajmahal-icon.png"))); // NOI18N
        Dkm.setText("DKM");
        Dkm.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Dkm.setHideActionText(true);
        Dkm.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Dkm.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        Dkm.setIconTextGap(10);
        Dkm.setInheritsPopupMenu(true);
        Dkm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DkmActionPerformed(evt);
            }
        });

        Emas.setBackground(java.awt.Color.green);
        Emas.setForeground(new java.awt.Color(255, 255, 255));
        Emas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/emas1.png"))); // NOI18N
        Emas.setText("Zakat Emas");
        Emas.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Emas.setHideActionText(true);
        Emas.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Emas.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        Emas.setIconTextGap(10);
        Emas.setInheritsPopupMenu(true);
        Emas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EmasActionPerformed(evt);
            }
        });

        Perak.setBackground(java.awt.Color.green);
        Perak.setForeground(new java.awt.Color(255, 255, 255));
        Perak.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/perak.png"))); // NOI18N
        Perak.setText("Zakat Perak");
        Perak.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Perak.setHideActionText(true);
        Perak.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Perak.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        Perak.setIconTextGap(10);
        Perak.setInheritsPopupMenu(true);
        Perak.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PerakActionPerformed(evt);
            }
        });

        Temuan.setBackground(java.awt.Color.green);
        Temuan.setForeground(new java.awt.Color(255, 255, 255));
        Temuan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/temuan.png"))); // NOI18N
        Temuan.setText("Zakat Temuan");
        Temuan.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Temuan.setHideActionText(true);
        Temuan.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Temuan.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        Temuan.setIconTextGap(10);
        Temuan.setInheritsPopupMenu(true);
        Temuan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TemuanActionPerformed(evt);
            }
        });

        Fitrah.setBackground(java.awt.Color.green);
        Fitrah.setForeground(new java.awt.Color(255, 255, 255));
        Fitrah.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/Rice-icon.png"))); // NOI18N
        Fitrah.setText("Zakat Fitrah");
        Fitrah.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Fitrah.setHideActionText(true);
        Fitrah.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Fitrah.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        Fitrah.setIconTextGap(10);
        Fitrah.setInheritsPopupMenu(true);
        Fitrah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FitrahActionPerformed(evt);
            }
        });

        Galian.setBackground(java.awt.Color.green);
        Galian.setForeground(new java.awt.Color(255, 255, 255));
        Galian.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/galian2.png"))); // NOI18N
        Galian.setText("Zakat Galian");
        Galian.setToolTipText("");
        Galian.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Galian.setHideActionText(true);
        Galian.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Galian.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        Galian.setIconTextGap(10);
        Galian.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GalianActionPerformed(evt);
            }
        });

        Profesi.setBackground(java.awt.Color.green);
        Profesi.setForeground(new java.awt.Color(255, 255, 255));
        Profesi.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/profesi.png"))); // NOI18N
        Profesi.setText("Zakat Profesi");
        Profesi.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Profesi.setHideActionText(true);
        Profesi.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Profesi.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        Profesi.setIconTextGap(10);
        Profesi.setInheritsPopupMenu(true);
        Profesi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ProfesiActionPerformed(evt);
            }
        });

        Perdagangan.setBackground(java.awt.Color.green);
        Perdagangan.setForeground(new java.awt.Color(255, 255, 255));
        Perdagangan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/perdagangan.png"))); // NOI18N
        Perdagangan.setText("Zakat Perdagangan");
        Perdagangan.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Perdagangan.setHideActionText(true);
        Perdagangan.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Perdagangan.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        Perdagangan.setIconTextGap(5);
        Perdagangan.setInheritsPopupMenu(true);
        Perdagangan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PerdaganganActionPerformed(evt);
            }
        });

        Pertanian.setBackground(java.awt.Color.green);
        Pertanian.setForeground(new java.awt.Color(255, 255, 255));
        Pertanian.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/pertanian1.jpg"))); // NOI18N
        Pertanian.setText("Zakat Pertanian");
        Pertanian.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Pertanian.setHideActionText(true);
        Pertanian.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Pertanian.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        Pertanian.setIconTextGap(10);
        Pertanian.setInheritsPopupMenu(true);
        Pertanian.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PertanianActionPerformed(evt);
            }
        });

        keluar.setBackground(java.awt.Color.green);
        keluar.setForeground(new java.awt.Color(255, 255, 255));
        keluar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/home1.jpg"))); // NOI18N
        keluar.setText("Keluar");
        keluar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        keluar.setHideActionText(true);
        keluar.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        keluar.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        keluar.setIconTextGap(10);
        keluar.setInheritsPopupMenu(true);
        keluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                keluarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout menuLayout = new javax.swing.GroupLayout(menu);
        menu.setLayout(menuLayout);
        menuLayout.setHorizontalGroup(
            menuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(menuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Emas, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Dkm, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Perak, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Fitrah, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Temuan, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Galian, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Profesi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Perdagangan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Pertanian, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(keluar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        menuLayout.setVerticalGroup(
            menuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(Dkm, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Emas, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Perak, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Temuan, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Fitrah, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Galian, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(Profesi, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(Perdagangan, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Pertanian, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(keluar, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1334, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(menu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Wadah, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(menu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Wadah, javax.swing.GroupLayout.DEFAULT_SIZE, 778, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 4, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

     void menu(){
       Wdkm.removeAll();
       Wdkm.repaint();
       Wdkm.revalidate();   
       Kas_fitrah.setVisible(false);
       Kas_mesjid.setVisible(false);
       Data_masyarakat.setVisible(false);
       Pengertian.setVisible(true);
       Syarat.setVisible(true);
       Rukun.setVisible(true);
       Perhitungan.setVisible(true);
    }
    private void DkmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DkmActionPerformed
        
       Wdkm.removeAll();
       Wdkm.repaint();
       Wdkm.revalidate();   
       Kas_fitrah.setVisible(true);
       Kas_mesjid.setVisible(true);
       Data_masyarakat.setVisible(true);
       Pengertian.setVisible(false);
       Syarat.setVisible(false);
       Rukun.setVisible(false);
       Perhitungan.setVisible(false);
        Emas.setBackground(Color.green);
        Dkm.setBackground(Color.orange);
        Perak.setBackground(Color.green);
        Temuan.setBackground(Color.green);
        Fitrah.setBackground(Color.green);
        Galian.setBackground(Color.green);
        Pertanian.setBackground(Color.green);
        Profesi.setBackground(Color.green);
        Perdagangan.setBackground(Color.green);   
    }//GEN-LAST:event_DkmActionPerformed

    private void EmasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EmasActionPerformed
        menu();
        Emas.setBackground(Color.orange);
        Dkm.setBackground(Color.green);
        Perak.setBackground(Color.green);
        Temuan.setBackground(Color.green);
        Fitrah.setBackground(Color.green);
        Galian.setBackground(Color.green);
        Pertanian.setBackground(Color.green);
        Profesi.setBackground(Color.green);
        Perdagangan.setBackground(Color.green);
    }//GEN-LAST:event_EmasActionPerformed

    private void PerakActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PerakActionPerformed
        menu();
        Emas.setBackground(Color.green);
        Dkm.setBackground(Color.green);
        Perak.setBackground(Color.orange);
        Temuan.setBackground(Color.green);
        Fitrah.setBackground(Color.green);
        Galian.setBackground(Color.green);
        Pertanian.setBackground(Color.green);
        Profesi.setBackground(Color.green);
        Perdagangan.setBackground(Color.green);
    }//GEN-LAST:event_PerakActionPerformed

    private void TemuanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TemuanActionPerformed
        menu();
        Emas.setBackground(Color.green);
        Dkm.setBackground(Color.green);
        Perak.setBackground(Color.green);
        Temuan.setBackground(Color.orange);
        Fitrah.setBackground(Color.green);
        Galian.setBackground(Color.green);
        Pertanian.setBackground(Color.green);
        Profesi.setBackground(Color.green);
        Perdagangan.setBackground(Color.green);
    }//GEN-LAST:event_TemuanActionPerformed

    private void FitrahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FitrahActionPerformed
        menu();
        Emas.setBackground(Color.green);
        Dkm.setBackground(Color.green);
        Perak.setBackground(Color.green);
        Temuan.setBackground(Color.green);
        Fitrah.setBackground(Color.orange);
        Galian.setBackground(Color.green);
        Pertanian.setBackground(Color.green);
        Profesi.setBackground(Color.green);
        Perdagangan.setBackground(Color.green);
    }//GEN-LAST:event_FitrahActionPerformed

    private void GalianActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GalianActionPerformed
        menu();
        Emas.setBackground(Color.green);
        Dkm.setBackground(Color.green);
        Perak.setBackground(Color.green);
        Temuan.setBackground(Color.green);
        Fitrah.setBackground(Color.green);
        Galian.setBackground(Color.orange);
        Pertanian.setBackground(Color.green);
        Profesi.setBackground(Color.green);
        Perdagangan.setBackground(Color.green);
    }//GEN-LAST:event_GalianActionPerformed

    private void ProfesiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ProfesiActionPerformed
        menu();
        Emas.setBackground(Color.green);
        Dkm.setBackground(Color.green);
        Perak.setBackground(Color.green);
        Temuan.setBackground(Color.green);
        Fitrah.setBackground(Color.green);
        Galian.setBackground(Color.green);
        Pertanian.setBackground(Color.green);
        Profesi.setBackground(Color.orange);
        Perdagangan.setBackground(Color.green);
    }//GEN-LAST:event_ProfesiActionPerformed

    private void PerdaganganActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PerdaganganActionPerformed
        menu();
        Emas.setBackground(Color.green);
        Dkm.setBackground(Color.green);
        Perak.setBackground(Color.green);
        Temuan.setBackground(Color.green);
        Fitrah.setBackground(Color.green);
        Galian.setBackground(Color.green);
        Pertanian.setBackground(Color.green);
        Profesi.setBackground(Color.green);
        Perdagangan.setBackground(Color.orange);
    }//GEN-LAST:event_PerdaganganActionPerformed

    private void PertanianActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PertanianActionPerformed
       menu();
       Emas.setBackground(Color.green);
       Dkm.setBackground(Color.green);
       Perak.setBackground(Color.green);
       Temuan.setBackground(Color.green);
       Fitrah.setBackground(Color.green);
       Galian.setBackground(Color.green);
       Pertanian.setBackground(Color.orange);
       Profesi.setBackground(Color.green);
       Perdagangan.setBackground(Color.green);
    }//GEN-LAST:event_PertanianActionPerformed

    private void PerhitunganActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PerhitunganActionPerformed
        Wdkm.removeAll();
        Wdkm.repaint();
        Wdkm.revalidate();
        if(Emas.getBackground()==Color.orange){
            Wdkm.add(Emas_perhitungan);
        }
        else if(Perak.getBackground()==Color.orange){
            Wdkm.add(Perak_perhitungan);
        }
        else if(Temuan.getBackground()==Color.orange){
            Wdkm.add(Temuan_perhitungan);
        }
        else if(Fitrah.getBackground()==Color.orange){
            Wdkm.add(Fitrah_perhitungan);
        }
        else if(Galian.getBackground()==Color.orange){
            Wdkm.add(Galian_perhitungan);
        }
        else if(Profesi.getBackground()==Color.orange){
            Wdkm.add(Profesi_perhitungan);
        }
        else if(Perdagangan.getBackground()==Color.orange){
            Wdkm.add(Perdagangan_perhitungan);
        }
        else if(Pertanian.getBackground()==Color.orange){
            Wdkm.add(Pertanian_perhitungan);
        }
        Wdkm.repaint();
        Wdkm.revalidate();
    }//GEN-LAST:event_PerhitunganActionPerformed

    private void SyaratActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SyaratActionPerformed
        Wdkm.removeAll();
        Wdkm.repaint();
        Wdkm.revalidate();
        if(Emas.getBackground()==Color.orange){
            Wdkm.add(Emas_syarat);
        }
        else if(Perak.getBackground()==Color.orange){
            Wdkm.add(Perak_syarat);
        }
        else if(Temuan.getBackground()==Color.orange){
            Wdkm.add(Temuan_syarat);
        }
        else if(Fitrah.getBackground()==Color.orange){
            Wdkm.add(Fitrah_syarat);
        }
        else if(Galian.getBackground()==Color.orange){
            Wdkm.add(Galian_syarat);
        }
        else if(Profesi.getBackground()==Color.orange){
            Wdkm.add(Profesi_syarat);
        }
        else if(Perdagangan.getBackground()==Color.orange){
            Wdkm.add(Perdagangan_syarat);
        }
        else if(Pertanian.getBackground()==Color.orange){
            Wdkm.add(Pertanian_syarat);
        }
        Wdkm.repaint();
        Wdkm.revalidate();
    }//GEN-LAST:event_SyaratActionPerformed

    private void RukunActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RukunActionPerformed
        Wdkm.removeAll();
        Wdkm.repaint();
        Wdkm.revalidate();
        if(Emas.getBackground()==Color.orange){
            Wdkm.add(Emas_rukun);
        }
        else if(Perak.getBackground()==Color.orange){
            Wdkm.add(Perak1_rukun);
        }
        else if(Temuan.getBackground()==Color.orange){
            Wdkm.add(Temuan_rukun);
        }
        else if(Fitrah.getBackground()==Color.orange){
            Wdkm.add(Fitrah_rukun);
        }
        else if(Galian.getBackground()==Color.orange){
            Wdkm.add(Galian_rukun);
        }
        else if(Profesi.getBackground()==Color.orange){
            Wdkm.add(Profesi_rukun);
        }
        else if(Perdagangan.getBackground()==Color.orange){
            Wdkm.add(Perdagangan_rukun);
        }
        else if(Pertanian.getBackground()==Color.orange){
            Wdkm.add(Pertanian_rukun);
        }
        Wdkm.repaint();
        Wdkm.revalidate();

    }//GEN-LAST:event_RukunActionPerformed

    public void setHasilgram(JTextField hasilgram) {
        this.hasilgram = hasilgram;
    }

    private void PengertianActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PengertianActionPerformed
        Wdkm.removeAll();
        Wdkm.repaint();
        Wdkm.revalidate();
        if(Emas.getBackground()==Color.orange){
            Wdkm.add(Emas_pengertian);
        }
        else if(Perak.getBackground()==Color.orange){
            Wdkm.add(Perak_pengertian);
        }
        else if(Temuan.getBackground()==Color.orange){
            Wdkm.add(Temuan_pengertian);
        }
        else if(Fitrah.getBackground()==Color.orange){
            Wdkm.add(Fitrah_pengertian);
        }
        else if(Galian.getBackground()==Color.orange){
            Wdkm.add(Galian_pengertian);
        }
        else if(Profesi.getBackground()==Color.orange){
            Wdkm.add(Profesi_pengertian);
        }
        else if(Perdagangan.getBackground()==Color.orange){
            Wdkm.add(Perdagangan_pengertian);
        }
        else if(Pertanian.getBackground()==Color.orange){
            Wdkm.add(Pertanian_pengertian);
        }
        Wdkm.repaint();
        Wdkm.revalidate();

    }//GEN-LAST:event_PengertianActionPerformed

    private void Data_masyarakatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Data_masyarakatActionPerformed
        Wdkm.removeAll();
        Wdkm.repaint();
        Wdkm.revalidate();
        Wdkm.add(PData);
        Wdkm.repaint();
        Wdkm.revalidate();
        Tampil_Data_Masyarakat g=new Tampil_Data_Masyarakat();
        setLocationRelativeTo(this);
        jTable3.setModel(g.tampilMasyarakat());
    }//GEN-LAST:event_Data_masyarakatActionPerformed

    private void Kas_fitrahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Kas_fitrahActionPerformed
        Wdkm.removeAll();
        Wdkm.repaint();
        Wdkm.revalidate();
        Wdkm.add(PKas_F);
        Wdkm.repaint();
        Wdkm.revalidate();
        Tampil_Kas_Fitrah g=new Tampil_Kas_Fitrah();
        setLocationRelativeTo(this);
        jTable2.setModel(g.tampilKasFitrah());
    }//GEN-LAST:event_Kas_fitrahActionPerformed

    private void Kas_mesjidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Kas_mesjidActionPerformed
        Wdkm.removeAll();
        Wdkm.repaint();
        Wdkm.revalidate();
        Wdkm.add(PKas_m);
        Wdkm.repaint();
        Wdkm.revalidate();
        Tampil_Kas_Umum g=new Tampil_Kas_Umum();
        setLocationRelativeTo(this);
        jTable1.setModel(g.tampilKas());
        
    }//GEN-LAST:event_Kas_mesjidActionPerformed

    private void hasiltemuanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hasiltemuanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_hasiltemuanActionPerformed

    private void hasilfitrahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hasilfitrahActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_hasilfitrahActionPerformed

    private void hasilgalianActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hasilgalianActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_hasilgalianActionPerformed

    private void keluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_keluarActionPerformed
     int p=JOptionPane.showConfirmDialog (null, "Yakin Akan Keluar!","Peringatan!",JOptionPane.YES_OPTION);
        if (p == 0) {
            System.exit(0);
        }
        
    }//GEN-LAST:event_keluarActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        berat.setText("");
        harga.setText("");
        hasilgram.setText("");
        hasilrupiah.setText("");
    }//GEN-LAST:event_jButton4ActionPerformed
    Cek w=new Cek();
    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        if(berat.getText().equals("") || harga.getText().equals("") || berat.getText().equals(" ") || harga.getText().equals(" ") ){
                JOptionPane.showMessageDialog(null, "Data harus diisi!");
        }
        else{
            if(Double.parseDouble(berat.getText())<Double.parseDouble(nishab.getText())){
                JOptionPane.showMessageDialog(null, "Anda Belum Wajib Zakat");
            }
            else{
                Emas a=new Emas(Double.parseDouble(berat.getText()),Double.parseDouble(harga.getText()));
                hasilrupiah.setText(String.valueOf(a.jumlah()));
                hasilgram.setText(String.valueOf(a.jumlah1()));
                Cek j=new Cek();
               
                
            }
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        if(beratperak.getText().equals("") || hargaperak.getText().equals("") || beratperak.getText().equals(" ") || hargaperak.getText().equals(" ") ){
            JOptionPane.showMessageDialog(null, "Data harus diisi!");
        }
        else{
            if(Double.parseDouble(beratperak.getText())<Double.parseDouble(nishabperak.getText())){
                JOptionPane.showMessageDialog(null, "Anda Belum Wajib Zakat");
            }
            else{
                Perak b=new Perak(Double.parseDouble(beratperak.getText()));
                b.setJumlah_harta((int) Double.parseDouble(hargaperak.getText()));
                hasilperak1.setText(""+b.jumlah());
                hasilperak.setText(""+b.jumlah1());
        }
     }
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
      if(namatemuan.getText().equals("") || nilaitemuan.getText().equals("") || namatemuan.getText().equals(" ") || nilaitemuan.getText().equals(" ") ){
            JOptionPane.showMessageDialog(null, "Data harus diisi!");
      }
      else{
          temuan b=new temuan(Double.parseDouble(nilaitemuan.getText()));
          hasiltemuan.setText(String.valueOf(b.jumlah()).toString());
      }
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
       if(jumlahfitrah.getText().equals("") || hargafitrah.getText().equals("") || jumlahfitrah.getText().equals(" ") || hargafitrah.getText().equals(" ") ){
            JOptionPane.showMessageDialog(null, "Data harus diisi!");
       }
        else{
            Fitrah b=new Fitrah(Long.parseLong((jumlahfitrah.getText())),Long.parseLong(hargafitrah.getText()));
            hasilfitrah.setText(""+b.jumlah());
        }
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
         if(namagalian.getText().equals("") || nilaigalian.getText().equals("") || namagalian.getText().equals(" ") || nilaigalian.getText().equals(" ") ){
            JOptionPane.showMessageDialog(null, "Data harus diisi!");
         }
         else{
             Galian b=new Galian(Long.parseLong(nilaigalian.getText()));
             hasilgalian.setText(""+b.jumlah());  
         }
    }//GEN-LAST:event_jButton13ActionPerformed

    private void jButton19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton19ActionPerformed
        if(gajiprofesi.getText().equals("") || bonusprofesi.getText().equals("") || pengeluaranprofesi.getText().equals("")){
            JOptionPane.showMessageDialog(null, "Data harus diisi!");
        }
        else{ 
            if((Double.parseDouble(gajiprofesi.getText())+Double.parseDouble(bonusprofesi.getText())-Double.parseDouble(pengeluaranprofesi.getText()))<Double.parseDouble(nishabprofesi.getText())){
                JOptionPane.showMessageDialog(null, "Anda Belum Wajib Zakat");
            }
            else{
                Profesi b=new Profesi(Double.parseDouble(gajiprofesi.getText()),Double.parseDouble(bonusprofesi.getText()),Double.parseDouble(pengeluaranprofesi.getText()));
                hasilprofesi1.setText(""+b.jumlah());  
            }
        }
    }//GEN-LAST:event_jButton19ActionPerformed

    private void jButton20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton20ActionPerformed
       gajiprofesi.setText("");
       bonusprofesi.setText("");
       pengeluaranprofesi.setText("");
       hasilprofesi1.setText("");
       
    }//GEN-LAST:event_jButton20ActionPerformed
   
    private void bonusprofesiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bonusprofesiActionPerformed
      
    }//GEN-LAST:event_bonusprofesiActionPerformed

    private void jButton17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton17ActionPerformed
        if(modaldagang.getText().equals("") || bonusdagang.getText().equals("") || (jRadioButton1.isSelected()==false && jRadioButton2.isSelected()==false)||jumlahlbrg.getText().equals("") || hutangdagang.getText().equals("") ){
            JOptionPane.showMessageDialog(null, "Data harus diisi!");
        }
        else{
            if (jRadioButton1.isSelected()){
                Perdagangan b=new Perdagangan(Double.parseDouble(modaldagang.getText()),Double.parseDouble(bonusdagang.getText()),Double.parseDouble(hutangdagang.getText()),Double.parseDouble(jumlahlbrg.getText()),1);
                hasildagang.setText(""+b.jumlah());
            }
            else if (jRadioButton2.isSelected()){
                Perdagangan b=new Perdagangan(Double.parseDouble(modaldagang.getText()),Double.parseDouble(bonusdagang.getText()),Double.parseDouble(hutangdagang.getText()),Double.parseDouble(jumlahlbrg.getText()),2);
                hasildagang.setText(""+b.jumlah());
            }
        }
    }//GEN-LAST:event_jButton17ActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
         if(berattani.getText().equals("") || hargapokoktani.getText().equals("") || (jRadioButton3.isSelected()==false && jRadioButton4.isSelected()==false) ){
            JOptionPane.showMessageDialog(null, "Data harus diisi!");
        }
        else{
            if(Double.parseDouble(berattani.getText())<Double.parseDouble(nishabtani.getText())){
                JOptionPane.showMessageDialog(null, "Anda Belum Wajib Zakat");
            }
            else{
                if (jRadioButton3.isSelected()){
                    Pertanian b=new Pertanian(Double.parseDouble(berattani.getText()),Double.parseDouble(hargapokoktani.getText()),1);
                    hasiltani1.setText(""+b.jumlah());
                    hasiltani.setText(""+b.jumlah1());
                } 
                else if (jRadioButton4.isSelected()){
                    Pertanian b=new Pertanian(Double.parseDouble(berattani.getText()),Double.parseDouble(hargapokoktani.getText()),2);
                    hasiltani1.setText(""+b.jumlah()); 
                    hasiltani.setText(""+b.jumlah1());
                }
            }
        }  
    }//GEN-LAST:event_jButton15ActionPerformed

    public void setjTable2() {
        Tampil_Kas_Fitrah g=new Tampil_Kas_Fitrah();
        setLocationRelativeTo(this);
        jTable2.setModel(g.tampilKasFitrah());
    }

    private void Ok4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Ok4ActionPerformed
       if(tambahkk.getText().equals("") || tambahjumlah.getText().equals("") || tambahkepala.getText().equals("") || tambahkepala.getText().equals(" ") ){
            JOptionPane.showMessageDialog(null, "Data harus diisi!");
         }
        else{  
            Tampil_Data_Masyarakat g=new Tampil_Data_Masyarakat();
            setLocationRelativeTo(this);
            isi.setNo_kk(tambahkk.getText());
            isi.setKepala(tambahkepala.getText());
            isi.setJumlah(Integer.parseInt(tambahjumlah.getText()));
            b.TambahData(isi);
            jTable3.setModel(g.tampilMasyarakat());
            tambahkk.setText("");
            tambahkepala.setText("");
            tambahjumlah.setText("");
       }
    }//GEN-LAST:event_Ok4ActionPerformed
    
    private void Ok2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Ok2ActionPerformed
         if(ubahkk.getText().equals("") || ubahjumlah.getText().equals("") || ubahkepala.getText().equals("") || ubahkk.getText().equals(" ") || ubahjumlah.getText().equals(" ") || ubahkepala.getText().equals(" ") ){
            JOptionPane.showMessageDialog(null, "Data harus diisi!");
        }
        else{
            Tampil_Data_Masyarakat g=new Tampil_Data_Masyarakat();
            setLocationRelativeTo(this);
            isi.setNo_kk(ubahkk.getText());
            isi.setKepala(ubahkepala.getText());
            isi.setJumlah(Integer.parseInt(ubahjumlah.getText()));
            b.UbahData(isi);
            jTable3.setModel(g.tampilMasyarakat());
            ubahkk.setText("");
            ubahkepala.setText("");
            ubahjumlah.setText("");
        }
    }//GEN-LAST:event_Ok2ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        beratperak.setText("");
        hargaperak.setText("");
        hasilperak.setText("");
        hasilperak1.setText("");
        
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
     namatemuan.setText("");
     nilaitemuan.setText("");
     hasiltemuan.setText("");
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
       jumlahfitrah.setText("");
       hargafitrah.setText("");
       hasilfitrah.setText("");
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
       namagalian.setText("");
       nilaigalian.setText("");
       hasilgalian.setText("");
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton16ActionPerformed
        berattani.setText("");
        hargapokoktani.setText("");
        hasiltani.setText("");
        hasiltani1.setText("");
        
        
    }//GEN-LAST:event_jButton16ActionPerformed

    private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton18ActionPerformed
       modaldagang.setText("");
       jumlahlbrg.setText("");
       bonusdagang.setText("");
       hutangdagang.setText("");
       hasildagang.setText("");
    }//GEN-LAST:event_jButton18ActionPerformed

    private void jTable3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable3MouseClicked
      int row=jTable3.getSelectedRow();
      No=jTable3.getModel().getValueAt(row, 0).toString();
      ubahkk.setText(jTable3.getModel().getValueAt(row, 0).toString());
      ubahkepala.setText(jTable3.getModel().getValueAt(row, 1).toString());
      ubahjumlah.setText(jTable3.getModel().getValueAt(row, 2).toString());
      hapuskk.setText(jTable3.getModel().getValueAt(row, 0).toString());
      
    }//GEN-LAST:event_jTable3MouseClicked

    private void hapuskk1MouseWheelMoved(java.awt.event.MouseWheelEvent evt) {//GEN-FIRST:event_hapuskk1MouseWheelMoved
       
    }//GEN-LAST:event_hapuskk1MouseWheelMoved

    private void Ok1AncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_Ok1AncestorAdded

    }//GEN-LAST:event_Ok1AncestorAdded

    private void hapuskk1PropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_hapuskk1PropertyChange
      Ambil_Data_Masyarakat h=new Ambil_Data_Masyarakat();
       h.tampilMasyarakat(hapuskk1.getText());
       Tampil_Data_Masyarakat g=new Tampil_Data_Masyarakat();
       setLocationRelativeTo(this);
       jTable3.setModel(g.tampilMasyarakat());
    }//GEN-LAST:event_hapuskk1PropertyChange

    private void hapuskk1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_hapuskk1KeyTyped
        
        Tampil_Data_Masyarakat g=new Tampil_Data_Masyarakat();
        setLocationRelativeTo(this);
        isi.setKepala(hapuskk1.getText());
        jTable3.setModel(b.tampilKasFitrah(isi));
        
    }//GEN-LAST:event_hapuskk1KeyTyped

    private void hapuskk1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hapuskk1ActionPerformed
       Ambil_Data_Masyarakat h=new Ambil_Data_Masyarakat();
       h.tampilMasyarakat(hapuskk1.getText());
       Tampil_Data_Masyarakat g=new Tampil_Data_Masyarakat();
       setLocationRelativeTo(this);
       jTable3.setModel(g.tampilMasyarakat());
    }//GEN-LAST:event_hapuskk1ActionPerformed

    private void OkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OkActionPerformed
        if(Keterangan.getText().equals("") || Jumlah.getText().equals("") || (jRadioButton5.isSelected()==false && jRadioButton6.isSelected()==false) || Keterangan.getText().equals(" ") || Jumlah.getText().equals(" ")){
            JOptionPane.showMessageDialog(null, "Data harus diisi!");
         }
        else{
        String tglll=String.valueOf(tgll.format(Tanggal.getDate()));
        Entitas_Kas_Umum t=new Entitas_Kas_Umum();
        Kas_Umum h=new Kas_Umum();
        Ambil_Saldo_Kas q=new Ambil_Saldo_Kas();
        Tampil_Kas_Umum g=new Tampil_Kas_Umum();
        setLocationRelativeTo(this);
        q.tampilsaldo();
        jTable4.setModel(q.tampilsaldo());
        No=jTable4.getModel().getValueAt(0, 0).toString();
        t.setKeterangan(Keterangan.getText());
        t.setKredit(Integer.parseInt(Jumlah.getText()));
        t.setDebet(Integer.parseInt(Jumlah.getText()));
        t.setTanggal(tglll);
        int u=Integer.parseInt(Jumlah.getText());
        int y=0;
        if (jRadioButton6.isSelected()){
             y=u+Integer.parseInt(No);
        
        } 
        else if (jRadioButton5.isSelected()){
            y=Integer.parseInt(No)-u;
       }
        t.setSaldo(y);
        q.UbahData(y);
        
        if (jRadioButton6.isSelected()){
            h.TambahData(t);
        
        } 
        else if (jRadioButton5.isSelected()){
            h.KurangData(t);
       }
        setLocationRelativeTo(this);
        jTable1.setModel(g.tampilKas());
        Keterangan.setText("");
        Jumlah.setText("");
        }
    }//GEN-LAST:event_OkActionPerformed

    private void gajiprofesiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gajiprofesiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_gajiprofesiActionPerformed

    private void gajiprofesiKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_gajiprofesiKeyTyped
        a.angka(gajiprofesi, evt);
    }//GEN-LAST:event_gajiprofesiKeyTyped

    private void gajiprofesiKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_gajiprofesiKeyPressed
     
    }//GEN-LAST:event_gajiprofesiKeyPressed

    private void bonusprofesiKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_bonusprofesiKeyTyped
         a.angka(bonusprofesi, evt);
    }//GEN-LAST:event_bonusprofesiKeyTyped

    

    private void Ok1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Ok1ActionPerformed
        if(hapuskk.getText().equals("")||hapuskk.getText().equals(" ")){
            JOptionPane.showMessageDialog(null, "Data harus diisi!");
         }
        else{
            Tampil_Data_Masyarakat g=new Tampil_Data_Masyarakat();
            setLocationRelativeTo(this);
            isi.setNo_kk(hapuskk.getText());
            b.HapusData(isi);
            jTable3.setModel(g.tampilMasyarakat());
            hapuskk.setText("");
        }
    }//GEN-LAST:event_Ok1ActionPerformed

    private void PDataFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_PDataFocusLost
      tambahkk.setText("");
      tambahjumlah.setText("");
      tambahkepala.setText("");
      ubahjumlah.setText("");
      ubahkepala.setText("");
      ubahkk.setText("");
      hapuskk.setText("");
      hapuskk1.setText("");
    }//GEN-LAST:event_PDataFocusLost

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        
        if(No_kk.getText().equals("") || kepala.getText().equals("") || anggota.getText().equals("") || jumlah.getText().equals("") || No_kk.getText().equals(" ") || kepala.getText().equals(" ") || anggota.getText().equals(" ") || jumlah.getText().equals(" ")){
            JOptionPane.showMessageDialog(null, "Data harus diisi!");
         }
        else{
            Induk h=new Induk();
            h.setjTable2();
            Entitas_Kas_Fitrah f=new Entitas_Kas_Fitrah();
            Kas_Fitrah k=new Kas_Fitrah();
            Ambil_Saldo_Kas_Fitrah a=new Ambil_Saldo_Kas_Fitrah();
            String tglll=String.valueOf(tgll.format(Tanggal.getDate()));
            f.setTanggal(tglll);
            f.setNo_kk(No_kk.getText());
            f.setKepala(kepala.getText());
            f.setAnggota(anggota.getText());
            f.setKredit(Integer.parseInt(jumlah.getText()));
            a.tampilsaldo();
            jTable4.setModel(a.tampilsaldo());
            int y=Integer.parseInt(jTable4.getModel().getValueAt(0, 0).toString());
            int z=y-Integer.parseInt(jumlah.getText());
            f.setSaldo(z);
            k.KurangData(f);
            a.UbahData(z);
            Kas_Fitrah g=new Kas_Fitrah();
            setLocationRelativeTo(this);
            jTable2.setModel(g.tampilKasFitrah());
            No_kk.setText("");
            anggota.setText("");
            kepala.setText("");
            jumlah.setText("");
        }
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton21ActionPerformed
         if(No_kk1.getText().equals("")||No_kk1.getText().equals(" ")){
            JOptionPane.showMessageDialog(null, "Data harus diisi!");
         }
        else{
            Induk h=new Induk();
            h.setjTable2(); 
            Entitas_Kas_Fitrah f=new Entitas_Kas_Fitrah();
            Kas_Fitrah k=new Kas_Fitrah();
            Ambil_Saldo_Kas_Fitrah a=new Ambil_Saldo_Kas_Fitrah();
            f.setTanggal(h.getTgl());
            f.setNo_kk(No_kk1.getText());
            f.setKepala(kepala1.getText());
            f.setAnggota(anggota1.getText());
            a.tampilsaldo();
            jTable4.setModel(a.tampilsaldo());
            int y=Integer.parseInt(jTable4.getModel().getValueAt(0, 0).toString());
             char q[]=jumlah1.getText().toCharArray();
             String e="";
             for (int i = 0; i < q.length-2; i++) {
                 e+=q[i];
             }
             jumlah1.setText(e);
            f.setDebet(Integer.parseInt(jumlah1.getText()));
            int z=y+Integer.parseInt(jumlah1.getText());
            f.setSaldo(z);
            k.TambahData(f);
            a.UbahData(z);
            Kas_Fitrah g=new Kas_Fitrah();
            setLocationRelativeTo(this);
            jTable2.setModel(g.tampilKasFitrah());
            No_kk1.setText("");
            anggota1.setText("");
            kepala1.setText("");
            jumlah1.setText("");
         }
    }//GEN-LAST:event_jButton21ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        Entitas_Data_Masyarakat f=new Entitas_Data_Masyarakat();
        f.setNo_kk(No_kk1.getText());
        Tampil_Data_Masyarakat r=new Tampil_Data_Masyarakat();
        r.tampilMasyarakat1(f);
        setLocationRelativeTo(this);
        jTable4.setModel(r.tampilMasyarakat1(f));
        kepala1.setText(jTable4.getModel().getValueAt(0, 1).toString());
        anggota1.setText(jTable4.getModel().getValueAt(0, 2).toString());
        double a=Double.parseDouble(anggota1.getText())*10000*2.5;
        jumlah1.setText(a+"");
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        try {
            Boolean complet=jTable2.print();
        } catch (Exception e) {
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
      try {
            Boolean complet=jTable1.print();
        } catch (Exception e) {
        }
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton22ActionPerformed
       try {
            Boolean complet=jTable3.print();
        } catch (Exception e) {
        }
    }//GEN-LAST:event_jButton22ActionPerformed

    private void namagalianKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_namagalianKeyTyped
        a.huruf(namagalian, evt);
    }//GEN-LAST:event_namagalianKeyTyped

    private void nilaigalianKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nilaigalianKeyTyped
     a.angka(nilaigalian, evt);
    }//GEN-LAST:event_nilaigalianKeyTyped

    private void hargaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_hargaKeyTyped
        a.angka(harga, evt);
    }//GEN-LAST:event_hargaKeyTyped

    private void hargaperakKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_hargaperakKeyTyped
       a.angka(hargaperak, evt);
    }//GEN-LAST:event_hargaperakKeyTyped

    private void namatemuanKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_namatemuanKeyTyped
     a.huruf(namatemuan,evt);
    }//GEN-LAST:event_namatemuanKeyTyped

    private void nilaitemuanKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nilaitemuanKeyTyped
     a.angka(nilaitemuan, evt);
    }//GEN-LAST:event_nilaitemuanKeyTyped

    private void jumlahfitrahKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jumlahfitrahKeyTyped
     a.angka(jumlahfitrah, evt);
    }//GEN-LAST:event_jumlahfitrahKeyTyped

    private void hargafitrahKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_hargafitrahKeyTyped
       a.angka(hargafitrah, evt);
    }//GEN-LAST:event_hargafitrahKeyTyped

    private void hargapokoktaniKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_hargapokoktaniKeyTyped
     a.angka(hargapokoktani, evt);
    }//GEN-LAST:event_hargapokoktaniKeyTyped

    private void modaldagangKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_modaldagangKeyTyped
    a.angka(modaldagang, evt);
    }//GEN-LAST:event_modaldagangKeyTyped

    private void bonusdagangKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_bonusdagangKeyTyped
     a.angka(bonusdagang, evt);
    }//GEN-LAST:event_bonusdagangKeyTyped

    private void jumlahlbrgKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jumlahlbrgKeyTyped
    a.angka(jumlahlbrg, evt);
    }//GEN-LAST:event_jumlahlbrgKeyTyped

    private void hutangdagangKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_hutangdagangKeyTyped
    a.angka(hutangdagang, evt);
    }//GEN-LAST:event_hutangdagangKeyTyped

    private void pengeluaranprofesiKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pengeluaranprofesiKeyTyped
      a.angka(pengeluaranprofesi, evt);
    }//GEN-LAST:event_pengeluaranprofesiKeyTyped

    private void KeteranganKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_KeteranganKeyTyped
     a.huruf(Keterangan,evt);
    }//GEN-LAST:event_KeteranganKeyTyped

    private void JumlahKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JumlahKeyTyped
       a.angka(Jumlah, evt);
    }//GEN-LAST:event_JumlahKeyTyped

    private void tambahkepalaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tambahkepalaKeyTyped
       a.huruf(tambahkepala,evt);
    }//GEN-LAST:event_tambahkepalaKeyTyped

    private void tambahjumlahKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tambahjumlahKeyTyped
     a.angka(tambahjumlah, evt);
    }//GEN-LAST:event_tambahjumlahKeyTyped

    private void tambahkkKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tambahkkKeyTyped
      a.kk(tambahkk, evt);
    }//GEN-LAST:event_tambahkkKeyTyped

    private void ubahkkKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ubahkkKeyTyped
       a.kk(ubahkk, evt);
    }//GEN-LAST:event_ubahkkKeyTyped

    private void ubahkepalaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ubahkepalaKeyTyped
       a.huruf(ubahkepala,evt);
    }//GEN-LAST:event_ubahkepalaKeyTyped

    private void ubahjumlahKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ubahjumlahKeyTyped
      a.angka(ubahjumlah, evt);
    }//GEN-LAST:event_ubahjumlahKeyTyped

    private void hapuskkKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_hapuskkKeyTyped
       a.kk(hapuskk, evt);
    }//GEN-LAST:event_hapuskkKeyTyped

    private void No_kkKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_No_kkKeyTyped
       a.kk(No_kk, evt);
    }//GEN-LAST:event_No_kkKeyTyped

    private void kepalaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_kepalaKeyTyped
      a.huruf(kepala,evt);
    }//GEN-LAST:event_kepalaKeyTyped

    private void anggotaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_anggotaKeyTyped
       a.angka(anggota, evt);
    }//GEN-LAST:event_anggotaKeyTyped

    private void jumlahKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jumlahKeyTyped
      a.angka(jumlah, evt);
    }//GEN-LAST:event_jumlahKeyTyped

    private void No_kk1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_No_kk1KeyTyped
      a.kk(No_kk1, evt);
    }//GEN-LAST:event_No_kk1KeyTyped

    private void kepala1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_kepala1KeyTyped
      a.huruf(kepala1,evt);
    }//GEN-LAST:event_kepala1KeyTyped

    private void anggota1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_anggota1KeyTyped
      a.angka(anggota1, evt);
    }//GEN-LAST:event_anggota1KeyTyped

    private void jumlah1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jumlah1KeyTyped
    a.angka(jumlah1, evt);
    }//GEN-LAST:event_jumlah1KeyTyped

    private void beratKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_beratKeyTyped
       a.doube(berat, evt);
    }//GEN-LAST:event_beratKeyTyped

    private void beratperakKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_beratperakKeyTyped
      a.doube(beratperak, evt);
    }//GEN-LAST:event_beratperakKeyTyped

    private void berattaniKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_berattaniKeyTyped
       a.doube(berattani, evt);
    }//GEN-LAST:event_berattaniKeyTyped

    public void getjTable2() {
        Tampil_Kas_Fitrah g=new Tampil_Kas_Fitrah();
        setLocationRelativeTo(this);
        jTable2.setModel(g.tampilKasFitrah());
    }

   
   private void hapuskk1ActionPerformed(java.awt.event.ActionListener evt) {                                         
       Ambil_Data_Masyarakat h=new Ambil_Data_Masyarakat();
       h.tampilMasyarakat(hapuskk1.getText());
       Tampil_Data_Masyarakat g=new Tampil_Data_Masyarakat();
       setLocationRelativeTo(this);
       jTable3.setModel(g.tampilMasyarakat());
    }
   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Data_masyarakat;
    private javax.swing.JButton Dkm;
    private javax.swing.JButton Emas;
    private javax.swing.JPanel Emas_pengertian;
    private javax.swing.JPanel Emas_perhitungan;
    private javax.swing.JPanel Emas_rukun;
    private javax.swing.JPanel Emas_syarat;
    private javax.swing.JButton Fitrah;
    private javax.swing.JPanel Fitrah_pengertian;
    private javax.swing.JPanel Fitrah_perhitungan;
    private javax.swing.JPanel Fitrah_rukun;
    private javax.swing.JPanel Fitrah_syarat;
    private javax.swing.JButton Galian;
    private javax.swing.JPanel Galian_pengertian;
    private javax.swing.JPanel Galian_perhitungan;
    private javax.swing.JPanel Galian_rukun;
    private javax.swing.JPanel Galian_syarat;
    private javax.swing.JTextField Jumlah;
    private javax.swing.JButton Kas_fitrah;
    private javax.swing.JButton Kas_mesjid;
    private javax.swing.JTextField Keterangan;
    private javax.swing.JTextField No_kk;
    private javax.swing.JTextField No_kk1;
    private javax.swing.JButton Ok;
    private javax.swing.JButton Ok1;
    private javax.swing.JButton Ok2;
    private javax.swing.JButton Ok4;
    private javax.swing.JPanel PData;
    private javax.swing.JPanel PKas_F;
    private javax.swing.JPanel PKas_m;
    private javax.swing.JButton Pengertian;
    private javax.swing.JButton Perak;
    private javax.swing.JPanel Perak1_rukun;
    private javax.swing.JPanel Perak_pengertian;
    private javax.swing.JPanel Perak_perhitungan;
    private javax.swing.JPanel Perak_rukun;
    private javax.swing.JPanel Perak_syarat;
    private javax.swing.JButton Perdagangan;
    private javax.swing.JPanel Perdagangan_pengertian;
    private javax.swing.JPanel Perdagangan_perhitungan;
    private javax.swing.JPanel Perdagangan_rukun;
    private javax.swing.JPanel Perdagangan_syarat;
    private javax.swing.JButton Perhitungan;
    private javax.swing.JButton Pertanian;
    private javax.swing.JPanel Pertanian_pengertian;
    private javax.swing.JPanel Pertanian_perhitungan;
    private javax.swing.JPanel Pertanian_rukun;
    private javax.swing.JPanel Pertanian_syarat;
    private javax.swing.JButton Profesi;
    private javax.swing.JPanel Profesi_pengertian;
    private javax.swing.JPanel Profesi_perhitungan;
    private javax.swing.JPanel Profesi_rukun;
    private javax.swing.JPanel Profesi_syarat;
    private javax.swing.JButton Rukun;
    private javax.swing.JButton Syarat;
    private com.toedter.calendar.JDateChooser Tanggal;
    private com.toedter.calendar.JDateChooser Tanggal1;
    private javax.swing.JButton Temuan;
    private javax.swing.JPanel Temuan_pengertian;
    private javax.swing.JPanel Temuan_perhitungan;
    private javax.swing.JPanel Temuan_rukun;
    private javax.swing.JPanel Temuan_syarat;
    private javax.swing.JPanel Wadah;
    private javax.swing.JPanel Wdkm;
    private javax.swing.JTextField anggota;
    private javax.swing.JTextField anggota1;
    private javax.swing.JTextField berat;
    private javax.swing.JTextField beratperak;
    private javax.swing.JTextField berattani;
    private javax.swing.JTextField bonusdagang;
    private javax.swing.JTextField bonusprofesi;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.JTextField gajiprofesi;
    private javax.swing.JTextField hapuskk;
    private javax.swing.JTextField hapuskk1;
    private javax.swing.JTextField harga;
    private javax.swing.JTextField hargafitrah;
    private javax.swing.JTextField hargaperak;
    private javax.swing.JTextField hargapokoktani;
    private javax.swing.JTextField hasildagang;
    private javax.swing.JTextField hasilfitrah;
    private javax.swing.JTextField hasilgalian;
    private javax.swing.JTextField hasilgram;
    private javax.swing.JTextField hasilperak;
    private javax.swing.JTextField hasilperak1;
    private javax.swing.JTextField hasilprofesi1;
    private javax.swing.JTextField hasilrupiah;
    private javax.swing.JTextField hasiltani;
    private javax.swing.JTextField hasiltani1;
    private javax.swing.JTextField hasiltemuan;
    private javax.swing.JTextField hutangdagang;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton22;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel100;
    private javax.swing.JLabel jLabel101;
    private javax.swing.JLabel jLabel102;
    private javax.swing.JLabel jLabel103;
    private javax.swing.JLabel jLabel104;
    private javax.swing.JLabel jLabel105;
    private javax.swing.JLabel jLabel106;
    private javax.swing.JLabel jLabel107;
    private javax.swing.JLabel jLabel108;
    private javax.swing.JLabel jLabel109;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel110;
    private javax.swing.JLabel jLabel111;
    private javax.swing.JLabel jLabel112;
    private javax.swing.JLabel jLabel113;
    private javax.swing.JLabel jLabel114;
    private javax.swing.JLabel jLabel115;
    private javax.swing.JLabel jLabel116;
    private javax.swing.JLabel jLabel117;
    private javax.swing.JLabel jLabel118;
    private javax.swing.JLabel jLabel119;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel120;
    private javax.swing.JLabel jLabel121;
    private javax.swing.JLabel jLabel122;
    private javax.swing.JLabel jLabel123;
    private javax.swing.JLabel jLabel124;
    private javax.swing.JLabel jLabel125;
    private javax.swing.JLabel jLabel126;
    private javax.swing.JLabel jLabel127;
    private javax.swing.JLabel jLabel128;
    private javax.swing.JLabel jLabel129;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel130;
    private javax.swing.JLabel jLabel131;
    private javax.swing.JLabel jLabel132;
    private javax.swing.JLabel jLabel133;
    private javax.swing.JLabel jLabel134;
    private javax.swing.JLabel jLabel135;
    private javax.swing.JLabel jLabel136;
    private javax.swing.JLabel jLabel137;
    private javax.swing.JLabel jLabel138;
    private javax.swing.JLabel jLabel139;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel140;
    private javax.swing.JLabel jLabel141;
    private javax.swing.JLabel jLabel142;
    private javax.swing.JLabel jLabel143;
    private javax.swing.JLabel jLabel144;
    private javax.swing.JLabel jLabel145;
    private javax.swing.JLabel jLabel146;
    private javax.swing.JLabel jLabel147;
    private javax.swing.JLabel jLabel148;
    private javax.swing.JLabel jLabel149;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel150;
    private javax.swing.JLabel jLabel151;
    private javax.swing.JLabel jLabel152;
    private javax.swing.JLabel jLabel153;
    private javax.swing.JLabel jLabel154;
    private javax.swing.JLabel jLabel155;
    private javax.swing.JLabel jLabel156;
    private javax.swing.JLabel jLabel157;
    private javax.swing.JLabel jLabel158;
    private javax.swing.JLabel jLabel159;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel160;
    private javax.swing.JLabel jLabel161;
    private javax.swing.JLabel jLabel162;
    private javax.swing.JLabel jLabel163;
    private javax.swing.JLabel jLabel164;
    private javax.swing.JLabel jLabel165;
    private javax.swing.JLabel jLabel166;
    private javax.swing.JLabel jLabel167;
    private javax.swing.JLabel jLabel168;
    private javax.swing.JLabel jLabel169;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel170;
    private javax.swing.JLabel jLabel171;
    private javax.swing.JLabel jLabel172;
    private javax.swing.JLabel jLabel173;
    private javax.swing.JLabel jLabel174;
    private javax.swing.JLabel jLabel175;
    private javax.swing.JLabel jLabel176;
    private javax.swing.JLabel jLabel177;
    private javax.swing.JLabel jLabel178;
    private javax.swing.JLabel jLabel179;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel180;
    private javax.swing.JLabel jLabel181;
    private javax.swing.JLabel jLabel182;
    private javax.swing.JLabel jLabel183;
    private javax.swing.JLabel jLabel184;
    private javax.swing.JLabel jLabel185;
    private javax.swing.JLabel jLabel186;
    private javax.swing.JLabel jLabel187;
    private javax.swing.JLabel jLabel188;
    private javax.swing.JLabel jLabel189;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel190;
    private javax.swing.JLabel jLabel191;
    private javax.swing.JLabel jLabel192;
    private javax.swing.JLabel jLabel193;
    private javax.swing.JLabel jLabel194;
    private javax.swing.JLabel jLabel195;
    private javax.swing.JLabel jLabel196;
    private javax.swing.JLabel jLabel197;
    private javax.swing.JLabel jLabel198;
    private javax.swing.JLabel jLabel199;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel200;
    private javax.swing.JLabel jLabel201;
    private javax.swing.JLabel jLabel202;
    private javax.swing.JLabel jLabel203;
    private javax.swing.JLabel jLabel204;
    private javax.swing.JLabel jLabel205;
    private javax.swing.JLabel jLabel206;
    private javax.swing.JLabel jLabel207;
    private javax.swing.JLabel jLabel208;
    private javax.swing.JLabel jLabel209;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel210;
    private javax.swing.JLabel jLabel211;
    private javax.swing.JLabel jLabel212;
    private javax.swing.JLabel jLabel213;
    private javax.swing.JLabel jLabel214;
    private javax.swing.JLabel jLabel215;
    private javax.swing.JLabel jLabel216;
    private javax.swing.JLabel jLabel217;
    private javax.swing.JLabel jLabel218;
    private javax.swing.JLabel jLabel219;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel220;
    private javax.swing.JLabel jLabel221;
    private javax.swing.JLabel jLabel222;
    private javax.swing.JLabel jLabel223;
    private javax.swing.JLabel jLabel224;
    private javax.swing.JLabel jLabel225;
    private javax.swing.JLabel jLabel226;
    private javax.swing.JLabel jLabel227;
    private javax.swing.JLabel jLabel228;
    private javax.swing.JLabel jLabel229;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel230;
    private javax.swing.JLabel jLabel231;
    private javax.swing.JLabel jLabel232;
    private javax.swing.JLabel jLabel233;
    private javax.swing.JLabel jLabel234;
    private javax.swing.JLabel jLabel235;
    private javax.swing.JLabel jLabel236;
    private javax.swing.JLabel jLabel237;
    private javax.swing.JLabel jLabel238;
    private javax.swing.JLabel jLabel239;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel240;
    private javax.swing.JLabel jLabel241;
    private javax.swing.JLabel jLabel242;
    private javax.swing.JLabel jLabel243;
    private javax.swing.JLabel jLabel244;
    private javax.swing.JLabel jLabel245;
    private javax.swing.JLabel jLabel246;
    private javax.swing.JLabel jLabel247;
    private javax.swing.JLabel jLabel248;
    private javax.swing.JLabel jLabel249;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel250;
    private javax.swing.JLabel jLabel251;
    private javax.swing.JLabel jLabel252;
    private javax.swing.JLabel jLabel253;
    private javax.swing.JLabel jLabel254;
    private javax.swing.JLabel jLabel255;
    private javax.swing.JLabel jLabel256;
    private javax.swing.JLabel jLabel257;
    private javax.swing.JLabel jLabel258;
    private javax.swing.JLabel jLabel259;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel260;
    private javax.swing.JLabel jLabel261;
    private javax.swing.JLabel jLabel262;
    private javax.swing.JLabel jLabel263;
    private javax.swing.JLabel jLabel264;
    private javax.swing.JLabel jLabel265;
    private javax.swing.JLabel jLabel266;
    private javax.swing.JLabel jLabel267;
    private javax.swing.JLabel jLabel268;
    private javax.swing.JLabel jLabel269;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel270;
    private javax.swing.JLabel jLabel271;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel80;
    private javax.swing.JLabel jLabel81;
    private javax.swing.JLabel jLabel82;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel85;
    private javax.swing.JLabel jLabel86;
    private javax.swing.JLabel jLabel87;
    private javax.swing.JLabel jLabel88;
    private javax.swing.JLabel jLabel89;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel90;
    private javax.swing.JLabel jLabel91;
    private javax.swing.JLabel jLabel92;
    private javax.swing.JLabel jLabel93;
    private javax.swing.JLabel jLabel94;
    private javax.swing.JLabel jLabel95;
    private javax.swing.JLabel jLabel96;
    private javax.swing.JLabel jLabel97;
    private javax.swing.JLabel jLabel98;
    private javax.swing.JLabel jLabel99;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JRadioButton jRadioButton3;
    private javax.swing.JRadioButton jRadioButton4;
    private javax.swing.JRadioButton jRadioButton5;
    private javax.swing.JRadioButton jRadioButton6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTable jTable4;
    private javax.swing.JTable jTable5;
    private javax.swing.JTextField jumlah;
    private javax.swing.JTextField jumlah1;
    private javax.swing.JTextField jumlahfitrah;
    private javax.swing.JTextField jumlahlbrg;
    private javax.swing.JButton keluar;
    private javax.swing.JTextField kepala;
    private javax.swing.JTextField kepala1;
    private javax.swing.JPanel menu;
    private javax.swing.JTextField modaldagang;
    private javax.swing.JTextField namagalian;
    private javax.swing.JTextField namatemuan;
    private javax.swing.JTextField nilaigalian;
    private javax.swing.JTextField nilaitemuan;
    private javax.swing.JTextField nishab;
    private javax.swing.JTextField nishabperak;
    private javax.swing.JTextField nishabprofesi;
    private javax.swing.JTextField nishabtani;
    private javax.swing.JTextField pengeluaranprofesi;
    private javax.swing.JTextField tambahjumlah;
    private javax.swing.JTextField tambahkepala;
    private javax.swing.JTextField tambahkk;
    private javax.swing.JLabel tgl;
    private javax.swing.JLabel tgl1;
    private javax.swing.JTextField ubahjumlah;
    private javax.swing.JTextField ubahkepala;
    private javax.swing.JTextField ubahkk;
    // End of variables declaration//GEN-END:variables

    public void setUbahjumlah(String r) {
        this.ubahjumlah.setText(r);
    }

    public void setUbahkepala(String r) {
        this.ubahkepala.setText(r);
    }

    public String getTgl() {
        return sm;
    }

    public String getHapuskk1() {
        return hapuskk1.getText();
    }
    
}
