/*
SQLyog Enterprise - MySQL GUI v7.02 
MySQL - 5.5.5-10.1.37-MariaDB : Database - db_perpus
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`db_perpus` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `db_perpus`;

/*Table structure for table `tbl_anggota` */

DROP TABLE IF EXISTS `tbl_anggota`;

CREATE TABLE `tbl_anggota` (
  `nim` int(11) NOT NULL,
  `nama` varchar(250) NOT NULL,
  `tempat_lahir` varchar(50) NOT NULL,
  `tgl_lahir` varchar(15) NOT NULL,
  `jk` enum('L','P') NOT NULL,
  `prodi` varchar(50) NOT NULL,
  `thn_masuk` varchar(4) NOT NULL,
  PRIMARY KEY (`nim`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbl_anggota` */

insert  into `tbl_anggota`(`nim`,`nama`,`tempat_lahir`,`tgl_lahir`,`jk`,`prodi`,`thn_masuk`) values (204171028,'saeful mizwar ','ciamis','1998-05-15','L','D3 Menejemen Informatika','2017');

/*Table structure for table `tbl_buku` */

DROP TABLE IF EXISTS `tbl_buku`;

CREATE TABLE `tbl_buku` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `judul` varchar(200) NOT NULL,
  `pengarang` varchar(100) NOT NULL,
  `penerbit` varchar(150) NOT NULL,
  `thn_terbit` varchar(4) NOT NULL,
  `isbn` varchar(25) NOT NULL,
  `jumlah_buku` int(3) NOT NULL,
  `lokasi` varchar(25) NOT NULL,
  `tgl_input` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Data for the table `tbl_buku` */

insert  into `tbl_buku`(`id`,`judul`,`pengarang`,`penerbit`,`thn_terbit`,`isbn`,`jumlah_buku`,`lokasi`,`tgl_input`) values (1,'Matematika','Asepudin','Gramedia','2015','4871847h',5,'rak2','2016-10-31 03:03:43'),(2,'Dasar PHP','Solihin','Toko bukbek','2010','943823jc4',4,'rak2','2016-10-31 03:03:43'),(3,'Pintar CSS','Jack','Media Suar','2012','934748',8,'rak1','2016-10-31 03:03:43'),(4,'Bahasa Arab','Soleh','Muslim post','2015','923847',3,'rak1','2016-10-31 03:03:43'),(6,'Mahir MySQL','April','Megatama','2014','1234',1,'rak1','2016-10-31 03:03:43'),(7,'HTML Untuk Pemula','Surya','Penerbit 1','2014','2345',5,'rak1','2016-11-05 12:16:37'),(8,'Cerita si Gundul','fitra','alam gaib','2000','asdfg',5,'Rak 1','2019-01-07 12:36:36');

/*Table structure for table `tbl_transaksi` */

DROP TABLE IF EXISTS `tbl_transaksi`;

CREATE TABLE `tbl_transaksi` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `judul` varchar(250) NOT NULL,
  `nim` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `tgl_pinjam` varchar(15) NOT NULL,
  `tgl_kembali` varchar(15) NOT NULL,
  `status` varchar(10) NOT NULL,
  `ket` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `tbl_transaksi` */

insert  into `tbl_transaksi`(`id`,`judul`,`nim`,`nama`,`tgl_pinjam`,`tgl_kembali`,`status`,`ket`) values (1,'Angular js',204171028,'saeful mizwar','06-01-2019','13-01-2019','Kembali','Baik'),(2,'Pintar CSS',204171028,'saeful mizwar','06-01-2019','13-01-2019','Kembali','Baik'),(3,'Mahir PHP',204171028,'saeful mizwar','06-01-2019','17-03-2019','Kembali','Baik'),(4,'Dasar PHP',204171028,'saeful mizwar ','01-01-2019','12-01-2019','Kembali','dipinjam'),(5,'Bahasa Arab',204171028,'saeful mizwar ','01-01-2019','12-01-2019','Pinjam','dipinjam'),(6,'Mahir MySQL',204171028,'saeful mizwar ','07-01-2019','14-01-2019','Pinjam','dipinjam');

/*Table structure for table `tbl_user` */

DROP TABLE IF EXISTS `tbl_user`;

CREATE TABLE `tbl_user` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `nama` varchar(200) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(200) NOT NULL,
  `email` varchar(100) NOT NULL,
  `foto` varchar(50) NOT NULL,
  `level` enum('admin','user') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `tbl_user` */

insert  into `tbl_user`(`id`,`nama`,`username`,`password`,`email`,`foto`,`level`) values (1,'saeful mizwar','admin','1','saefulmizwar15@gmail.com','saeful.jpg','admin'),(2,'Trinoverita','user','1','trinoverita@gmail.com','trinoverita.jpg','user'),(3,'mizwar','mizwar','1','saeful.mizwar15','19489.jpg','user'),(5,'Lusi Kusnaeni','lusi','1','Lusikusnaeni@gmail.com','179000.jpg','user'),(6,'Saiful','saiful','1','saifulnurikhsan@gmail.com','326262.jpg','user');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
