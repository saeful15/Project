<div class="col-sm-9">
 <br> <h4 align="center">Cetak Laporan</h4>
  <hr>	
</div>
<div class="col-md-9">
	<div class="panel panel-info">
		<div class="panel-heading">
			<div class="panel-title">Laporan</div>
		</div>

		<div class="panel-body">
		
		<div class="list-group">		  
		  <a href="../print-anggota.php" target="_blank" class="list-group-item">Laporan Anggota</a>
		  <a href="../print-buku.php" target="_blank" class="list-group-item">Laporan Buku</a>
		  <a href="../print-transaksi.php" target="_blank" class="list-group-item">Laporan Transaksi</a>
		</div>
    
		</div>

	</div>
</div>

