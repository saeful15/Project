<!DOCTYPE html>
<html lang="en">
<head>
  <title>APLIKASI PERPUS</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <script src="../js/jquery.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
  <style>
    .row.content {height: auto}
    
    .sidenav {
      background-color: #f1f1f1;
      height: 100%;
    }
    
    footer {
      background-color: #555;
      color: white;
      padding: 15px;
    }
    
 
    @media screen and (max-width: 767px) {
      .sidenav {
        height: auto;
        padding: 15px;
      }
      .row.content {height: auto;}
    }
  </style>
</head>
<body>
<?php 
session_start();
if(!isset($_SESSION['nama'])|| $_SESSION['level'] != "user"){
  echo "<script>alert('Silahkan login terlebih dahulu')</script>";
  echo "<meta http-equiv='refresh' content='0; url=../index.php'>";
}
else{

  include_once '../inti/head.php';
?>
<div class="container-fluid">
<div class="container-fluid">
  <div class="row content"><br>
    <div class="list-group col-sm-3" align='center' style="background-color:sky;">
      <br>
      <a class="list-group-item active" align='center'><center><h5>USER</h5></center> </a>
      <br>
      <image src="../images/<?php echo $_SESSION['foto']; ?>" width="100" height="100"></image><br>
      <a>Wellcome : <font color=""><?php echo $_SESSION['nama']; ?></font></a>
      <ul class="nav nav-pills nav-stacked">
        <li><a href="?page"> Home</a></li>
        <li><a href="?page=buku"> Buku</a></li>
        <li><a href="?page=anggota"></i> Anggota</a></li>
      </ul>
    </div>


    <?php 
    error_reporting(0);
    switch ($_GET['page']) {
      // menu buku
      case 'buku':
        include "../pengunjung/buku_data.php";
        break;
      case 'detil-buku':
        include "../pengunjung/buku_detil.php";
        break;
      case 'buku_search':
        include "../pengunjung/buku_search.php";
        break;

      // menu anggota
      case 'anggota':
        include "../pengunjung/anggota_data.php";
        break;
      case 'anggota_search':
        include "../pengunjung/anggota_search.php";
        break;
      case 'detil-anggota':
        include '../pengunjung/anggota_detil.php';
        break;
      
      case 'logout':
        include "../logout.php";
        break;
      
      default:
        include "../pengunjung/home.php";
        break;
    }
    ?>
    
  </div>
</div>
</div>
<br>
<footer class="container-fluid" style="background-color:skyblue">
  <p>&copy; PUSTAKA <a target="_blank">BACA.COM</a></p>
</footer>
<?php } ?>
</body>
</html>

