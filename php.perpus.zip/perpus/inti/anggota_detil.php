<?php 
include_once '../inc/class.perpus.php';
$anggota = new anggota;

if (isset($_GET['nim'])) {
	$nim = $_GET['nim'];
	extract($anggota->getData($nim,'tbl_anggota','nim'));
}
?>

<div class="col-sm-9">
	<br><h4 align="center">Detail Anggota</h4>
	<hr>
</div>

<div class="col-md-9">
	
<?php 
if (isset($msg)) {
	echo $msg;
}
?>

	<form method="post">
		<table class="table table-bordered">
			<tr>
				<td>NIM</td>
				<td><input class="form-control" disabled type="text" name="nim1" value="<?=$nim;?>"></td>
			</tr>
			<tr>
				<td>Nama Lengkap</td>
				<td><input class="form-control" disabled type="text" name="nama" value="<?=$nama;?>"></td>
			</tr>
			<tr>
				<td>Tempat Lahir</td>
				<td><input class="form-control" disabled type="text" name="tempat_lahir" value="<?=$tempat_lahir;?>"></td>
			</tr>
			<tr>
				<td>Tanggal Lahir</td>
				<td><input class="form-control" disabled type="date" name="tgl_lahir" value="<?=$tgl_lahir;?>" placeholder="hh/bb/tttt"></td>
			</tr>
			<tr>
				<td>Jenis Kelamin</td>
				<td>
				<?php if ($jk=="L"): ?>
					<input type="radio" value="L" name="jk" checked> Laki-laki
					<input type="radio" disabled value="P" name="jk"> Perempuan					
				<?php else: ?>
					<input type="radio" disabled value="L" name="jk"> Laki-laki
					<input type="radio" value="P" name="jk" checked> Perempuan
				<?php endif ?>
				</td>
			</tr>
			<tr>
				<td>Prodi</td>
				<td>
					<select disabled class="form-control" name="prodi" style="width: 200px">
						<option>Pillih Prodi</option>
						<option value="S1 Teknik Informatika" <?php if ($prodi=='S1 Teknik Informatika'){echo "selected";} ?>>S1 Teknik Informatika</option>
						<option value="D3 Menejemen Informatika" <?php if($prodi=='D3 Menejemen Informatika'){echo "selected";} ?>>D3 Menejemen Informatika</option>
						<option value="D3 Teknik Informatika" <?php if($prodi=='D3 Teknik Informatika'){echo "selected";} ?>>D3 Teknik Informatika</option>
						<option value="S1 Menejemen" <?php if($prodi=='S1 Menejemen'){echo "selected";} ?>>S1 Menejemen</option>
						<option value="S1 Akuntansi" <?php if($prodi=='S1 Akuntansi'){echo "selected";} ?>>S1 Akuntansi</option>
						<option value="D3 Perpajakan" <?php if($prodi=='D3 Perpajakan'){echo "selected";} ?>>D3 Perpajakan</option>
						<option value="S1 Pshykologi" <?php if($prodi=='S1 Pshykologi'){echo "selected";} ?>>S1 Pshykologi</option>
						<option value="S1 Bahasa Jepang" <?php if($prodi=='S1 Bahasa Jepang'){echo "selected";} ?>>S1 Bahasa Jepang</option>
						<option value="S1 Bahasa Inggris" <?php if($prodi=='S1 Bahasa Inggris'){echo "selected";} ?>>S1 Bahasa Inggris</option>
						<option value="S1 Teknik Industri" <?php if($prodi=='S1 Teknik Industri'){echo "selected";} ?>>S1 Teknik Industri</option>
					</select>
				</td>
			</tr>
			<tr>
				<td>Tahun Masuk</td>
				<td><input class="form-control" disabled type="text" name="thn_masuk" value="<?=$thn_masuk;?>"></td>
			</tr>

			<tr>
				<td colspan="2">
					<a href="?page=anggota" class="btn btn-large btn-success"><i class="glyphicon glyphicon-backward"></i> &nbsp;Kembali</a>
				</td>
			</tr>
		</table>
	</form>

</div>