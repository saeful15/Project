<div class="col-sm-9">
  <h4 align="center">PUSTAKA PASIM <hr>	
  <image align='center' src='../images/pasim.jpg'></image></h4>

</div>

