<nav style="background-color:darkred;">
  <div>
    <div>
      <a class="navbar-brand" href="#">Universitas Nasional Pasim Bandung</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href=""><?php echo date('D'.' '.'d-m-Y') ?></a></li>
        <li><a href="?page=logout"> Logout</a></li>
      </ul>
    </div>
  </div>
</nav>