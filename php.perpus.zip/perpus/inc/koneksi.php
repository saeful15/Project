<?php 

$db_con = new PDO('mysql:host=localhost;dbname=db_perpus', 'root', '');

?>
