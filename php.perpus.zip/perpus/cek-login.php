<?php 

session_start();
	include_once('inc/koneksi.php');

	if (isset($_POST['submit'])) {
		$errMsg = '';
		
		$username = trim($_POST['username']);
		$password = trim($_POST['password']);
		
			$stmt = $db_con->prepare('SELECT * FROM tbl_user WHERE username = :username');
			$stmt->bindparam(':username', $username);
			$stmt->execute();
			$results = $stmt->fetch(PDO::FETCH_ASSOC);
		
			if (count($results) > 0 && $password == $results['password']) {
				$_SESSION['nama'] = $results['nama'];
				$_SESSION['username'] = $results['username'];
				$_SESSION['level'] = $results['level'];
				$level = $_SESSION['level'];
				$_SESSION['foto']=$results['foto'];
				if ($_SESSION['level'] == 'admin') {
					echo "<script>alert('Anda berhasil Log In. Sebagai : $level');</script>";
					echo "<meta http-equiv='refresh' content='0; url=inti/index.php'>";
					exit;
				}else{
					echo "<script>alert('Anda berhasil Log In. Sebagai : $level');</script>";
					echo "<meta http-equiv='refresh' content='0; url=pengunjung/index.php'>";
				}
			}else{
		
				echo "<script>alert('Username and Password are not found');</script>";
				echo "<meta http-equiv='refresh' content='0; url=index.php'>";
			}
	}

?>