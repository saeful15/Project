/*
SQLyog Enterprise - MySQL GUI v7.02 
MySQL - 5.5.5-10.1.10-MariaDB : Database - db_login
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`db_login` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `db_login`;

/*Table structure for table `kas` */

DROP TABLE IF EXISTS `kas`;

CREATE TABLE `kas` (
  `tanggal` date DEFAULT NULL,
  `keterangan` varchar(50) DEFAULT NULL,
  `debet` int(11) DEFAULT NULL,
  `kredit` int(11) DEFAULT NULL,
  `saldo` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `kas` */

insert  into `kas`(`tanggal`,`keterangan`,`debet`,`kredit`,`saldo`) values ('2018-05-15','infaq dari mr. saeful',10000000,0,10000000),('2018-05-17','beli amply',0,2500000,7500000),('2018-05-18','benerin mic',0,20000,7480000),('2018-05-18','kas jumat',120000,0,7600000),('2018-05-21','infsq ti husnul',500000,0,8100000);

/*Table structure for table `kas_fitrah` */

DROP TABLE IF EXISTS `kas_fitrah`;

CREATE TABLE `kas_fitrah` (
  `tanggal` date DEFAULT NULL,
  `no_kk` char(16) DEFAULT NULL,
  `kepala_keluarga` varchar(50) DEFAULT NULL,
  `anggota` int(11) DEFAULT NULL,
  `debet` int(11) DEFAULT NULL,
  `kredit` int(11) DEFAULT NULL,
  `saldo` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `kas_fitrah` */

insert  into `kas_fitrah`(`tanggal`,`no_kk`,`kepala_keluarga`,`anggota`,`debet`,`kredit`,`saldo`) values ('2018-05-03','1234567890123789','sihab',6,150000,0,150000),('2018-05-05','1234567891012244','Novelina Erlin Saputri',5,125000,0,275000),('2018-05-08','1234567891012344','Hadiyanto',5,125000,0,400000),('2018-05-08','1234567891012346','Deded Rolistio Alamsyah',4,100000,0,500000),('2018-05-08','1234567890123484','caridi',8,200000,0,700000),('2018-05-08','1234567891012394','Monica Dyah Pratiwi',5,125000,0,825000),('2018-05-09','1234567891012313','Husnul Roby Gunawan',7,175000,0,1000000),('2018-05-09','1233567890123456','SM',5,125000,0,1125000),('2018-05-13','1233567840123456','Teguh Nurwansyah',11,275000,0,1400000),('2018-05-15','1234567891012341','Abdul Wahid',3,75000,0,1475000),('2018-05-15','1234567891012348','Fenita Oktaviani',4,100000,0,1575000),('2018-05-21','1234567891012304','Nina Man Aida',3,75000,0,1650000);

/*Table structure for table `kk` */

DROP TABLE IF EXISTS `kk`;

CREATE TABLE `kk` (
  `no_kk` char(16) NOT NULL,
  `nama_kepala_keluarga` varchar(30) NOT NULL,
  `anggota` int(11) DEFAULT NULL,
  PRIMARY KEY (`no_kk`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `kk` */

insert  into `kk`(`no_kk`,`nama_kepala_keluarga`,`anggota`) values ('1233567800123456','Suyanto herera',12),('1233567840123456','Teguh Nurwansyah',11),('1233567890123456','SM',5),('1234567890123454','siti',2),('1234567890123484','caridi',8),('1234567890123789','sihab',6),('1234567891012144','Ninda Try Alviani',5),('1234567891012244','Novelina Erlin Saputri',5),('1234567891012304','Nina Man Aida',3),('1234567891012313','Husnul Roby Gunawan',4),('1234567891012323','Hafidh Almarogi',5),('1234567891012326','Hasri Nuryawati',5),('1234567891012341','Abdul Wahid',3),('1234567891012342','Fitra Surya Saputra',4),('1234567891012343','Bahrum Husein Nst',4),('1234567891012344','Hadiyanto',5),('1234567891012345','Dani Kusnaedi',7),('1234567891012346','Deded Rolistio Alamsyah',4),('1234567891012347','Fahmi Ali',6),('1234567891012348','Fenita Oktaviani',4),('1234567891012354','Irsyad Ilyasa',5),('1234567891012364','Iyan Sanjaya',5),('1234567891012374','Ihsan Nasihin',3),('1234567891012384','M. Baghyan Widiyanto',5),('1234567891012394','Monica Dyah Pratiwi',5),('1234567891012444','Nurrizky',2),('1234567891012544','Putri Widiyanti Rohman',4),('1234567891012644','Rini Oktaviani',5),('1234567891014221','Nurdin',7),('1234567891017341','Saeful Mizwar',9),('1234567891034221','Amelia Yuniar',7);

/*Table structure for table `saldo` */

DROP TABLE IF EXISTS `saldo`;

CREATE TABLE `saldo` (
  `saldo` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `saldo` */

insert  into `saldo`(`saldo`) values (8100000);

/*Table structure for table `saldo_fitrah` */

DROP TABLE IF EXISTS `saldo_fitrah`;

CREATE TABLE `saldo_fitrah` (
  `saldo` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `saldo_fitrah` */

/*Table structure for table `tb_login` */

DROP TABLE IF EXISTS `tb_login`;

CREATE TABLE `tb_login` (
  `username` varchar(20) NOT NULL,
  `kata_sandi` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tb_login` */

insert  into `tb_login`(`username`,`kata_sandi`) values ('zakat','zakat');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
