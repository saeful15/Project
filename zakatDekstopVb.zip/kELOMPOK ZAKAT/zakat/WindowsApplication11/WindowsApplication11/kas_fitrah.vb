﻿Imports MySql.Data.MySqlClient
    Public Class kas_fitrah
        Dim CMD4 As MySqlCommand
    Dim adp As MySqlDataAdapter
    Sub cetak3()
        Dim Query As String
        Dim data As New DataTable
        Query = "select *from saldo_fitrah"
        adp = New MySqlDataAdapter(Query, con)
        adp.Fill(data)
        DataGridView2.DataSource = data
    End Sub
    Sub cetak1()
        Dim Query As String
        Dim data As New DataTable
        Query = "select *from kas_fitrah"
        adp = New MySqlDataAdapter(Query, con)
        adp.Fill(data)
        DataGridView3.DataSource = data
    End Sub

 
    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Try
            Dim sqlquery = "SELECT nama_kepala_keluarga, anggota FROM kk WHERE no_kk = '" + TextBox8.Text + "' "
            Dim myCommand As New MySqlCommand
            Dim myAdapter As New MySqlDataAdapter
            myCommand.Connection = con
            myCommand.CommandText = sqlquery
            myAdapter.SelectCommand = myCommand
            CMD4 = New MySqlCommand(sqlquery, con)
            CMD4.ExecuteNonQuery()
            Dim dt As New DataTable
            myAdapter.Fill(dt)
            DataGridView1.DataSource = dt
            TextBox1.Text = DataGridView1.Rows(0).Cells(0).Value.ToString
            TextBox3.Text = DataGridView1.Rows(0).Cells(1).Value.ToString
            TextBox2.Text = Val(TextBox3.Text) * 10000 * 2.5
        Catch ex As Exception
            MsgBox("masukan no kk yang benar")
        End Try
        
    End Sub
    Private Sub ComboBox1_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox1.MouseEnter
        ComboBox1.Text = ""
    End Sub
    Private Sub ComboBox2_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox2.MouseEnter
        ComboBox2.Text = ""
    End Sub
    Private Sub ComboBox3_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox3.MouseEnter
        ComboBox3.Text = ""
    End Sub
    Private Sub kas_fitrah_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        For a = 1 To 31
            ComboBox1.Items.Add(a)
        Next
        For a = 1 To 12
            ComboBox2.Items.Add(a)
        Next
        
        For a = 2018 To 2060
            ComboBox3.Items.Add(a)
        Next
        Timer1.Start()
        cetak3()
        cetak1()
        DataGridView3.Columns(0).Width = 110
        DataGridView3.Columns(1).Width = 110
        DataGridView3.Columns(2).Width = 135
        DataGridView3.Columns(3).Width = 85
        DataGridView3.Columns(4).Width = 85
        DataGridView3.Columns(5).Width = 85
        Me.DataGridView3.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        Me.DataGridView3.Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        Me.DataGridView3.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        Me.DataGridView3.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Label1.Text = Format(Now, "yyyy:M:d")
    End Sub
    Dim sapi
    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Dim ss As Integer = DataGridView2.Rows(0).Cells(0).Value.ToString
        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox8.Text = "" Then
            MsgBox("Silahkan Isi Semua Form")
        Else
            Call koneksi()
            ss += Val(TextBox2.Text)
            Dim edit1 As String = "update saldo_fitrah set saldo='" & ss.ToString & "'where saldo='" & (ss - Val(TextBox2.Text)).ToString & "'"
            CMD4 = New MySqlCommand(edit1, con)
            CMD4.ExecuteNonQuery()
            cetak3()
            Dim save As String = "insert into kas_fitrah values ( '" & Label1.Text & "','" & TextBox8.Text & "','" & TextBox1.Text & "','" & TextBox3.Text & "','" & TextBox2.Text & "','" & "0" & "','" & ss.ToString & "')"
            CMD4 = New MySqlCommand(save, con)
            CMD4.ExecuteNonQuery()
            MsgBox("Input data berhasil")
            sapi = CreateObject("sapi.spvoice")
            sapi.speak("thank you family" + TextBox1.Text)
            cetak1()

        End If

        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox8.Text = ""
    End Sub

    Private Sub GroupBox4_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox4.Enter

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If TextBox4.Text.Length <> 16 Then
            MsgBox("nomor KK Harus Benar")
        End If
        Try
            Dim sqlquery = "SELECT nama_kepala_keluarga, anggota FROM kk WHERE no_kk = '" + TextBox4.Text + "' "
            Dim myCommand As New MySqlCommand
            Dim myAdapter As New MySqlDataAdapter
            myCommand.Connection = con
            myCommand.CommandText = sqlquery
            myAdapter.SelectCommand = myCommand
            CMD4 = New MySqlCommand(sqlquery, con)
            CMD4.ExecuteNonQuery()
            Dim dt As New DataTable
            myAdapter.Fill(dt)
            DataGridView1.DataSource = dt
            TextBox6.Text = DataGridView1.Rows(0).Cells(0).Value.ToString
            TextBox5.Text = DataGridView1.Rows(0).Cells(1).Value.ToString

        Catch ex As Exception
            MsgBox("masukan no kk yang benar")
        End Try
        TextBox4.Enabled = False
        TextBox6.Enabled = False
        TextBox5.Enabled = False
    End Sub



    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim ss As Integer = DataGridView2.Rows(0).Cells(0).Value.ToString
        If ComboBox1.Text = "" Or ComboBox3.Text = "" Or ComboBox2.Text = "" Or TextBox4.Text = "" Or TextBox7.Text = "" Then
            MsgBox("Inputan Harus Benar")
        End If
        If TextBox7.Text = "" Then
            MsgBox("berapa Jumlah Uang Yang Dibagikan")
        Else
            Call koneksi()
            ss -= Val(TextBox7.Text)
            Dim edit1 As String = "update saldo_fitrah set saldo='" & ss.ToString & "'where saldo='" & (ss + Val(TextBox7.Text)).ToString & "'"
            CMD4 = New MySqlCommand(edit1, con)
            CMD4.ExecuteNonQuery()
            cetak3()
            Dim save As String = "insert into kas_fitrah values ( '" & ComboBox3.Text + "-" + ComboBox2.Text + "-" + ComboBox1.Text & "','" & TextBox4.Text & "','" & TextBox6.Text & "','" & TextBox5.Text & "','" & "0" & "','" & TextBox7.Text & "','" & ss.ToString & "')"
            CMD4 = New MySqlCommand(save, con)
            CMD4.ExecuteNonQuery()
            MsgBox("Input data berhasil")
            cetak1()

        End If
        ComboBox1.Text = ""
        ComboBox2.Text = ""
        ComboBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""

    End Sub


    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        TextBox4.Enabled = True
        TextBox6.Enabled = True
        TextBox5.Enabled = True
        TextBox4.Text = ""
        TextBox6.Text = ""
        TextBox5.Text = ""
    End Sub
End Class
