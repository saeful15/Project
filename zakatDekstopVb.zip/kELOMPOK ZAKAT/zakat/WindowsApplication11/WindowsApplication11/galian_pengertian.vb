﻿Public Class galian_pengertian

End Class
