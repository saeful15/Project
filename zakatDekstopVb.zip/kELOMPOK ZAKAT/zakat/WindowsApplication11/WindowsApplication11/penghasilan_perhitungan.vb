﻿Public Class penghasilan_perhitungan

    Private Sub penghasilan_perhitungan_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ComboBox1.Items.Add("Laba")
        ComboBox1.Items.Add("Rugi")
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        If ComboBox1.SelectedIndex = (0) Then
            TextBox7.Text = (Val(TextBox2.Text) + Val(TextBox3.Text) + Val(TextBox4.Text) - Val(TextBox5.Text)) * 2.5 / 100
        ElseIf ComboBox1.SelectedIndex = (1) Then
            TextBox7.Text = (Val(TextBox2.Text) + Val(TextBox3.Text) - Val(TextBox4.Text) - Val(TextBox5.Text)) * 2.5 / 100
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox7.Text = ""
        ComboBox1.Text = ""
    End Sub
End Class
