﻿Public Class penghasilan_syarat

End Class
