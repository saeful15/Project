﻿Public Class Form2
    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Timer1.Start()
        Label2.Text = "Kalkulator Zakat"
        Timer1.Enabled = True
        Timer1.Interval = 100

    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Label1.Text = Format(Now, "hh:mm:ss")
        Label3.Text = Format(Now, "ddd/d/M/yyyy")
        If (Label2.Left + Label2.Width <= 0) Then
            Label2.Left = Me.Width
        End If
        Label2.Left = Label2.Left - 10
    End Sub
    Dim emas1 As New emas_Pengertian
    Dim emas2 As New Emas_syarat
    Dim emas3 As New Emas_rukun1
    Dim emas4 As New emas_penghitungan

    Dim perak1 As New perak_pengertian
    Dim perak2 As New perak_syarat
    Dim perak3 As New perak_rukun
    Dim perak4 As New perak_penghitungan

    Dim temuan1 As New temuan_pengertian
    Dim temuan2 As New temuan_syarat
    Dim temuan3 As New temuan_rukun
    Dim temuan4 As New temuan_penghitungan

    Dim galian1 As New galian_pengertian
    Dim galian2 As New galian_syarat
    Dim galian3 As New galian_rukun
    Dim galian4 As New galian_penghitungan

    Dim pertanian1 As New pertanian_pengertian
    Dim pertanian2 As New pertanian_syarat
    Dim pertanian3 As New pertanian_rukun
    Dim pertanian4 As New pertanian_penghitungan

    Dim profesi1 As New profesi_pengertian
    Dim profesi2 As New profesi_syarat
    Dim profesi3 As New profesi_rukun
    Dim profesi4 As New profesi_penghitungan

    Dim penghasilan1 As New Pengertian_Perdagangan1
    Dim penghasilan2 As New penghasilan_syarat
    Dim penghasilan3 As New penghasilan_rukun
    Dim penghasilan4 As New penghasilan_perhitungan


    Dim fitrah1 As New UserControl4
    Dim fitrah2 As New UserControl3
    Dim fitrah3 As New UserControl1
    Dim fitrah4 As New UserControl2
    Dim fitrah5 As New kartu_keluarga


    Private Sub PegertianToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PegertianToolStripMenuItem.Click
        Label4.Text = "Zakat Emas"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(emas1)
    End Sub

    Private Sub RukunToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RukunToolStripMenuItem.Click
        Label4.Text = "Zakat Emas"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(emas3)
    End Sub

    Private Sub SyaratToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SyaratToolStripMenuItem.Click
        Label4.Text = "Zakat Emas"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(emas2)
    End Sub

    Private Sub HitunganToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HitunganToolStripMenuItem.Click
        Label4.Text = "Zakat Emas"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(emas4)
    End Sub

    Private Sub ToolStripMenuItem42_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem42.Click
        Label4.Text = "Zakat Perak"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(perak1)
    End Sub

    Private Sub ToolStripMenuItem43_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem43.Click
        Label4.Text = "Zakat Perak"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(perak3)
    End Sub

    Private Sub ToolStripMenuItem44_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem44.Click
        Label4.Text = "Zakat Perak"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(perak2)
    End Sub

    Private Sub ToolStripMenuItem45_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem45.Click
        Label4.Text = "Zakat Perak"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(perak4)
    End Sub

    Private Sub ToolStripMenuItem37_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem37.Click
        Label4.Text = "Zakat Fitrah"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(fitrah1)
    End Sub

    Private Sub ToolStripMenuItem38_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem38.Click
        Label4.Text = "Zakat Fitrah"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(fitrah3)
    End Sub

    Private Sub ToolStripMenuItem39_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem39.Click
        Label4.Text = "Zakat Fitrah"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(fitrah2)
    End Sub

    Private Sub ToolStripMenuItem40_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem40.Click
        Label4.Text = "Zakat Fitrah"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(fitrah4)
    End Sub

    Private Sub ToolStripMenuItem32_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem32.Click
        Label4.Text = "Zakat Barang Galian"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(galian1)
    End Sub

    Private Sub ToolStripMenuItem33_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem33.Click
        Label4.Text = "Zakat Barang Galian"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(galian3)
    End Sub

    Private Sub ToolStripMenuItem34_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem34.Click
        Label4.Text = "Zakat Barang Galian"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(galian2)
    End Sub

    Private Sub ToolStripMenuItem35_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem35.Click
        Label4.Text = "Zakat Barang Galian"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(galian4)
    End Sub

    Private Sub ToolStripMenuItem27_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem27.Click
        Label4.Text = "Zakat Perdagangan"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(penghasilan1)
    End Sub

    Private Sub ToolStripMenuItem28_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem28.Click
        Label4.Text = "Zakat Perdagangan"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(penghasilan3)
    End Sub

    Private Sub ToolStripMenuItem29_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem29.Click
        Label4.Text = "Zakat Perdagangan"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(penghasilan2)
    End Sub

    Private Sub ToolStripMenuItem30_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem30.Click
        Label4.Text = "Zakat Perdagangan"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(penghasilan4)
    End Sub

    Private Sub ToolStripMenuItem22_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem22.Click
        Label4.Text = "Zakat Pertanian"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(pertanian1)
    End Sub

    Private Sub ToolStripMenuItem23_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem23.Click
        Label4.Text = "Zakat Pertanian"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(pertanian3)
    End Sub

    Private Sub ToolStripMenuItem24_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem24.Click
        Label4.Text = "Zakat Pertanian"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(pertanian2)
    End Sub

    Private Sub ToolStripMenuItem25_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem25.Click
        Label4.Text = "Zakat Pertanian"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(pertanian4)
    End Sub

    Private Sub ToolStripMenuItem17_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem17.Click
        Label4.Text = "Zakat Profesi"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(profesi1)
    End Sub

    Private Sub ToolStripMenuItem18_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem18.Click
        Label4.Text = "Zakat Profesi"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(profesi3)
    End Sub

    Private Sub ToolStripMenuItem19_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem19.Click
        Label4.Text = "Zakat Profesi"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(profesi2)
    End Sub

    Private Sub ToolStripMenuItem20_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem20.Click
        Label4.Text = "Zakat Profesi"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(profesi4)
    End Sub

    Private Sub ToolStripMenuItem12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem12.Click
        Label4.Text = "Zakat Barang Temuan"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(temuan1)
    End Sub

    Private Sub ToolStripMenuItem13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem13.Click
        Label4.Text = "Zakat Barang Temuan"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(temuan3)
    End Sub

    Private Sub ToolStripMenuItem14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem14.Click
        Label4.Text = "Zakat Barang Temuan"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(temuan2)
    End Sub

    Private Sub ToolStripMenuItem15_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem15.Click
        Label4.Text = "Zakat Barang Temuan"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(temuan4)
    End Sub

    Private Sub ToolStripMenuItem8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem8.Click
        Label4.Text = "Zakat Fitrah Masyarakat"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(fitrah5)
    End Sub
    Private Sub DataMasyarakatToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Label4.Text = "Zakat Fitrah"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(fitrah5)
    End Sub
    Dim kas As New Kas
    Private Sub ToolStripMenuItem7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem7.Click
        Label4.Text = "Kas"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(kas)
    End Sub
    Dim kas_fitrah As New kas_fitrah
    Private Sub KasFitrahToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KasFitrahToolStripMenuItem.Click
        Label4.Text = "Kas Fitrah"
        Panel1.Controls.Clear()
        Panel1.Controls.Add(kas_fitrah)
    End Sub
    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.Click
        Me.Hide()
        Form1.Show()
    End Sub

    Private Sub PictureBox1_MouseHover(ByVal sender As Object, ByVal e As System.EventArgs) Handles PictureBox1.MouseHover
        PictureBox1.BackColor = Color.Red
    End Sub

    Private Sub PictureBox1_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles PictureBox1.MouseLeave
        PictureBox1.BackColor = Color.Transparent
    End Sub


    Private Sub MenuStrip1_ItemClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles MenuStrip1.ItemClicked

    End Sub
End Class