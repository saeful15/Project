﻿Imports MySql.Data.MySqlClient
Public Class Form1
    Private Sub TextBox2_enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox2.Enter
        TextBox2.UseSystemPasswordChar = True
        TextBox2.Text = ""
        TextBox2.ForeColor = Color.Black
    End Sub
    Private Sub TextBox1_enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.Enter
        TextBox1.Text = ""
        TextBox1.ForeColor = Color.Black
    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            TextBox2.UseSystemPasswordChar = False
        Else
            TextBox2.UseSystemPasswordChar = True
        End If
    End Sub
    Dim sapi
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        koneksi()
        DataGridView1.Hide()
        TextBox1.Text = "Masukan User Name"
        TextBox2.UseSystemPasswordChar = False
        TextBox1.ForeColor = Color.Gray
        TextBox2.Text = "Masukan paswoard"
        TextBox2.ForeColor = Color.Gray
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim sqlquery = "SELECT * FROM tb_login WHERE username = '" + TextBox1.Text + "' AND kata_sandi= '" + TextBox2.Text + "'"
        Dim myCommand As New MySqlCommand
        Dim myAdapter As New MySqlDataAdapter
        myCommand.Connection = con
        myCommand.CommandText = sqlquery
        Try
            myAdapter.SelectCommand = myCommand
            Dim dt As New DataTable
            myAdapter.Fill(dt)
            DataGridView1.DataSource = dt
            Dim name As String = DataGridView1.Rows(0).Cells(0).Value.ToString
            Dim pasw As String = DataGridView1.Rows(0).Cells(1).Value.ToString
            If (name = TextBox1.Text And pasw = TextBox2.Text) Then
                sapi = CreateObject("sapi.spvoice")
                sapi.speak("welcome to Zakat group project")
                MsgBox("Login Success, Wellcome " & TextBox1.Text & " ! ", MsgBoxStyle.Information, "Successfull Login")
                Form2.Show()
                Me.Hide()
            End If
        Catch ex As Exception
            MsgBox("Error Your Username Or Password !", MsgBoxStyle.Exclamation, "Error Login")
            TextBox1.Text = "Masukan User Name"
            TextBox2.UseSystemPasswordChar = False
            TextBox1.ForeColor = Color.Gray
            TextBox2.Text = "Masukan paswoard"
            TextBox2.ForeColor = Color.Gray
        End Try
        TextBox1.Text = "Masukan User Name"
        TextBox2.UseSystemPasswordChar = False
        TextBox1.ForeColor = Color.Gray
        TextBox2.Text = "Masukan paswoard"
        TextBox2.ForeColor = Color.Gray
        CheckBox1.Checked = False
    End Sub

End Class
