﻿Public Class temuan_syarat

End Class
