﻿Imports MySql.Data.MySqlClient
Public Class kartu_keluarga
    Dim CMD4 As MySqlCommand
    Dim adp As MySqlDataAdapter
    Sub cetak()
        Dim Query As String
        Dim data As New DataTable
        Query = "select *from kk"
        adp = New MySqlDataAdapter(Query, con)
        adp.Fill(data)
        DataGridView1.DataSource = data
    End Sub
    Private Sub kartu_keluarga_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        koneksi()
        cetak()
        DataGridView1.Columns(0).Width = 110
        DataGridView1.Columns(1).Width = 135
        DataGridView1.Columns(2).Width = 60
        Me.DataGridView1.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
    End Sub

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox5.Text = "" Or TextBox6.Text = "" Or TextBox7.Text = "" Then
            MsgBox("Silahkan Isi Semua Form")
        ElseIf TextBox7.Text.Length <> 16 Then
            MsgBox("digit kk harus 16 digit")
        Else
            Try
                Call koneksi()
                Dim save As String = "insert into kk values ( '" & TextBox7.Text & "','" & TextBox6.Text & "','" & TextBox5.Text & "')"
                CMD4 = New MySqlCommand(save, con)
                CMD4.ExecuteNonQuery()
                MsgBox("Input data berhasil")
            Catch ex As Exception
                MsgBox("No kk tidak boleh sama")
            End Try
            

        End If
        cetak()
        TextBox7.Text = ""
        TextBox6.Text = ""
        TextBox5.Text = ""
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If TextBox4.Text = "" Then
            MsgBox("Silahkan Isi Form")
        ElseIf TextBox4.Text.Length <> 16 Then
            MsgBox("digit kk harus 16 digit")
        Else
            If MessageBox.Show("Yakin akan dihapus..?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                Call koneksi()
                Dim hapus As String = "delete From kk  where no_kk='" & TextBox4.Text & "'"
                CMD4 = New MySqlCommand(hapus, con)
                CMD4.ExecuteNonQuery()
            End If
            cetak()
        End If
        TextBox4.Text = ""
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If no.Text = "" Then
            MsgBox("Silahkan Isi Semua Form")
        ElseIf no.Text.Length <> 16 Or update_no.Text.Length <> 16 Then
            MsgBox("digit kk harus 16 digit")
        Else
            Try
                Dim edit As String = "update kk set no_kk='" & update_no.Text & "',nama_kepala_keluarga='" & update_nama_kepala.Text & "',anggota='" & update_jumlah.Text & "' where no_kk='" & no.Text & "'"
                CMD4 = New MySqlCommand(edit, con)
                CMD4.ExecuteNonQuery()
                MsgBox("Data Berhasil diUpdate")
                cetak()

            Catch ex As Exception
                MsgBox("No kk harus benar")
            End Try

        End If
        no.Text = ""
        update_jumlah.Text = ""
        update_nama_kepala.Text = ""
        update_no.Text = ""
    End Sub

End Class
