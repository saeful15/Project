﻿Public Class pertanian_penghitungan

    
    Private Sub pertanian_penghitungan_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ComboBox1.Items.Add("Pengairan Alami")
        ComboBox1.Items.Add("Pengairan Pribadi")
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If Val(TextBox1.Text) < 652.8 Then
            MsgBox("Minimal 652.8 Kilo Gram", MsgBoxStyle.Critical, "Information")
        ElseIf ComboBox1.SelectedIndex = (0) Then
            TextBox3.Text = Val(TextBox1.Text) * Val(TextBox2.Text) * 10 / 100
            TextBox5.Text = Val(TextBox1.Text) * 10 / 100
        ElseIf ComboBox1.SelectedIndex = (1) Then
            TextBox3.Text = Val(TextBox1.Text) * Val(TextBox2.Text) * 5 / 100
            TextBox5.Text = Val(TextBox1.Text) * 5 / 100
        End If

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox5.Text = ""
        ComboBox1.Text = ""
    End Sub
End Class
