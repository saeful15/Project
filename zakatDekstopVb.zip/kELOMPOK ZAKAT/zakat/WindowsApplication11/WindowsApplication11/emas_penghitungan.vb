﻿Public Class emas_penghitungan
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If (Val(TextBox1.Text) < 85) Then
            MsgBox("Minimal 85 Gram", MsgBoxStyle.Critical, "Information")
        Else
            TextBox5.Text = Val(TextBox1.Text) * 2.5 / 100
            TextBox2.Text = Val(TextBox1.Text) * Val(TextBox3.Text) * 2.5 / 100
        End If
        
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox5.Text = ""
    End Sub


End Class
