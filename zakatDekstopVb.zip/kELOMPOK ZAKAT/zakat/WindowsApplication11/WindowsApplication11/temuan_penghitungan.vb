﻿Public Class temuan_penghitungan

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Label5.Text = "Jumlah Zakat " & TextBox1.Text & " Yang Harus Dibayar Adalah"
        TextBox3.Text = Val(TextBox2.Text) * 20 / 100
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
    End Sub
End Class
