﻿Imports Mysql.data.MySqlClient
Module Module1
    Dim adp As MySqlDataAdapter
    Dim sql As String
    Public con As MySqlConnection
    Dim qq As New kartu_keluarga
    Dim myCommand As New MySqlCommand
    Dim sapi
    Sub koneksi()
        Try
            sql = "server=localhost;user id=root;database=db_login"
            con = New MySqlConnection(sql)
            If con.State = ConnectionState.Closed Then
                con.Open()
                'MessageBox.Show("Koneksi jf")
            Else
                con.Close()
            End If
        Catch ex As MySql.Data.MySqlClient.MySqlException
            sapi = CreateObject("sapi.spvoice")
            sapi.speak("please turn on xampp first")
            MessageBox.Show("Silahkan Nyalakan" & vbCrLf & "XAMPP Terlebih Dahulu ")
            Form1.Close()
        End Try
    End Sub
End Module
