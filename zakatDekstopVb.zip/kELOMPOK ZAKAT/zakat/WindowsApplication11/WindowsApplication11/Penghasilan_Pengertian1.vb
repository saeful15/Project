﻿Public Class Penghasilan_Pengertian1

End Class
