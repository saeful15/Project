﻿Public Class temuan_rukun

End Class
