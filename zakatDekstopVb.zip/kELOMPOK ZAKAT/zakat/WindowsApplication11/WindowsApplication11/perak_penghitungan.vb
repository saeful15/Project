﻿Public Class perak_penghitungan

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If (Val(TextBox1.Text) < 595) Then
            MsgBox("Minimal 595 Gram", MsgBoxStyle.Critical, "Information")
        Else
            TextBox5.Text = Val(TextBox1.Text) * 2.5 / 100
            TextBox2.Text = Val(TextBox1.Text) * Val(TextBox3.Text) * 2.5 / 100
        End If

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox5.Text = ""
    End Sub

    Private Sub perak_perhitungan_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TextBox1.Enabled = True
        TextBox2.Enabled = False
        TextBox3.Enabled = True
        TextBox4.Enabled = False
        TextBox5.Enabled = False
        Label2.Enabled = True
        Label2.Enabled = True
        Label8.Enabled = True
        Label4.Enabled = True
        Label7.Enabled = True
        Label6.Enabled = True
        Label7.Enabled = True
        Label8.Enabled = True
        Button1.Enabled = True
        Button2.Enabled = True
    End Sub

End Class

