﻿Public Class penghasilan_rukun

End Class
