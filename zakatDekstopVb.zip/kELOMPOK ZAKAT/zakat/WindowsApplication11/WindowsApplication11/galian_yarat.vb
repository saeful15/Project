﻿Public Class galian_syarat

End Class
