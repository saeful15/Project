﻿Imports MySql.Data.MySqlClient
Public Class Kas
    Dim CMD4 As MySqlCommand
    Dim adp As MySqlDataAdapter
    Sub cetak1()
        Dim Query As String
        Dim data As New DataTable
        Query = "select *from kas"
        adp = New MySqlDataAdapter(Query, con)
        adp.Fill(data)
        DataGridView1.DataSource = data
    End Sub
    Sub cetak2()
        Dim Query As String
        Dim data As New DataTable
        Query = "select *from saldo"
        adp = New MySqlDataAdapter(Query, con)
        adp.Fill(data)
        DataGridView2.DataSource = data
    End Sub
   
    Private Sub Kas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        For a = 1 To 31
            ComboBox4.Items.Add(a)
        Next
        For a = 1 To 12
            ComboBox2.Items.Add(a)
        Next

        For a = 2018 To 2060
            ComboBox3.Items.Add(a)
        Next
        cetak1()
        ComboBox1.Items.Add("debet")
        ComboBox1.Items.Add("kredit")
        Dim sqlquery = "SELECT * FROM saldo "
        cetak2()
        DataGridView1.Columns(1).Width = 150

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim ss As Integer = DataGridView2.Rows(0).Cells(0).Value.ToString
        If ComboBox4.Text = "" Or ComboBox3.Text = "" Or ComboBox2.Text = "" Or TextBox4.Text = "" Or TextBox5.Text = "" Then
            MsgBox("Silahkan Isi Semua Form")
        Else
            Call koneksi()
            If (ComboBox1.SelectedIndex = 0) Then
                ss += Val(TextBox5.Text)
                Dim edit1 As String = "update saldo set saldo='" & ss.ToString & "'where saldo='" & (ss - Val(TextBox5.Text)).ToString & "'"
                CMD4 = New MySqlCommand(edit1, con)
                CMD4.ExecuteNonQuery()
                Dim save As String = "insert into kas values ('" & ComboBox3.Text + "-" + ComboBox2.Text + "-" + ComboBox4.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "','" & "0" & "','" & ss.ToString & "')"
                CMD4 = New MySqlCommand(save, con)
                CMD4.ExecuteNonQuery()
                MsgBox("Input data berhasil")
            ElseIf ComboBox1.SelectedIndex = 1 Then
                ss -= Val(TextBox5.Text)
                Dim edit1 As String = "update saldo set saldo='" & ss.ToString & "'where saldo='" & (ss + Val(TextBox5.Text)).ToString & "'"
                CMD4 = New MySqlCommand(edit1, con)
                CMD4.ExecuteNonQuery()
                Dim save As String = "insert into kas values ( '" & ComboBox3.Text + "-" + ComboBox2.Text + "-" + ComboBox4.Text & "','" & TextBox4.Text & "','" & "0" & "','" & TextBox5.Text & "','" & ss.ToString & "')"
                CMD4 = New MySqlCommand(save, con)
                CMD4.ExecuteNonQuery()
                MsgBox("Input data berhasil")
            End If
            cetak1()
            cetak2()
            ComboBox4.Text = ""
            ComboBox2.Text = ""
            ComboBox3.Text = ""
            TextBox4.Text = ""
            ComboBox1.Text = ""
            TextBox5.Text = ""
        End If
    End Sub

    Private Sub ComboBox4_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox4.MouseEnter
        ComboBox4.Text = ""
    End Sub
    Private Sub ComboBox2_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox2.MouseEnter
        ComboBox2.Text = ""
    End Sub
    Private Sub ComboBox3_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox3.MouseEnter
        ComboBox3.Text = ""
    End Sub

End Class
